#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 013
'Kayıtta lint' -> daha anlaşılır etiket + tooltip

    py path.py --check
    py path.py
"""

import argparse
import os
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "013"
HTML_REL = "splash_code/templates/index.html"

OLD = '<div class="label">Kayıtta lint</div>'
NEW = ('<div class="label" title="Kaydettikten sonra kodu tarar; '
       'sözdizimi hatalarını ve uyarıları Sorunlar panelinde gösterir">'
       'Kaydederken hata kontrolü</div>')

SKIP = {".git", ".venv", "venv", "node_modules", "_backups",
        ".idea", ".vscode", "dist", "build"}


def find_root(cli=None):
    cands = []
    if cli:
        cands.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for p in cands:
        if p and os.path.isdir(os.path.join(p, "splash_code")):
            return p
    return cands[0] if cands else os.getcwd()


def rd(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def wr(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > 25 * 1024 * 1024:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def check(root):
    hp = os.path.join(root, HTML_REL)
    if not os.path.isfile(hp):
        print("  index.html yok")
        return
    src = rd(hp)
    if NEW in src:
        print("  ZATEN UYGULANMIS")
    elif OLD in src:
        print("  DEGISTIRILECEK: 'Kayıtta lint' -> 'Kaydederken hata kontrolü'")
    else:
        print("  UYARI: 'Kayıtta lint' metni bulunamadi")
        print("  (farkli bir patch degistirmis olabilir)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 56)
    print("  Patch %s — etiket düzeltmesi" % PATCH_ID)
    print("=" * 56)

    if a.check:
        return check(root)

    hp = os.path.join(root, HTML_REL)
    if not os.path.isfile(hp):
        print("  HATA: %s yok" % HTML_REL)
        return 1

    src = rd(hp)

    if NEW in src:
        print("  Zaten uygulanmış.")
        return 0
    if OLD not in src:
        print("  'Kayıtta lint' bulunamadı — bir şey değişmiş.")
        return 2

    if a.dry_run:
        print("  Plan: 'Kayıtta lint' -> 'Kaydederken hata kontrolü'")
        print("  --dry-run temiz.")
        return 0

    zp = None
    if not a.no_backup:
        zp, n = backup(root)
        print("  Backup: %s (%d dosya)" % (zp, n))

    new_src = src.replace(OLD, NEW, 1)
    wr(hp, new_src)
    print("  OK — etiket güncellendi.")
    print("  Eski: Kayıtta lint")
    print("  Yeni: Kaydederken hata kontrolü")
    print("  (üzerine gelince tooltip açıklaması da var)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
