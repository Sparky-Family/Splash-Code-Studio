#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 005 (hotfix)
1) splash_code/__init__.py : eksik app_name/version tanimlari (append, guard'li)
2) main.py : import guard (ImportError'da constants'a duser)
3) clear_pycache : GERCEKTEN siler (onceki patch'lerde bug vardi)

    py path.py --check
    py path.py --dry-run
    py path.py
"""

import argparse
import os
import py_compile
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "005"
TITLE = "app_name ImportError hotfix + gercek pycache temizligi"
MARK = "# ===== SC-PATCH-005 ====="
GUARD = "SC005_IMPORT_GUARD"

# ══════════════════════════════════════════════════════════════
#  splash_code/__init__.py  (APPEND - mevcut içerik KORUNUR)
# ══════════════════════════════════════════════════════════════

B_INIT = r"""
# ===== SC-PATCH-005 =====
# main.py 'from splash_code import app_name, version' kullaniyor.
# Bu isimler eksikse ImportError olusuyordu; guard'li tanimlar.
if 'app_name' not in globals():
    app_name = 'Splash Code Studio'
if 'version' not in globals():
    version = '3.0.0'
if 'version_name' not in globals():
    version_name = 'Modular'
if 'APP_NAME' not in globals():
    APP_NAME = app_name
if 'APP_VERSION' not in globals():
    APP_VERSION = version + ' - ' + version_name
# ===== /SC-PATCH-005 =====
"""

APPEND = {"splash_code/__init__.py": B_INIT}

# ══════════════════════════════════════════════════════════════
#  main.py  (CERRAHI EDIT)   guard, anchor, yeni, aciklama
# ══════════════════════════════════════════════════════════════

NEW_IMPORT = (
    "# " + GUARD + "\n"
    "try:\n"
    "    from splash_code import app_name, version\n"
    "except ImportError:\n"
    "    try:\n"
    "        from splash_code.constants import (\n"
    "            APP_NAME as app_name, APP_VERSION as version)\n"
    "    except Exception:\n"
    "        app_name, version = 'Splash Code Studio', '3.0.0'\n"
)

EDITS = {
    "main.py": [
        (GUARD,
         "from splash_code import app_name, version",
         NEW_IMPORT,
         "import guard -> constants fallback"),
    ],
}

# ══════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════

SKIP_DIRS = {".git", ".venv", "venv", "node_modules",
             "_backups", ".idea", ".vscode", "dist", "build"}
PRUNE = SKIP_DIRS                      # __pycache__ BUDANMIYOR (bug fix)
MAX_BACKUP_FILE = 25 * 1024 * 1024


def find_root(cli=None):
    cands = []
    if cli:
        cands.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for c in cands:
        if os.path.isdir(os.path.join(c, "splash_code")):
            return c
    return cands[0]


def read_text(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def clear_pycache(root):
    """__pycache__ dizinlerini GERCEKTEN siler (budama yok)."""
    targets = []
    for dp, dn, fn in os.walk(root):
        if os.path.basename(dp) == "__pycache__":
            targets.append(dp)
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in PRUNE]
    for t in targets:
        shutil.rmtree(t, ignore_errors=True)
    return len(targets)


def make_backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP_DIRS]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAX_BACKUP_FILE:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def make_plan(root):
    ops, problems = [], []

    for rel, block in APPEND.items():
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            # dosya yoksa olustur
            ops.append((rel, block.strip("\n") + "\n", "YENI DOSYA"))
            continue
        src = read_text(p)
        if MARK in src:
            ops.append((rel, None, "ZATEN"))
            continue
        body = block.strip("\n")
        new = src if (src.endswith("\n") or not src) else src + "\n"
        new += "\n" + body + "\n"
        ops.append((rel, new, "+%d satir" % len(body.splitlines())))

    for rel, items in EDITS.items():
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            problems.append("%s: dosya yok" % rel)
            continue
        cur = read_text(p)
        for guard, anchor, new, desc in items:
            if guard in cur:
                ops.append((rel, None, "ZATEN: " + desc))
                continue
            c = cur.count(anchor)
            if c != 1:
                problems.append("%s: anchor %d kez -> %s" % (rel, c, desc))
                continue
            cur = cur.replace(anchor, new, 1)
            ops.append((rel, cur, "OK: " + desc))
    return ops, problems


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc005.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR...")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                if k in names:
                    with open(os.path.join(root, rel), "wb") as f:
                        f.write(z.read(k))
                    print("    geri: %s" % rel)
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Elle ac: %s" % zp)


def do_restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: %s" % zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    clear_pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def do_check(root):
    print("\n  --- TANI ---")
    p = os.path.join(root, "splash_code", "__init__.py")
    print("  __init__.py : %s" % p)
    if os.path.isfile(p):
        with open(p, "rb") as f:
            raw = f.read()
        print("  boyut       : %d byte" % len(raw))
        print("  icerik      : %s" % repr(raw[:400]))
        for name in (b"app_name", b"version", b"version_name"):
            print("  %-11s : %s"
                  % (name.decode(), "VAR" if name in raw else "YOK"))
    else:
        print("  !! DOSYA YOK (namespace package -> ImportError)")

    mn = os.path.join(root, "main.py")
    if os.path.isfile(mn):
        s = read_text(mn)
        print("  main.py guard : %s" % ("VAR" if GUARD in s else "YOK"))
        print("  main.py offline: %s"
              % ("VAR" if "_start_local_server" in s else "YOK"))

    api = os.path.join(root, "splash_code", "api.py")
    if os.path.isfile(api):
        s = read_text(api)
        print("  api.py tempfile: %s"
              % ("VAR" if "import tempfile" in s else "YOK <-- KAYIT BOZUK"))

    nc = 0
    for dp, dn, fn in os.walk(root):
        if os.path.basename(dp) == "__pycache__":
            nc += 1
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in PRUNE]
    print("  __pycache__ adedi: %d" % nc)
    ml = os.path.join(root, "splash_code", "static", "monaco",
                      "vs", "loader.js")
    print("  Yerel Monaco     : %s"
          % ("VAR" if os.path.isfile(ml) else "YOK -> --get-monaco (004)"))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 64)
    print("  Splash Code Studio - Patch %s" % PATCH_ID)
    print("  %s" % TITLE)
    print("=" * 64)
    print("  Kok: %s" % root)

    if a.restore:
        return do_restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok. --root ver.")
        return 1
    if a.check:
        return do_check(root)

    ops, problems = make_plan(root)
    print("\n  Plan:")
    for rel, new, info in ops:
        print("    %-30s %s" % (rel, info))
    if problems:
        print("\n  !! SORUN:")
        for x in problems:
            print("     - %s" % x)
        print("  Hicbir sey yazilmadi.")
        return 2

    todo = [(r, c) for r, c, _ in ops if c is not None]
    if a.dry_run:
        print("\n  --dry-run: temiz. (%d dosya yazilacak)" % len(todo))
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = make_backup(root)
        print("    %s (%d dosya)" % (zp, n))

    touched = []
    try:
        for rel, content in todo:
            write_atomic(os.path.join(root, rel), content)
            touched.append(rel)
            print("    + %s" % rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Derleme dogrulamasi...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK")
    print("    %d __pycache__ GERCEKTEN silindi" % clear_pycache(root))

    print("\n" + "=" * 64)
    print("  Patch %s UYGULANDI" % PATCH_ID)
    if zp:
        print("  Geri al: py path.py --restore \"%s\"" % zp)
    print("  Test: py main.py")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())
