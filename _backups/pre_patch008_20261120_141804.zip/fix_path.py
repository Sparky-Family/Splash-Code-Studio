#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Patch 008 on-kontrol hotfix
# compile(str) BOM'u temizlemez, compile(bytes) temizler.
# On-kontrolde derlemeye bytes vererek disk davranisini birebir taklit eder.

import os
import py_compile
import sys
import tempfile

TARGET = sys.argv[1] if len(sys.argv) > 1 else "path.py"

EDITS = [
    ('compile(src, name, "exec")',
     'compile(src.encode("utf-8"), name, "exec")'),
    ('compile(rd(p) + "\\n" + blk, rel, "exec")',
     'compile((rd(p) + "\\n" + blk).encode("utf-8"), rel, "exec")'),
]


def main():
    p = os.path.abspath(TARGET)
    if not os.path.isfile(p):
        print("Dosya yok: %s" % p)
        return 1

    with open(p, "r", encoding="utf-8", newline="") as f:
        src = f.read()

    changed = 0
    for old, new in EDITS:
        if new in src:
            print("Zaten duzeltilmis: %s" % old[:40])
            continue
        n = src.count(old)
        if n != 1:
            print("BULUNAMADI (%d adet): %s" % (n, old))
            return 2
        src = src.replace(old, new, 1)
        changed += 1
        print("Duzeltildi: %s" % old[:40])

    if changed:
        bak = p + ".bak"
        if not os.path.exists(bak):
            with open(bak, "w", encoding="utf-8", newline="") as f:
                with open(p, "r", encoding="utf-8", newline="") as g:
                    f.write(g.read())
        with open(p, "w", encoding="utf-8", newline="") as f:
            f.write(src)
        print("Yedek: %s" % bak)

    print("path.py derleme kontrolu...")
    try:
        py_compile.compile(
            p, cfile=os.path.join(tempfile.gettempdir(), "sc_fix008.pyc"),
            doraise=True)
    except Exception as e:
        print("HALA HATA: %s" % e)
        return 1

    print("OK. Simdi: py path.py --dry-run")
    return 0


if __name__ == "__main__":
    sys.exit(main())
