#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 008 "Studio"
Coklu terminal + canli Terminal Studio kontrol reyonu + interaktif stdin
+ dosya watcher + .gitignore arama + AI streaming/diff-apply + offline font
+ ses tasarimi + undo.

    py path.py --check
    py path.py --dry-run
    py path.py
    py path.py --restore _backups/pre_patch008_XXXX.zip
"""

import argparse
import os
import py_compile
import re
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "008"
TITLE = "Studio: coklu terminal, stdin, watcher, arama, AI stream, font"
MARK = "SC-STUDIO-008"
HTML_REL = "splash_code/templates/index.html"

# ══════════════════════════════════════════════════════════════════════
#  splash_code/features.py
# ══════════════════════════════════════════════════════════════════════

FEATURES_PY = r'''"""
Splash Code Studio - Studio Features (SC-STUDIO-008)
Interaktif run/stdin, dosya watcher, .gitignore arama, AI streaming,
font yerellestirme, studio ayar kaliciligi.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

NO_WINDOW = 0x08000000 if os.name == "nt" else 0
SKIP_DIRS = {
    "node_modules", "__pycache__", ".git", "venv", ".venv", "dist",
    "build", ".next", "target", ".mypy_cache", ".pytest_cache",
    ".ruff_cache", "site-packages", ".idea", ".vscode", ".cache",
    "bower_components", ".turbo", ".parcel-cache",
}
FONT_CSS = (
    "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700"
    "&family=JetBrains+Mono:wght@400;500;600&display=swap"
)
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def js_call(fn, *args):
    try:
        import webview
        if not webview.windows:
            return
        payload = ",".join(json.dumps(a, ensure_ascii=False) for a in args)
        webview.windows[0].evaluate_js(
            "if(window.%s)window.%s(%s);" % (fn, fn, payload))
    except Exception:
        pass


def pkg_dir():
    return os.path.dirname(os.path.abspath(__file__))


def studio_file():
    from .constants import SETTINGS_DIR
    return os.path.join(SETTINGS_DIR, "studio.json")


def load_studio():
    try:
        with open(studio_file(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_studio(d):
    try:
        os.makedirs(os.path.dirname(studio_file()), exist_ok=True)
        tmp = studio_file() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d or {}, f, indent=2, ensure_ascii=False)
        os.replace(tmp, studio_file())
        return True
    except Exception:
        return False


# ── Calistirma + stdin ────────────────────────────────────────────────
def build_run_cmd(path, cwd):
    ext = os.path.splitext(path or "")[1].lower()
    q = os.path.abspath(path) if path else ""
    if ext in (".py", ".pyw"):
        return [sys.executable, "-u", q]
    if ext in (".js", ".mjs", ".cjs"):
        return ["node", q]
    if ext in (".ts", ".tsx"):
        return ["npx", "--yes", "tsx", q]
    if ext == ".sh":
        return ["bash", q]
    if ext == ".ps1":
        return ["powershell", "-ExecutionPolicy", "Bypass", "-File", q]
    if ext == ".rb":
        return ["ruby", q]
    if ext == ".php":
        return ["php", q]
    if ext == ".lua":
        return ["lua", q]
    if ext == ".pl":
        return ["perl", q]
    if ext == ".go":
        return ["go", "run", q]
    if ext == ".rs":
        man = os.path.join(cwd or os.path.dirname(q), "Cargo.toml")
        if os.path.isfile(man):
            return ["cargo", "run", "--manifest-path", man]
        return ["rustc", q, "-o", os.path.join(tempfile.gettempdir(), "sc_rs")]
    return None


class RunManager:
    """Tek calisan surec; stdin PIPE, stdout anlik akar."""

    def __init__(self):
        self.proc = None
        self.lock = threading.Lock()

    def busy(self):
        with self.lock:
            return bool(self.proc and self.proc.poll() is None)

    def start(self, cmd, cwd):
        if self.busy():
            return {"ok": False, "hata": "Zaten calisan bir surec var"}
        env = dict(os.environ)
        env["PYTHONUNBUFFERED"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        env.setdefault("TERM", "xterm-256color")
        kw = {}
        if os.name == "nt":
            kw["creationflags"] = (
                subprocess.CREATE_NEW_PROCESS_GROUP | NO_WINDOW)
        else:
            kw["start_new_session"] = True
        try:
            p = subprocess.Popen(
                cmd, cwd=cwd or None, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                bufsize=-1, env=env, **kw)
        except Exception as ex:
            return {"ok": False, "hata": str(ex)}
        with self.lock:
            self.proc = p
        threading.Thread(target=self._pump, args=(p,),
                         name="sc-run", daemon=True).start()
        return {"ok": True, "pid": p.pid}

    def _pump(self, p):
        try:
            while True:
                b = p.stdout.read1(65536)
                if not b:
                    break
                js_call("scRunOut", b.decode("utf-8", "replace"))
        except Exception:
            pass
        rc = None
        try:
            rc = p.wait(timeout=5)
        except Exception:
            pass
        with self.lock:
            if self.proc is p:
                self.proc = None
        js_call("scRunDone", rc)

    def send(self, data):
        with self.lock:
            p = self.proc
        if not p or p.poll() is not None:
            return {"ok": False, "hata": "Calisan surec yok"}
        try:
            s = data if isinstance(data, str) else str(data)
            p.stdin.write(s.encode("utf-8", "replace"))
            p.stdin.flush()
            return {"ok": True}
        except Exception as ex:
            return {"ok": False, "hata": str(ex)}

    def stop(self):
        with self.lock:
            p = self.proc
        if not p or p.poll() is not None:
            return {"ok": False, "hata": "Calisan surec yok"}
        try:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(p.pid)],
                    capture_output=True, timeout=8,
                    creationflags=NO_WINDOW)
            else:
                import signal
                try:
                    os.killpg(os.getpgid(p.pid), signal.SIGTERM)
                except Exception:
                    p.terminate()
            try:
                p.wait(timeout=3)
            except Exception:
                p.kill()
        except Exception:
            try:
                p.kill()
            except Exception:
                pass
        with self.lock:
            self.proc = None
        return {"ok": True}


RUN = RunManager()


# ── Dosya Watcher ─────────────────────────────────────────────────────
class Watcher:
    def __init__(self):
        self._snap = None
        self._lock = threading.Lock()

    def poll(self, cwd, paths, dirs):
        files = {}
        listing = {}
        watched = []
        for p in (paths or []):
            if not p:
                continue
            ap = os.path.abspath(p)
            watched.append(ap)
            try:
                st = os.stat(ap)
                files[ap] = [round(st.st_mtime, 3), st.st_size]
            except Exception:
                files[ap] = None
        targets = ([cwd] if cwd else []) + list(dirs or [])
        seen = set()
        for d in targets:
            if not d:
                continue
            ad = os.path.abspath(d)
            if ad in seen or not os.path.isdir(ad):
                continue
            seen.add(ad)
            names = []
            try:
                for e in os.scandir(ad):
                    if e.name in SKIP_DIRS:
                        continue
                    names.append(e.name)
                names.sort()
            except Exception:
                pass
            listing[ad] = names
        cur = {"f": files, "d": listing}
        with self._lock:
            prev = self._snap
            self._snap = cur
        if prev is None:
            return {"ok": True, "init": True, "changed": [],
                    "deleted": [], "tree": []}
        pf = prev.get("f", {})
        changed, deleted = [], []
        for ap in watched:
            now = files.get(ap)
            before = pf.get(ap)
            if now is None and before is not None:
                deleted.append(ap)
            elif now is not None and before is not None and now != before:
                changed.append(ap)
        tree = []
        pd = prev.get("d", {})
        for d, names in listing.items():
            if d in pd and pd[d] != names:
                tree.append(d)
        return {"ok": True, "init": False, "changed": changed,
                "deleted": deleted, "tree": tree}

    def reset(self):
        with self._lock:
            self._snap = None


WATCH = Watcher()


# ── .gitignore ────────────────────────────────────────────────────────
class GitIgnore:
    def __init__(self, root):
        self.root = os.path.abspath(root or ".")
        self.rules = []
        self.add_dir(self.root, "")

    @staticmethod
    def _compile(pat):
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        dir_only = pat.endswith("/")
        pat = pat.strip().strip("/")
        anchored = "/" in pat
        out = []
        i, n = 0, len(pat)
        while i < n:
            c = pat[i]
            if c == "*":
                if pat[i:i + 3] == "**/":
                    out.append("(?:.*/)?")
                    i += 3
                    continue
                if pat[i:i + 2] == "**":
                    out.append(".*")
                    i += 2
                    continue
                out.append("[^/]*")
                i += 1
                continue
            if c == "?":
                out.append("[^/]")
                i += 1
                continue
            if c == "[":
                j = pat.find("]", i + 1)
                if j > i:
                    out.append(pat[i:j + 1])
                    i = j + 1
                    continue
            out.append(re.escape(c))
            i += 1
        body = "".join(out) or "(?!)"
        rx = ("^" if anchored else "^(?:.*/)?") + body
        return neg, dir_only, re.compile(rx)

    def add_dir(self, folder, rel):
        p = os.path.join(folder, ".gitignore")
        base = (rel or "").replace("\\", "/").strip("/")
        try:
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    s = line.rstrip("\r\n")
                    if not s.strip() or s.lstrip().startswith("#"):
                        continue
                    try:
                        self.rules.append((base, self._compile(s)))
                    except Exception:
                        continue
        except Exception:
            pass

    def ignored(self, rel, is_dir):
        rel = (rel or "").replace("\\", "/").strip("/")
        if not rel:
            return False
        res = False
        for base, (neg, dir_only, rx) in self.rules:
            if base:
                if not rel.startswith(base + "/") and rel != base:
                    continue
                r = rel[len(base):].lstrip("/")
            else:
                r = rel
            if not r:
                continue
            m = rx.match(r)
            if not m:
                continue
            tail = r[m.end():]
            if tail and not tail.startswith("/"):
                continue
            if dir_only and not tail and not is_dir:
                continue
            res = not neg
        return res


def _is_binary(path):
    try:
        if os.path.getsize(path) > 4 * 1024 * 1024:
            return True
        with open(path, "rb") as f:
            return b"\x00" in f.read(4096)
    except Exception:
        return True


def _match_glob(rel, patterns):
    if not patterns:
        return True
    for pat in patterns:
        pat = pat.strip()
        if not pat:
            continue
        if re.search(r"[*?\[]", pat):
            import fnmatch
            if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(
                    os.path.basename(rel), pat):
                return True
        elif pat in rel:
            return True
    return False


def search(root, query, opts=None):
    opts = opts or {}
    use_regex = bool(opts.get("regex"))
    case = bool(opts.get("case"))
    whole = bool(opts.get("whole"))
    use_gi = opts.get("gitignore", True)
    inc = [x for x in (opts.get("include") or "").split(",") if x.strip()]
    exc = [x for x in (opts.get("exclude") or "").split(",") if x.strip()]
    limit = int(opts.get("limit") or 800)
    if not query or not root or not os.path.isdir(root):
        return {"ok": False, "hits": [], "files": 0, "scanned": 0,
                "hata": "Eksik parametre"}
    q = query
    if use_regex:
        if whole:
            q = r"\b(?:" + q + r")\b"
    else:
        q = re.escape(query)
        if whole:
            q = r"\b" + q + r"\b"
    try:
        rx = re.compile(q, 0 if case else re.IGNORECASE)
    except re.error as ex:
        return {"ok": False, "hits": [], "files": 0, "scanned": 0,
                "hata": "Regex: %s" % ex}
    gi = GitIgnore(root) if use_gi else None
    plain = None if use_regex else (query if case else query.lower())
    hits, scanned, fcount = [], 0, 0
    truncated = False
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root).replace("\\", "/")
        if rel_dir == ".":
            rel_dir = ""
        keep = []
        for d in dirnames:
            if d in SKIP_DIRS or (d.startswith(".") and d != ".github"):
                continue
            rel = (rel_dir + "/" + d).lstrip("/")
            if gi and gi.ignored(rel, True):
                continue
            keep.append(d)
        dirnames[:] = keep
        if gi:
            gi.add_dir(dirpath, rel_dir)
        for fn in filenames:
            rel = (rel_dir + "/" + fn).lstrip("/")
            if gi and gi.ignored(rel, False):
                continue
            if inc and not _match_glob(rel, inc):
                continue
            if exc and _match_glob(rel, exc):
                continue
            p = os.path.join(dirpath, fn)
            if _is_binary(p):
                continue
            scanned += 1
            got = 0
            try:
                with open(p, "r", encoding="utf-8", errors="ignore") as f:
                    for i, ln in enumerate(f, 1):
                        if plain is not None:
                            hay = ln if case else ln.lower()
                            if plain not in hay:
                                continue
                        m = rx.search(ln)
                        if not m:
                            continue
                        hits.append({"path": p, "rel": rel, "line": i,
                                     "col": m.start(),
                                     "text": ln.rstrip()[:240]})
                        got += 1
                        if len(hits) >= limit:
                            truncated = True
                            break
            except Exception:
                continue
            if got:
                fcount += 1
            if truncated:
                break
        if truncated:
            break
    return {"ok": True, "hits": hits, "files": fcount,
            "scanned": scanned, "truncated": truncated}


def replace_all(root, query, repl, opts=None):
    res = search(root, query, opts)
    if not res.get("ok"):
        return res
    opts = opts or {}
    use_regex = bool(opts.get("regex"))
    case = bool(opts.get("case"))
    whole = bool(opts.get("whole"))
    q = query
    if use_regex:
        if whole:
            q = r"\b(?:" + q + r")\b"
    else:
        q = re.escape(query)
        if whole:
            q = r"\b" + q + r"\b"
    rx = re.compile(q, 0 if case else re.IGNORECASE)
    byfile = {}
    for h in res["hits"]:
        byfile.setdefault(h["path"], 0)
        byfile[h["path"]] += 1
    backup, total, changed = [], 0, 0
    for p in byfile:
        try:
            with open(p, "r", encoding="utf-8", errors="strict") as f:
                src = f.read()
        except Exception:
            continue
        new, k = rx.subn(repl or "", src)
        if not k:
            continue
        backup.append({"path": p, "content": src})
        try:
            d = os.path.dirname(p)
            fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
                f.write(new)
            os.replace(tmp, p)
            total += k
            changed += 1
        except Exception:
            backup.pop()
    return {"ok": True, "replacements": total, "changed_files": changed,
            "backup": backup}


def restore_backup(backup):
    n = 0
    for item in (backup or []):
        try:
            with open(item["path"], "w", encoding="utf-8", newline="") as f:
                f.write(item["content"])
            n += 1
        except Exception:
            continue
    return {"ok": True, "restored": n}


# ── AI Streaming ──────────────────────────────────────────────────────
class AiStreams:
    def __init__(self):
        self.lock = threading.Lock()
        self.cancels = {}
        self.n = 0

    def start(self, provider, key, model, messages):
        if not key:
            return {"ok": False, "hata": "API key yok"}
        with self.lock:
            self.n += 1
            sid = "s%d" % self.n
            ev = threading.Event()
            self.cancels[sid] = ev
        threading.Thread(
            target=self._run,
            args=(sid, provider, key, model, messages or [], ev),
            name="sc-ai-" + sid, daemon=True).start()
        return {"ok": True, "id": sid}

    def cancel(self, sid):
        with self.lock:
            ev = self.cancels.get(sid)
        if ev:
            ev.set()
            return {"ok": True}
        return {"ok": False}

    def _emit_lines(self, resp, ev, on_data):
        for raw in resp:
            if ev.is_set():
                break
            line = raw.decode("utf-8", "replace").strip()
            if not line or not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            try:
                on_data(json.loads(payload))
            except Exception:
                continue

    def _run(self, sid, provider, key, model, messages, ev):
        parts = []
        err = None
        try:
            if provider == "gemini":
                model = (model or "gemini-2.5-flash").strip()
                sysp, contents = [], []
                for m in messages:
                    r = m.get("role")
                    t = m.get("content") or ""
                    if r == "system":
                        sysp.append(t)
                    else:
                        contents.append({
                            "role": "user" if r == "user" else "model",
                            "parts": [{"text": t}]})
                if not contents:
                    raise RuntimeError("Bos mesaj")
                if contents[0]["role"] != "user":
                    contents.insert(0, {"role": "user",
                                        "parts": [{"text": "(baglam)"}]})
                body = {"contents": contents}
                if sysp:
                    body["systemInstruction"] = {
                        "parts": [{"text": "\n\n".join(sysp)}]}
                url = ("https://generativelanguage.googleapis.com/v1beta/"
                       "models/" + model + ":streamGenerateContent?alt=sse")
                req = urllib.request.Request(
                    url, data=json.dumps(body).encode("utf-8"),
                    headers={"Content-Type": "application/json",
                             "x-goog-api-key": key}, method="POST")

                def on(d):
                    for c in (d.get("candidates") or []):
                        for p in ((c.get("content") or {}).get("parts") or []):
                            t = p.get("text") or ""
                            if t:
                                parts.append(t)
                                js_call("scAiChunk", sid, t)
                with urllib.request.urlopen(req, timeout=180) as resp:
                    self._emit_lines(resp, ev, on)

            elif provider == "claude":
                model = (model or "claude-sonnet-4-5").strip()
                sysp, msgs = [], []
                for m in messages:
                    if m.get("role") == "system":
                        sysp.append(m.get("content") or "")
                    else:
                        msgs.append({
                            "role": "assistant" if m.get("role") == "assistant"
                            else "user",
                            "content": m.get("content") or ""})
                if not msgs:
                    raise RuntimeError("Bos mesaj")
                body = {"model": model, "max_tokens": 8192,
                        "messages": msgs, "stream": True}
                if sysp:
                    body["system"] = "\n\n".join(sysp)
                req = urllib.request.Request(
                    "https://api.anthropic.com/v1/messages",
                    data=json.dumps(body).encode("utf-8"),
                    headers={"Content-Type": "application/json",
                             "x-api-key": key,
                             "anthropic-version": "2023-06-01"},
                    method="POST")

                def on(d):
                    if d.get("type") == "content_block_delta":
                        t = (d.get("delta") or {}).get("text") or ""
                        if t:
                            parts.append(t)
                            js_call("scAiChunk", sid, t)
                    elif d.get("type") == "error":
                        raise RuntimeError(
                            (d.get("error") or {}).get("message", "AI hatasi"))
                with urllib.request.urlopen(req, timeout=180) as resp:
                    self._emit_lines(resp, ev, on)
            else:
                err = "Bilinmeyen saglayici"
        except urllib.error.HTTPError as ex:
            try:
                err = "HTTP %s: %s" % (
                    ex.code, ex.read().decode("utf-8", "ignore")[:300])
            except Exception:
                err = "HTTP %s" % ex.code
        except Exception as ex:
            err = str(ex)
        js_call("scAiDone", sid, "".join(parts), err, ev.is_set())
        with self.lock:
            self.cancels.pop(sid, None)


AI = AiStreams()


# ── Font yerellestirme ────────────────────────────────────────────────
def localize_fonts():
    out_dir = os.path.join(pkg_dir(), "static", "fonts")
    os.makedirs(out_dir, exist_ok=True)
    try:
        req = urllib.request.Request(FONT_CSS, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=90) as r:
            css = r.read().decode("utf-8", "replace")
    except Exception as ex:
        return {"ok": False, "hata": "CSS indirilemedi: %s" % ex}
    urls = sorted(set(re.findall(r"url\((https://[^)]+)\)", css)))
    if not urls:
        return {"ok": False, "hata": "Font URL bulunamadi"}
    n = 0
    for u in urls:
        name = u.split("/")[-1].split("?")[0]
        if not name:
            name = "f%d.woff2" % n
        dest = os.path.join(out_dir, name)
        try:
            if not os.path.isfile(dest):
                rq = urllib.request.Request(u, headers={"User-Agent": UA})
                with urllib.request.urlopen(rq, timeout=90) as r:
                    data = r.read()
                with open(dest, "wb") as f:
                    f.write(data)
            css = css.replace(u, name)
            n += 1
        except Exception:
            continue
    try:
        with open(os.path.join(out_dir, "sc-fonts.css"), "w",
                  encoding="utf-8") as f:
            f.write(css)
    except Exception as ex:
        return {"ok": False, "hata": str(ex)}
    return {"ok": True, "files": n, "dir": out_dir}
'''

# ══════════════════════════════════════════════════════════════════════
#  api.py  APPEND
# ══════════════════════════════════════════════════════════════════════

API_APPEND = r'''
# ===== SC-STUDIO-008 =====
import time as _sc008_time
import tempfile as _sc008_tmp
from . import features as _sc008_f
from . import terminal as _sc008_term


def _sc008_run_baslat(self, path, content, cwd):
    try:
        cwd = cwd or self._cwd or os.getcwd()
        target = path
        if content is not None:
            ext = os.path.splitext(path or "")[1] or ".py"
            d = _sc008_tmp.mkdtemp(prefix="sc_run_")
            target = os.path.join(d, "unsaved" + ext)
            with open(target, "w", encoding="utf-8", newline="") as f:
                f.write(content)
        if not target:
            return {"ok": False, "hata": "Dosya yok"}
        cmd = _sc008_f.build_run_cmd(target, cwd)
        if not cmd:
            return {"ok": False,
                    "hata": "Desteklenmeyen uzanti: %s"
                            % os.path.splitext(target)[1]}
        r = _sc008_f.RUN.start(cmd, cwd)
        if r.get("ok"):
            r["cmd"] = " ".join(str(c) for c in cmd)
            r["file"] = target
        return r
    except Exception as e:
        return {"ok": False, "hata": str(e)}


def _sc008_run_stdin(self, data):
    return _sc008_f.RUN.send(data)


def _sc008_run_durdur(self):
    return _sc008_f.RUN.stop()


def _sc008_run_durum(self):
    return {"ok": True, "busy": _sc008_f.RUN.busy()}


def _sc008_terminal_ac(self, cwd, shell=None, name=None):
    tid = "s%d" % int(_sc008_time.time() * 1000)
    r = _sc008_term.term_spawn(tid, cwd or self._cwd or os.getcwd(), shell)
    if r.get("ok"):
        r["term_id"] = tid
        r["name"] = name or "Terminal"
        r["cwd"] = cwd or self._cwd or os.getcwd()
    return r


def _sc008_terminal_listele(self):
    try:
        return {"ok": True, "ids": list(_sc008_term._TERM_PROCS.keys())}
    except Exception:
        return {"ok": True, "ids": []}


def _sc008_izleme_poll(self, cwd, paths, dirs):
    return _sc008_f.WATCH.poll(cwd or self._cwd, paths, dirs)


def _sc008_izleme_sifirla(self):
    _sc008_f.WATCH.reset()
    return {"ok": True}


def _sc008_arama(self, query, cwd, opts):
    return _sc008_f.search(cwd or self._cwd, query, opts or {})


def _sc008_degistir(self, query, repl, cwd, opts):
    return _sc008_f.replace_all(cwd or self._cwd, query, repl, opts or {})


def _sc008_geri_al(self, backup):
    return _sc008_f.restore_backup(backup)


def _sc008_ai_stream(self, messages, context):
    s = self.settings
    provider = s.get("ai_provider", "")
    if not provider:
        return {"ok": False, "hata": "AI saglayici secilmemis"}
    msgs = []
    if context:
        msgs.append({"role": "system",
                     "content": "Asagidaki kod baglaminda yardimci ol. "
                                "Kod onerirken tam fenced blok ver:\n"
                                + str(context)})
    msgs.extend(messages or [])
    key = (s.get("ai_gemini_key", "") if provider == "gemini"
           else s.get("ai_claude_key", ""))
    return _sc008_f.AI.start(provider, key, s.get("ai_model", ""), msgs)


def _sc008_ai_durdur(self, sid):
    return _sc008_f.AI.cancel(sid)


def _sc008_font(self):
    r = _sc008_f.localize_fonts()
    try:
        clear_build_cache()
    except Exception:
        pass
    return r


def _sc008_studio_yukle(self):
    return _sc008_f.load_studio()


def _sc008_studio_kaydet(self, d):
    return {"ok": _sc008_f.save_studio(d or {})}


Api.run_baslat = _sc008_run_baslat
Api.run_stdin = _sc008_run_stdin
Api.run_durdur = _sc008_run_durdur
Api.run_durum = _sc008_run_durum
Api.terminal_ac = _sc008_terminal_ac
Api.terminal_listele = _sc008_terminal_listele
Api.izleme_poll = _sc008_izleme_poll
Api.izleme_sifirla = _sc008_izleme_sifirla
Api.arama_v2 = _sc008_arama
Api.degistir_v2 = _sc008_degistir
Api.geri_al = _sc008_geri_al
Api.ai_stream_baslat = _sc008_ai_stream
Api.ai_stream_durdur = _sc008_ai_durdur
Api.font_yerellestir = _sc008_font
Api.studio_ayar_yukle = _sc008_studio_yukle
Api.studio_ayar_kaydet = _sc008_studio_kaydet
# ===== /SC-STUDIO-008 =====
'''

# ══════════════════════════════════════════════════════════════════════
#  html_builder.py  APPEND
# ══════════════════════════════════════════════════════════════════════

HTMLB_APPEND = r'''
# ===== SC-STUDIO-008 =====
import re as _sc008_re
_sc008_orig_build = build_html


def build_html(settings):
    html = _sc008_orig_build(settings)
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "static", "fonts", "sc-fonts.css")
        if os.path.isfile(p) and not os.environ.get("SPLASH_FORCE_CDN"):
            html = _sc008_re.sub(
                r"<link[^>]*fonts\.googleapis\.com[^>]*>",
                '<link rel="stylesheet" href="static/fonts/sc-fonts.css">',
                html)
            html = _sc008_re.sub(
                r"<link[^>]*fonts\.gstatic\.com[^>]*>", "", html)
    except Exception:
        pass
    return html
# ===== /SC-STUDIO-008 =====
'''

# ══════════════════════════════════════════════════════════════════════
#  STUDIO CSS
# ══════════════════════════════════════════════════════════════════════

STUDIO_CSS = r'''
:root{
  --sc-ink:#05070E;--sc-ink2:#0A0F1C;--sc-surf:#0E1526;--sc-surf2:#131C31;
  --sc-line:#1E2A45;--sc-line2:#2C3E63;--sc-txt:#DDE7F5;--sc-dim:#7C8DAE;
  --sc-cyan:#22D3EE;--sc-blue:#3B82F6;--sc-violet:#8B5CF6;--sc-mag:#F0ABFC;
  --sc-lime:#A3E635;--sc-amber:#FBBF24;--sc-ok:#34D399;--sc-warn:#FBBF24;
  --sc-bad:#FB7185;--sc-info:#60A5FA;
  --sc-grad:linear-gradient(115deg,#22D3EE 0%,#3B82F6 32%,#8B5CF6 62%,#F0ABFC 100%);
}
#terminalPanel.sc-studio{height:340px;background:var(--sc-ink);border-top:1px solid var(--sc-line);position:relative;display:none;flex-direction:column}
#terminalPanel.sc-studio.open{display:flex}
#terminalPanel.sc-studio #termResizer{position:absolute;top:-4px;left:0;right:0;height:8px;cursor:ns-resize;z-index:20}
#terminalPanel.sc-studio #termResizer:hover{background:var(--sc-grad);opacity:.75}
#scTermHead{height:36px;flex:0 0 36px;display:flex;align-items:center;gap:4px;padding:0 6px;background:linear-gradient(180deg,#0E1526,#0A0F1C);border-bottom:1px solid var(--sc-line)}
#scTermTabs{display:flex;align-items:stretch;gap:3px;overflow-x:auto;flex:1;min-width:0;height:100%;scrollbar-width:thin}
.sc-tab{display:flex;align-items:center;gap:7px;padding:0 9px;height:28px;margin-top:4px;border-radius:7px 7px 0 0;background:#0B1120;border:1px solid var(--sc-line);border-bottom:none;color:var(--sc-dim);font:500 11.5px/1 var(--font-ui,sans-serif);cursor:pointer;white-space:nowrap;flex:0 0 auto;transition:background .14s,color .14s,box-shadow .14s}
.sc-tab:hover{background:#141E36;color:var(--sc-txt)}
.sc-tab.on{background:var(--sc-surf2);color:var(--sc-txt);box-shadow:inset 0 2px 0 0 var(--sc-cyan),0 0 18px -6px var(--sc-cyan)}
.sc-tab .dot{width:6px;height:6px;border-radius:50%;background:var(--sc-lime);box-shadow:0 0 7px var(--sc-lime)}
.sc-tab.dead .dot{background:var(--sc-bad);box-shadow:0 0 7px var(--sc-bad)}
.sc-tab .nm{max-width:130px;overflow:hidden;text-overflow:ellipsis}
.sc-tab .cl{opacity:.45;font-size:13px;line-height:1}
.sc-tab .cl:hover{opacity:1;color:var(--sc-bad)}
.sc-btn{background:#101A2E;border:1px solid var(--sc-line);color:var(--sc-dim);border-radius:7px;height:26px;min-width:26px;padding:0 8px;font:600 12px/1 var(--font-ui,sans-serif);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:5px;transition:all .14s}
.sc-btn:hover{color:var(--sc-txt);border-color:var(--sc-line2);background:#16223C}
.sc-btn:active{transform:translateY(1px)}
.sc-btn.pri{background:var(--sc-grad);border:none;color:#04070F;font-weight:700}
.sc-btn.pri:hover{filter:brightness(1.12)}
.sc-btn.dgr:hover{color:var(--sc-bad);border-color:var(--sc-bad)}
.sc-btn.on{color:var(--sc-cyan);border-color:var(--sc-cyan);box-shadow:0 0 14px -5px var(--sc-cyan)}
.sc-sp{flex:1}
#scTermBody{flex:1;display:flex;min-height:0}
#terminalPanel.sc-studio #xtermContainer{flex:1;position:relative;min-width:0;padding:0;overflow:hidden}
.sc-term{position:absolute;inset:0;padding:6px 4px 6px 8px;display:none}
.sc-term.on{display:block}
.sc-term .sc-scan{position:absolute;inset:0;pointer-events:none;z-index:6;opacity:0;background:repeating-linear-gradient(180deg,rgba(0,0,0,.34) 0 1px,transparent 1px 3px)}
.sc-term .sc-vig{position:absolute;inset:0;pointer-events:none;z-index:5;background:radial-gradient(120% 100% at 50% 0%,transparent 55%,rgba(0,0,0,.45) 100%)}
#scRail{flex:0 0 252px;width:252px;background:linear-gradient(180deg,#0B1120,#080D18);border-left:1px solid var(--sc-line);overflow-y:auto;overflow-x:hidden;padding:8px 10px 14px}
#scRail::-webkit-scrollbar{width:9px}
#scRail::-webkit-scrollbar-track{background:#070C16}
#scRail::-webkit-scrollbar-thumb{background:linear-gradient(180deg,#22D3EE,#8B5CF6);border-radius:9px;border:2px solid #070C16}
#scRail::-webkit-scrollbar-thumb:hover{background:linear-gradient(180deg,#67E8F9,#F0ABFC)}
#scRail{scrollbar-width:thin;scrollbar-color:#3B82F6 #070C16}
.sc-rail-h{display:flex;align-items:center;gap:7px;margin:2px 0 10px}
.sc-rail-h b{font:800 11px/1 var(--font-ui,sans-serif);letter-spacing:.14em;text-transform:uppercase;background:var(--sc-grad);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.sc-rail-h i{flex:1;height:1px;background:linear-gradient(90deg,var(--sc-line2),transparent)}
.sc-grp{margin-bottom:11px;padding:8px 9px;border:1px solid var(--sc-line);border-radius:9px;background:#0A1020}
.sc-grp>h4{margin:0 0 7px;font:700 9.5px/1 var(--font-ui,sans-serif);letter-spacing:.13em;text-transform:uppercase;color:var(--sc-dim)}
.sc-ctl{margin-bottom:8px}
.sc-ctl:last-child{margin-bottom:0}
.sc-ctl .lb{display:flex;justify-content:space-between;align-items:center;font:500 11px/1.3 var(--font-ui,sans-serif);color:var(--sc-txt);margin-bottom:4px;gap:6px}
.sc-ctl .vl{font:600 10px/1 var(--font-mono,monospace);color:var(--sc-cyan);background:#0D1830;border:1px solid var(--sc-line);border-radius:5px;padding:3px 5px;white-space:nowrap}
.sc-ctl input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:16px;background:transparent;cursor:pointer;display:block}
.sc-ctl input[type=range]::-webkit-slider-runnable-track{height:5px;border-radius:5px;background:linear-gradient(90deg,#22D3EE,#8B5CF6,#F0ABFC);box-shadow:inset 0 0 0 1px rgba(255,255,255,.07)}
.sc-ctl input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;margin-top:-4.5px;border-radius:50%;background:#EAF6FF;border:2px solid #0A1020;box-shadow:0 0 10px -1px #22D3EE;transition:transform .12s}
.sc-ctl input[type=range]:hover::-webkit-slider-thumb{transform:scale(1.18)}
.sc-ctl input[type=range]::-moz-range-track{height:5px;border-radius:5px;background:linear-gradient(90deg,#22D3EE,#8B5CF6,#F0ABFC)}
.sc-ctl input[type=range]::-moz-range-thumb{width:13px;height:13px;border-radius:50%;background:#EAF6FF;border:2px solid #0A1020}
.sc-ctl select{width:100%;background:#0D1830;border:1px solid var(--sc-line);color:var(--sc-txt);border-radius:6px;padding:5px 6px;font:500 11px/1 var(--font-ui,sans-serif);outline:none;cursor:pointer}
.sc-ctl select:focus{border-color:var(--sc-cyan)}
.sc-tg{display:flex;align-items:center;justify-content:space-between;gap:8px;font:500 11px/1.3 var(--font-ui,sans-serif);color:var(--sc-txt);cursor:pointer;padding:2px 0}
.sc-sw{width:32px;height:17px;border-radius:9px;background:#1B2740;border:1px solid var(--sc-line);position:relative;flex:0 0 32px;transition:background .16s,border-color .16s}
.sc-sw::after{content:"";position:absolute;top:1.5px;left:2px;width:12px;height:12px;border-radius:50%;background:#63748F;transition:left .16s,background .16s}
.sc-tg.on .sc-sw{background:linear-gradient(90deg,#22D3EE,#8B5CF6);border-color:transparent}
.sc-tg.on .sc-sw::after{left:16px;background:#04070F}
.sc-acts{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.sc-acts .sc-btn{width:100%;height:28px;font-size:11px}
.sc-acts .wide{grid-column:1/-1}
#scTermFoot{flex:0 0 24px;height:24px;display:flex;align-items:center;gap:10px;padding:0 10px;background:#080D18;border-top:1px solid var(--sc-line);font:500 10.5px/1 var(--font-mono,monospace);color:var(--sc-dim);overflow:hidden;white-space:nowrap}
#scTermFoot b{color:var(--sc-cyan);font-weight:600}
#scTermFoot .chip{padding:2px 6px;border-radius:5px;background:#0F1A30;border:1px solid var(--sc-line)}
#runPanel.sc-run{height:230px;background:var(--sc-ink);border-top:1px solid var(--sc-line);display:none;flex-direction:column}
#runPanel.sc-run.open{display:flex}
#runPanel.sc-run #runOutput{flex:1;overflow:auto;padding:9px 12px;font:12px/1.55 var(--font-mono,monospace);color:#CFE0F5;white-space:pre-wrap;background:transparent}
#runPanel.sc-run #runOutput::-webkit-scrollbar{width:9px}
#runPanel.sc-run #runOutput::-webkit-scrollbar-track{background:#070C16}
#runPanel.sc-run #runOutput::-webkit-scrollbar-thumb{background:linear-gradient(180deg,#22D3EE,#8B5CF6);border-radius:9px;border:2px solid #070C16}
#scRunBar{flex:0 0 40px;display:flex;align-items:center;gap:6px;padding:0 8px;background:#0A1020;border-top:1px solid var(--sc-line)}
#scRunIn{flex:1;min-width:0;height:28px;background:#060B16;border:1px solid var(--sc-line);border-radius:7px;color:var(--sc-txt);padding:0 10px;font:12px/1 var(--font-mono,monospace);outline:none}
#scRunIn:focus{border-color:var(--sc-cyan);box-shadow:0 0 0 3px rgba(34,211,238,.12)}
#scRunIn:disabled{opacity:.45}
.sc-state{padding:3px 8px;border-radius:20px;font:700 9.5px/1 var(--font-ui,sans-serif);letter-spacing:.1em;text-transform:uppercase;border:1px solid var(--sc-line);color:var(--sc-dim)}
.sc-state.run{color:#04070F;background:linear-gradient(90deg,#A3E635,#22D3EE);border-color:transparent;animation:scPulse 1.4s ease-in-out infinite}
.sc-state.ok{color:var(--sc-ok);border-color:var(--sc-ok)}
.sc-state.bad{color:var(--sc-bad);border-color:var(--sc-bad)}
@keyframes scPulse{0%,100%{filter:brightness(1)}50%{filter:brightness(1.35)}}
#scWatchBar{display:none;align-items:center;gap:8px;padding:7px 12px;background:linear-gradient(90deg,rgba(251,191,36,.16),rgba(251,113,133,.10));border-bottom:1px solid rgba(251,191,36,.4);font:500 11.5px/1.3 var(--font-ui,sans-serif);color:#FFE7B0;flex:0 0 auto}
#scWatchBar.on{display:flex}
.sc-modal{position:fixed;inset:0;background:rgba(3,6,14,.76);backdrop-filter:blur(7px);z-index:4200;display:none;align-items:center;justify-content:center;padding:24px}
.sc-modal.on{display:flex}
.sc-box{width:min(980px,94vw);max-height:86vh;display:flex;flex-direction:column;background:linear-gradient(180deg,#0C1424,#080E1B);border:1px solid var(--sc-line2);border-radius:14px;box-shadow:0 30px 90px rgba(0,0,0,.75),0 0 0 1px rgba(34,211,238,.09);overflow:hidden}
.sc-box header{display:flex;align-items:center;gap:10px;padding:13px 16px;border-bottom:1px solid var(--sc-line);background:#0A1120}
.sc-box header h3{margin:0;font:700 13px/1 var(--font-ui,sans-serif);color:var(--sc-txt)}
.sc-box header .tag{font:600 10px/1 var(--font-mono,monospace);padding:4px 7px;border-radius:6px;background:#0F1A30;border:1px solid var(--sc-line);color:var(--sc-cyan)}
.sc-box .body{flex:1;min-height:0;overflow:auto;padding:14px 16px}
.sc-box .body::-webkit-scrollbar{width:10px}
.sc-box .body::-webkit-scrollbar-track{background:#070C16}
.sc-box .body::-webkit-scrollbar-thumb{background:linear-gradient(180deg,#22D3EE,#8B5CF6);border-radius:10px;border:2px solid #070C16}
.sc-box footer{display:flex;gap:8px;align-items:center;padding:12px 16px;border-top:1px solid var(--sc-line);background:#0A1120}
.sc-diff{font:11.5px/1.6 var(--font-mono,monospace);white-space:pre;border-radius:9px;overflow:hidden;border:1px solid var(--sc-line)}
.sc-diff div{padding:1px 12px}
.sc-diff .a{background:rgba(163,230,53,.13);color:#CFF59A}
.sc-diff .d{background:rgba(251,113,133,.13);color:#FFC2CC}
.sc-diff .s{color:#8FA3C2}
.sc-diff .h{background:#0F1A30;color:var(--sc-cyan);padding:5px 12px;font-weight:700}
#scSearch .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px}
#scSearch input[type=text]{flex:1;min-width:170px;background:#060B16;border:1px solid var(--sc-line);color:var(--sc-txt);border-radius:8px;padding:8px 11px;font:12.5px/1 var(--font-ui,sans-serif);outline:none}
#scSearch input[type=text]:focus{border-color:var(--sc-cyan);box-shadow:0 0 0 3px rgba(34,211,238,.12)}
.sc-chip{padding:5px 10px;border-radius:20px;border:1px solid var(--sc-line);background:#0D1830;color:var(--sc-dim);font:600 10.5px/1 var(--font-ui,sans-serif);cursor:pointer;user-select:none;transition:all .14s}
.sc-chip:hover{color:var(--sc-txt);border-color:var(--sc-line2)}
.sc-chip.on{background:var(--sc-grad);color:#04070F;border-color:transparent}
.sc-file{margin-bottom:9px;border:1px solid var(--sc-line);border-radius:9px;overflow:hidden;background:#0A1020}
.sc-file>h5{margin:0;padding:7px 11px;background:#0F1A30;font:600 11px/1.3 var(--font-mono,monospace);color:var(--sc-cyan);display:flex;gap:8px;align-items:center;cursor:pointer}
.sc-file>h5 span{margin-left:auto;color:var(--sc-dim);font-size:10px}
.sc-hit{padding:4px 11px;font:11.5px/1.5 var(--font-mono,monospace);color:#B9C9E2;cursor:pointer;display:flex;gap:9px;border-top:1px solid rgba(30,42,69,.6)}
.sc-hit:hover{background:#111C33;color:#EAF3FF}
.sc-hit i{color:var(--sc-dim);font-style:normal;min-width:38px;text-align:right;flex:0 0 auto}
.sc-hit em{font-style:normal;background:rgba(251,191,36,.28);color:#FFE9AE;border-radius:3px;padding:0 2px}
.sc-empty{padding:34px;text-align:center;color:var(--sc-dim);font:12px/1.6 var(--font-ui,sans-serif)}
.sc-ai-code{position:relative;margin:8px 0;border:1px solid var(--sc-line);border-radius:9px;overflow:hidden;background:#060B16}
.sc-ai-code .hd{display:flex;align-items:center;gap:6px;padding:5px 8px;background:#0F1A30;border-bottom:1px solid var(--sc-line);font:600 10px/1 var(--font-mono,monospace);color:var(--sc-dim)}
.sc-ai-code pre{margin:0;padding:9px 11px;overflow:auto;font:11.5px/1.55 var(--font-mono,monospace);color:#CFE0F5;white-space:pre}
.sc-ai-code pre::-webkit-scrollbar{height:8px;width:8px}
.sc-ai-code pre::-webkit-scrollbar-thumb{background:#3B82F6;border-radius:8px}
.sc-caret{display:inline-block;width:7px;height:13px;background:var(--sc-cyan);vertical-align:-2px;animation:scBlink .9s steps(2) infinite;box-shadow:0 0 9px var(--sc-cyan)}
@keyframes scBlink{0%,50%{opacity:1}51%,100%{opacity:0}}
#scToastWrap{position:fixed;right:18px;bottom:56px;z-index:4600;display:flex;flex-direction:column;gap:8px;pointer-events:none}
.sc-toast{pointer-events:auto;display:flex;align-items:center;gap:10px;min-width:250px;max-width:390px;padding:10px 13px;border-radius:10px;background:linear-gradient(180deg,#0E1728,#0A1120);border:1px solid var(--sc-line2);border-left:3px solid var(--sc-cyan);color:var(--sc-txt);font:500 12px/1.45 var(--font-ui,sans-serif);box-shadow:0 14px 40px rgba(0,0,0,.6);animation:scIn .22s cubic-bezier(.2,.9,.3,1.3)}
.sc-toast.ok{border-left-color:var(--sc-ok)}.sc-toast.bad{border-left-color:var(--sc-bad)}
.sc-toast.warn{border-left-color:var(--sc-warn)}
.sc-toast button{margin-left:auto}
@keyframes scIn{from{opacity:0;transform:translateX(26px) scale(.96)}to{opacity:1;transform:none}}
#scMute{width:30px;height:30px;border-radius:7px;background:#101A2E;border:1px solid var(--sc-line);color:var(--sc-cyan);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;font-size:14px;transition:all .15s}
#scMute:hover{border-color:var(--sc-cyan);box-shadow:0 0 14px -4px var(--sc-cyan)}
#scMute.off{color:var(--sc-dim);background:#0B1120}
@media (max-width:880px){
  #scTermBody{flex-direction:column}
  #scRail{flex:0 0 auto;width:auto;max-height:168px;border-left:none;border-top:1px solid var(--sc-line);display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:8px;align-content:start}
  .sc-rail-h{grid-column:1/-1}
  #terminalPanel.sc-studio{height:420px}
}
'''

# ══════════════════════════════════════════════════════════════════════
#  STUDIO JS
# ══════════════════════════════════════════════════════════════════════

STUDIO_JS = r'''
(function(){
'use strict';
if (window.__SC_STUDIO_008__) return;
window.__SC_STUDIO_008__ = true;

var MARK = 'sc-studio-008';
function API(){ return (window.pywebview && window.pywebview.api) || null; }
function el(i){ return document.getElementById(i); }
function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function mk(t,c,h){ var n=document.createElement(t); if(c)n.className=c; if(h!=null)n.innerHTML=h; return n; }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }
function rnd(a,b){ return a+Math.random()*(b-a); }
function pick(a){ return a[Math.floor(Math.random()*a.length)]; }

/* ---------- ses ---------- */
var Sound = {
  on:true, ctx:null,
  boot:function(){ if(this.ctx) return; try{ var C=window.AudioContext||window.webkitAudioContext; if(C) this.ctx=new C(); }catch(e){} },
  play:function(k){
    if(!this.on) return; this.boot(); var c=this.ctx; if(!c) return;
    if(c.state==='suspended'){ try{c.resume();}catch(e){} }
    var S={tick:[1500,.014,.022,'square'],tab:[680,.055,.05,'triangle'],
      open:[430,.12,.06,'sine'],close:[300,.12,.055,'sine'],
      bell:[900,.26,.075,'sine'],start:[500,.16,.06,'triangle'],
      done:[720,.22,.06,'sine'],err:[140,.24,.07,'sawtooth'],
      apply:[620,.17,.06,'triangle'],find:[840,.09,.045,'sine']}[k]||[600,.05,.04,'sine'];
    try{
      var t=c.currentTime, g=c.createGain(), o=c.createOscillator();
      o.type=S[3]; o.frequency.setValueAtTime(S[0],t);
      if(k==='start'||k==='done'||k==='apply') o.frequency.exponentialRampToValueAtTime(S[0]*1.55,t+S[1]);
      if(k==='close'||k==='err') o.frequency.exponentialRampToValueAtTime(S[0]*.55,t+S[1]);
      g.gain.setValueAtTime(.0001,t);
      g.gain.exponentialRampToValueAtTime(S[2],t+.006);
      g.gain.exponentialRampToValueAtTime(.0001,t+S[1]);
      o.connect(g); g.connect(c.destination); o.start(t); o.stop(t+S[1]+.03);
    }catch(e){}
  }
};

/* ---------- toast + undo ---------- */
function wrap(){ var w=el('scToastWrap'); if(!w){ w=mk('div'); w.id='scToastWrap'; document.body.appendChild(w); } return w; }
function toast(msg,kind,undo){
  var w=wrap(), n=mk('div','sc-toast '+(kind||''));
  n.appendChild(mk('span',null,esc(msg)));
  if(undo){ var b=mk('button','sc-btn','Geri al'); b.onclick=function(){ undo(); n.remove(); }; n.appendChild(b); }
  w.appendChild(n);
  var life=undo?7000:3000;
  setTimeout(function(){ n.style.transition='opacity .2s,transform .2s'; n.style.opacity='0'; n.style.transform='translateX(22px)'; setTimeout(function(){ n.remove(); },220); },life);
  try{ if(window.toast && kind) window.toast(msg,kind==='bad'?'error':kind==='ok'?'success':'info',2200); }catch(e){}
}
var UNDO=[];
function pushUndo(label,fn){ UNDO.push({label:label,fn:fn}); if(UNDO.length>25) UNDO.shift(); toast(label,'warn',function(){ var u=UNDO.pop(); if(u){ u.fn(); toast('Geri alındı: '+u.label,'ok'); } }); }
function doUndo(){ var u=UNDO.pop(); if(!u){ toast('Geri alınacak işlem yok'); return; } u.fn(); Sound.play('close'); toast('Geri alındı: '+u.label,'ok'); }

/* ---------- paletler ---------- */
var PAL={
 splash:{n:'Splash',bg:'#05070E',fg:'#DDE7F5',cu:'#22D3EE',se:'#1E3A5F',
  a:['#0A0F1C','#FB7185','#A3E635','#FBBF24','#3B82F6','#F0ABFC','#22D3EE','#DDE7F5','#4A5A78','#FF9AAE','#C4F06A','#FFD479','#7DA9FF','#F7C6FF','#67E8F9','#FFFFFF']},
 abyss:{n:'Abyss',bg:'#020617',fg:'#CBD5F5',cu:'#60A5FA',se:'#1E3A8A',
  a:['#0B1220','#F87171','#4ADE80','#FACC15','#60A5FA','#A78BFA','#38BDF8','#E2E8F0','#475569','#FCA5A5','#86EFAC','#FDE68A','#93C5FD','#C4B5FD','#7DD3FC','#F8FAFC']},
 acid:{n:'Acid',bg:'#07100A',fg:'#DCFCE7',cu:'#A3E635',se:'#14532D',
  a:['#0C1A10','#FB7185','#A3E635','#FDE047','#34D399','#F0ABFC','#2DD4BF','#E7FBE9','#3F6B4C','#FFA8B6','#D9F99D','#FEF08A','#6EE7B7','#F7C6FF','#5EEAD4','#FFFFFF']},
 vapor:{n:'Vapor',bg:'#0D0620',fg:'#F3E8FF',cu:'#F0ABFC',se:'#4C1D95',
  a:['#170B2E','#FF6B9D','#B6FF6A','#FFD166','#8B5CF6','#F0ABFC','#22D3EE','#F3E8FF','#6D4B9E','#FF9EC0','#D4FF9E','#FFE29A','#B39CFF','#F8D3FF','#7BE7F7','#FFFFFF']},
 ember:{n:'Ember',bg:'#120806',fg:'#FFE9D6',cu:'#FBBF24',se:'#7C2D12',
  a:['#1C0F0A','#FB7185','#A3E635','#FBBF24','#F97316','#F472B6','#22D3EE','#FFE9D6','#7A4A32','#FFA1AF','#C9F27E','#FFD98A','#FDBA74','#F9A8D4','#67E8F9','#FFFFFF']},
 paper:{n:'Paper',bg:'#F7F9FC',fg:'#16233A',cu:'#0EA5E9',se:'#BAE6FD',
  a:['#16233A','#DC2626','#15803D','#B45309','#1D4ED8','#9333EA','#0891B2','#E2E8F0','#64748B','#EF4444','#22C55E','#D97706','#3B82F6','#A855F7','#06B6D4','#FFFFFF']}
};
var FONTS=["'JetBrains Mono', Consolas, monospace","'Fira Code', Consolas, monospace","'Cascadia Code', Consolas, monospace","Consolas, monospace","'Courier New', monospace"];
var DEF={fontSize:13,letterSpacing:0,lineHeight:1.18,fontFamily:FONTS[0],cursorStyle:'bar',cursorBlink:true,cursorWidth:2,scrollback:3000,palette:'splash',opacity:1,blur:0,glow:.32,scan:false,ligatures:true,bell:true,sound:true};
var CFG=JSON.parse(JSON.stringify(DEF));
var TABS=[], ACT=null, SEQ=0, STYLE=null, STREAMS={}, WATCH_T=null, LAST_TREE=0;

function themeOf(){
  var p=PAL[CFG.palette]||PAL.splash, a=p.a;
  function rgba(h,o){ var v=h.replace('#',''); var r=parseInt(v.substr(0,2),16),g=parseInt(v.substr(2,2),16),b=parseInt(v.substr(4,2),16); return 'rgba('+r+','+g+','+b+','+o+')'; }
  return {background:rgba(p.bg,CFG.opacity),foreground:p.fg,cursor:p.cu,cursorAccent:p.bg,
    selectionBackground:p.se,black:a[0],red:a[1],green:a[2],yellow:a[3],blue:a[4],magenta:a[5],cyan:a[6],white:a[7],
    brightBlack:a[8],brightRed:a[9],brightGreen:a[10],brightYellow:a[11],brightBlue:a[12],brightMagenta:a[13],brightCyan:a[14],brightWhite:a[15]};
}
function css(){
  if(!STYLE){ STYLE=mk('style'); STYLE.id='scDyn'; document.head.appendChild(STYLE); }
  var g=(CFG.glow*9).toFixed(2);
  STYLE.textContent='#xtermContainer .xterm-rows,#xtermContainer .xterm-rows span{text-shadow:0 0 '+g+'px currentColor;font-variant-ligatures:'+(CFG.ligatures?'normal':'none')+'}'+
   '#xtermContainer .sc-scan{opacity:'+(CFG.scan?0.55:0)+'}'+
   '#xtermContainer .sc-term{backdrop-filter:blur('+CFG.blur+'px);-webkit-backdrop-filter:blur('+CFG.blur+'px)}';
}
function applyCfg(save){
  css();
  TABS.forEach(function(t){
    if(!t.term) return;
    try{
      t.term.options.fontSize=CFG.fontSize;
      t.term.options.fontFamily=CFG.fontFamily;
      t.term.options.letterSpacing=CFG.letterSpacing;
      t.term.options.lineHeight=CFG.lineHeight;
      t.term.options.cursorStyle=CFG.cursorStyle;
      t.term.options.cursorBlink=CFG.cursorBlink;
      t.term.options.cursorWidth=CFG.cursorWidth;
      t.term.options.scrollback=CFG.scrollback;
      t.term.options.theme=themeOf();
    }catch(e){}
    fit(t);
  });
  Sound.on=CFG.sound;
  var mb=el('scMute'); if(mb){ mb.classList.toggle('off',!CFG.sound); mb.textContent=CFG.sound?'🔊':'🔇'; mb.title=CFG.sound?'Sesi kapat':'Sesi aç'; }
  if(save!==false){ var a=API(); if(a&&a.studio_ayar_kaydet) a.studio_ayar_kaydet(CFG); }
}

/* ---------- terminal cekirdegi ---------- */
function panel(){ return el('terminalPanel'); }
function stack(){ return el('xtermContainer'); }
function find(id){ for(var i=0;i<TABS.length;i++) if(TABS[i].id===id) return TABS[i]; return null; }
function act(){ return find(ACT); }
function curCwd(){
  try{ var tb=aktifTab(); if(tb&&tb.path) return String(tb.path).replace(/[\\/][^\\/]*$/,''); }catch(e){}
  return window._cwd||'';
}
function shell(){
  var p=panel(); if(!p) return null;
  if(p.dataset.sc==='1') return p;
  p.dataset.sc='1'; p.classList.add('sc-studio');
  p.innerHTML='<div id="termResizer" title="Sürükle: yükseklik"></div>'+
   '<div id="scTermHead"><div id="scTermTabs"></div>'+
   '<button class="sc-btn" id="scTermNew" title="Yeni terminal (Ctrl+Shift+T)">+</button><span class="sc-sp"></span>'+
   '<button class="sc-btn" id="scTermRand" title="Rastgele görünüm">🎲</button>'+
   '<button class="sc-btn" id="scTermClear" title="Temizle">⌫</button>'+
   '<button class="sc-btn dgr" id="scTermClose" title="Terminali kapat">✕</button></div>'+
   '<div id="scTermBody"><div id="xtermContainer"></div><div id="scRail"></div></div>'+
   '<div id="scTermFoot"><span class="chip" id="scFcwd">—</span><span class="chip" id="scFsize">—</span>'+
   '<span class="chip" id="scFpal">—</span><span class="sc-sp"></span><span id="scFhint">Ctrl+Shift+T yeni · Ctrl+Shift+W kapat</span></div>';
  el('scTermNew').onclick=function(){ newTerm(curCwd()); };
  el('scTermClear').onclick=function(){ var t=act(); if(t&&t.term) t.term.clear(); Sound.play('tick'); };
  el('scTermClose').onclick=function(){ closeTab(ACT); };
  el('scTermRand').onclick=randomize;
  buildRail();
  var rz=el('scTermHead').previousElementSibling, drag=false, y0=0, h0=0;
  rz.addEventListener('mousedown',function(e){ drag=true; y0=e.clientY; h0=p.offsetHeight; document.body.style.userSelect='none'; e.preventDefault(); });
  document.addEventListener('mousemove',function(e){ if(!drag) return; p.style.height=clamp(h0-(e.clientY-y0),160,window.innerHeight*.82)+'px'; fitAll(); });
  document.addEventListener('mouseup',function(){ if(drag){ drag=false; document.body.style.userSelect=''; fitAll(); } });
  return p;
}
function renderTabs(){
  var c=el('scTermTabs'); if(!c) return;
  c.innerHTML=TABS.map(function(t){
    return '<div class="sc-tab'+(t.id===ACT?' on':'')+(t.dead?' dead':'')+'" data-id="'+t.id+'">'+
      '<span class="dot"></span><span class="nm">'+esc(t.name)+'</span><span class="cl" data-cl="'+t.id+'">✕</span></div>';
  }).join('');
  Array.prototype.forEach.call(c.querySelectorAll('.sc-tab'),function(n){
    n.onclick=function(e){ if(e.target.dataset.cl){ closeTab(e.target.dataset.cl); return; } activate(n.dataset.id); };
    n.ondblclick=function(){ var t=find(n.dataset.id); if(!t) return; var v=prompt('Terminal adı:',t.name); if(v){ t.name=v; renderTabs(); } };
  });
  var t=act();
  var f1=el('scFcwd'), f2=el('scFsize'), f3=el('scFpal');
  if(f1) f1.textContent=t?(t.cwd||'—'):'—';
  if(f2) f2.textContent=t&&t.term?(t.term.cols+'×'+t.term.rows):'—';
  if(f3) f3.textContent=(PAL[CFG.palette]||PAL.splash).n;
}
function fit(t){
  if(!t||!t.term||!t.host) return;
  try{
    var core=t.term._core, d=core&&core._renderService&&core._renderService.dimensions;
    var cols=0,rows=0;
    if(d&&d.css&&d.css.cell.width>0&&d.css.cell.height>0){
      var sb=(core.viewport&&core.viewport.scrollBarWidth)||0;
      var w=t.host.clientWidth-12-sb, h=t.host.clientHeight-12;
      cols=Math.max(2,Math.floor(w/d.css.cell.width));
      rows=Math.max(1,Math.floor(h/d.css.cell.height));
    }
    if(!cols||!rows){ cols=Math.max(20,Math.floor((t.host.clientWidth-14)/(CFG.fontSize*.62))); rows=Math.max(5,Math.floor((t.host.clientHeight-14)/(CFG.fontSize*CFG.lineHeight))); }
    if(cols>0&&rows>0&&(t.term.cols!==cols||t.term.rows!==rows)) t.term.resize(cols,rows);
  }catch(e){}
}
function fitAll(){ TABS.forEach(fit); renderTabs(); }
function mount(t){
  if(typeof Terminal==='undefined'){ fallback(t); return; }
  try{
    var term=new Terminal({fontSize:CFG.fontSize,fontFamily:CFG.fontFamily,letterSpacing:CFG.letterSpacing,
      lineHeight:CFG.lineHeight,cursorStyle:CFG.cursorStyle,cursorBlink:CFG.cursorBlink,cursorWidth:CFG.cursorWidth,
      scrollback:CFG.scrollback,theme:themeOf(),allowTransparency:true,allowProposedApi:true,macOptionIsMeta:true});
    t.term=term; term.open(t.host);
    term.onData(function(d){ var a=API(); if(a) a.terminal_yaz(t.id,d); });
    term.onResize(function(s){ var a=API(); if(a) a.terminal_yeniden_boyutlandir(t.id,s.rows,s.cols); renderTabs(); });
    term.onBell(function(){ if(CFG.bell) Sound.play('bell'); t.host.animate([{filter:'brightness(1.7)'},{filter:'brightness(1)'}],{duration:170}); });
    term.attachCustomKeyEventHandler(function(e){
      if(e.type==='keydown'&&e.ctrlKey&&e.shiftKey&&(e.key==='C'||e.key==='c')){ if(term.hasSelection()){ navigator.clipboard.writeText(term.getSelection()); return false; } }
      if(e.type==='keydown'&&e.ctrlKey&&e.shiftKey&&(e.key==='V'||e.key==='v')){ navigator.clipboard.readText().then(function(x){ term.paste(x); }); return false; }
      return true;
    });
    if(window.ResizeObserver){ t.ro=new ResizeObserver(function(){ fit(t); }); t.ro.observe(t.host); }
    fit(t); setTimeout(function(){ fit(t); try{term.focus();}catch(e){} },90);
    css();
  }catch(e){ fallback(t); }
}
function fallback(t){
  t.host.innerHTML='<div style="padding:8px;color:#FBBF24;font:12px monospace">Basit terminal (xterm yok)</div>'+
    '<pre class="scfb" style="position:absolute;top:32px;bottom:34px;left:8px;right:8px;overflow:auto;margin:0;color:#CFE0F5;font:12px monospace;white-space:pre-wrap"></pre>'+
    '<input class="scfbi" placeholder="Komut + Enter" style="position:absolute;bottom:6px;left:8px;right:8px;height:26px;background:#060B16;border:1px solid #1E2A45;color:#DDE7F5;border-radius:6px;padding:0 8px;font:12px monospace;outline:none">';
  t.fb=t.host.querySelector('.scfb');
  var i=t.host.querySelector('.scfbi');
  i.addEventListener('keydown',function(e){ if(e.key==='Enter'){ var a=API(); if(a) a.terminal_yaz(t.id,i.value+'\r'); i.value=''; } });
}
function newTerm(cwd,name){
  var a=API(); if(!a||!a.terminal_ac){ toast('Terminal API hazır değil','bad'); return; }
  shell();
  var id='s'+(++SEQ)+Date.now().toString(36);
  var host=mk('div','sc-term'); host.id='scTerm_'+id;
  host.appendChild(mk('div','sc-vig')); host.appendChild(mk('div','sc-scan'));
  stack().appendChild(host);
  var t={id:id,name:name||('Terminal '+(TABS.length+1)),cwd:cwd||curCwd(),host:host,term:null,dead:false};
  TABS.push(t); activate(id); openPanel();
  a.terminal_ac(t.cwd,null,t.name).then(function(r){
    if(!r||!r.ok){ t.dead=true; renderTabs(); Sound.play('err'); toast((r&&r.hata)||'PTY başlatılamadı','bad'); return; }
    t.pid=r.pid; mount(t); renderTabs(); Sound.play('open');
  }).catch(function(e){ t.dead=true; renderTabs(); toast(String(e),'bad'); });
}
function activate(id){
  ACT=id;
  TABS.forEach(function(t){ t.host.classList.toggle('on',t.id===id); });
  var t=act(); if(t&&t.term){ fit(t); try{t.term.focus();}catch(e){} }
  renderTabs(); Sound.play('tab');
}
function closeTab(id){
  var t=find(id); if(!t) return;
  var a=API(); if(a) a.terminal_kapat(t.id);
  var snap={cwd:t.cwd,name:t.name};
  try{ if(t.ro) t.ro.disconnect(); }catch(e){}
  try{ if(t.term) t.term.dispose(); }catch(e){}
  t.host.remove();
  var i=TABS.indexOf(t); TABS.splice(i,1);
  Sound.play('close');
  pushUndo('Terminal kapatıldı ('+snap.name+')',function(){ newTerm(snap.cwd,snap.name); });
  if(!TABS.length){ ACT=null; panel().classList.remove('open'); }
  else activate(TABS[Math.max(0,i-1)].id);
}
function openPanel(){ var p=shell(); if(p){ p.classList.add('open'); setTimeout(fitAll,60); } }

/* ---------- kontrol reyonu ---------- */
var CTRL=[
 {g:'Tipografi',k:'fontFamily',t:'sel',l:'Yazı tipi',o:FONTS.map(function(f,i){return [f,['JetBrains Mono','Fira Code','Cascadia Code','Consolas','Courier New'][i]];})},
 {g:'Tipografi',k:'fontSize',t:'rng',l:'Punto',mn:8,mx:28,st:.5,u:'px'},
 {g:'Tipografi',k:'letterSpacing',t:'rng',l:'Harf aralığı',mn:-2,mx:6,st:.25,u:'px'},
 {g:'Tipografi',k:'lineHeight',t:'rng',l:'Satır yüksekliği',mn:1,mx:2,st:.02,u:'×'},
 {g:'Tipografi',k:'ligatures',t:'tg',l:'Ligature'},
 {g:'İmleç',k:'cursorStyle',t:'sel',l:'Biçim',o:[['bar','Çubuk'],['block','Blok'],['underline','Alt çizgi']]},
 {g:'İmleç',k:'cursorWidth',t:'rng',l:'Kalınlık',mn:1,mx:6,st:1,u:'px'},
 {g:'İmleç',k:'cursorBlink',t:'tg',l:'Yanıp sönsün'},
 {g:'Atmosfer',k:'palette',t:'sel',l:'Palet',o:Object.keys(PAL).map(function(k){return [k,PAL[k].n];})},
 {g:'Atmosfer',k:'opacity',t:'rng',l:'Zemin opaklığı',mn:.35,mx:1,st:.01,u:''},
 {g:'Atmosfer',k:'blur',t:'rng',l:'Arka plan blur',mn:0,mx:14,st:.5,u:'px'},
 {g:'Atmosfer',k:'glow',t:'rng',l:'Işıma',mn:0,mx:1,st:.02,u:''},
 {g:'Atmosfer',k:'scan',t:'tg',l:'CRT tarama çizgileri'},
 {g:'Davranış',k:'scrollback',t:'rng',l:'Geri kaydırma',mn:200,mx:20000,st:200,u:''},
 {g:'Davranış',k:'bell',t:'tg',l:'Zil sesi'},
 {g:'Davranış',k:'sound',t:'tg',l:'Arayüz sesi'}
];
function buildRail(){
  var r=el('scRail'); if(!r) return;
  var h='<div class="sc-rail-h"><b>Terminal Studio</b><i></i></div>', groups={};
  CTRL.forEach(function(c){ (groups[c.g]=groups[c.g]||[]).push(c); });
  Object.keys(groups).forEach(function(g){
    h+='<div class="sc-grp"><h4>'+esc(g)+'</h4>';
    groups[g].forEach(function(c){
      if(c.t==='rng'){
        h+='<div class="sc-ctl"><div class="lb"><span>'+esc(c.l)+'</span><span class="vl" id="scv_'+c.k+'"></span></div>'+
           '<input type="range" id="scc_'+c.k+'" min="'+c.mn+'" max="'+c.mx+'" step="'+c.st+'"></div>';
      } else if(c.t==='sel'){
        h+='<div class="sc-ctl"><div class="lb"><span>'+esc(c.l)+'</span></div><select id="scc_'+c.k+'">'+
           c.o.map(function(o){ return '<option value="'+esc(o[0])+'">'+esc(o[1])+'</option>'; }).join('')+'</select></div>';
      } else {
        h+='<div class="sc-ctl"><div class="sc-tg" id="scc_'+c.k+'"><span>'+esc(c.l)+'</span><span class="sc-sw"></span></div></div>';
      }
    });
    h+='</div>';
  });
  h+='<div class="sc-grp"><h4>Eylemler</h4><div class="sc-acts">'+
     '<button class="sc-btn" id="scReset">Sıfırla</button>'+
     '<button class="sc-btn" id="scRand">Rastgele</button>'+
     '<button class="sc-btn pri wide" id="scExport">Dışa aktar (JSON)</button>'+
     '<button class="sc-btn wide" id="scFonts">Fontları çevrimdışı yap</button>'+
     '</div></div>';
  r.innerHTML=h;
  CTRL.forEach(function(c){
    var n=el('scc_'+c.k); if(!n) return;
    if(c.t==='rng'){ n.oninput=function(){ CFG[c.k]=parseFloat(n.value); syncRail(); applyCfg(); }; }
    else if(c.t==='sel'){ n.onchange=function(){ CFG[c.k]=n.value; syncRail(); applyCfg(); Sound.play('tick'); }; }
    else { n.onclick=function(){ CFG[c.k]=!CFG[c.k]; syncRail(); applyCfg(); Sound.play('tick'); }; }
  });
  el('scReset').onclick=function(){ CFG=JSON.parse(JSON.stringify(DEF)); syncRail(); applyCfg(); toast('Studio sıfırlandı','ok'); };
  el('scRand').onclick=randomize;
  el('scExport').onclick=exportCfg;
  el('scFonts').onclick=function(){
    var a=API(); if(!a||!a.font_yerellestir) return;
    toast('Fontlar indiriliyor…');
    a.font_yerellestir().then(function(r){
      if(r&&r.ok){ Sound.play('done'); toast(r.files+' font yerelleştirildi. Yeniden başlat.','ok'); }
      else { Sound.play('err'); toast((r&&r.hata)||'Font indirilemedi','bad'); }
    });
  };
  syncRail();
}
function syncRail(){
  CTRL.forEach(function(c){
    var n=el('scc_'+c.k); if(!n) return;
    if(c.t==='rng'){ n.value=CFG[c.k]; var v=el('scv_'+c.k); if(v) v.textContent=(Math.round(CFG[c.k]*100)/100)+(c.u||''); }
    else if(c.t==='sel'){ n.value=CFG[c.k]; }
    else { n.classList.toggle('on',!!CFG[c.k]); }
  });
}
function randomize(){
  CFG.palette=pick(Object.keys(PAL));
  CFG.fontSize=Math.round(rnd(11,18)*2)/2;
  CFG.lineHeight=Math.round(rnd(1.05,1.45)*50)/50;
  CFG.letterSpacing=Math.round(rnd(-.5,1.5)*4)/4;
  CFG.glow=Math.round(rnd(0,.7)*50)/50;
  CFG.opacity=Math.round(rnd(.82,1)*100)/100;
  CFG.blur=Math.round(rnd(0,6)*2)/2;
  CFG.cursorStyle=pick(['bar','block','underline']);
  CFG.scan=Math.random()<.35;
  syncRail(); applyCfg(); Sound.play('apply'); toast('Yeni görünüm: '+(PAL[CFG.palette]||PAL.splash).n,'ok');
}
function exportCfg(){
  var data=JSON.stringify({studio:'splash-code',version:8,config:CFG},null,2);
  try{
    var b=new Blob([data],{type:'application/json'}), u=URL.createObjectURL(b), a=document.createElement('a');
    a.href=u; a.download='splash-terminal-studio.json'; a.click();
    setTimeout(function(){ URL.revokeObjectURL(u); },1500);
  }catch(e){}
  try{ navigator.clipboard.writeText(data); }catch(e){}
  Sound.play('done'); toast('Ayarlar indirildi ve panoya kopyalandı','ok');
}

/* ---------- global kopru ---------- */
window.termWrite=function(d,id){
  var t=find(id)||act();
  if(!t) return;
  if(t.term){ try{ t.term.write(d); }catch(e){} }
  else if(t.fb){ t.fb.textContent+=d; t.fb.scrollTop=t.fb.scrollHeight; }
};
window.termClosed=function(id){
  var t=find(id); if(!t) return;
  t.dead=true; renderTabs(); Sound.play('close');
  if(t.term){ try{ t.term.write('\r\n\x1b[38;5;244m[oturum kapandı — + ile yenisi]\x1b[0m\r\n'); }catch(e){} }
};
window.terminalToggle=function(){
  var st=window.settings||{};
  if((st.terminalMode||'internal')==='external'){ var a=API(); if(a&&a.harici_terminal_ac){ a.harici_terminal_ac(curCwd(),null); return; } }
  var p=shell(); if(!p) return;
  if(p.classList.contains('open')&&TABS.length){ p.classList.remove('open'); return; }
  openPanel(); if(!TABS.length) newTerm(curCwd());
};
window.initTerminal=function(){ openPanel(); if(!TABS.length) newTerm(curCwd()); };
window.terminalClose=function(){ if(TABS.length) closeTab(ACT); else panel().classList.remove('open'); };
window.terminalClear=function(){ var t=act(); if(t&&t.term) t.term.clear(); };
window._scFitTerm=fitAll;
var _treeAction=window.treeAction;
window.treeAction=function(act2){
  if(act2==='terminal'){
    var sp=(typeof selectedPath!=='undefined')?selectedPath:null;
    var dir=(sp&&sp.path)?(sp.is_dir?sp.path:String(sp.path).replace(/[\\/][^\\/]*$/,'')):curCwd();
    var m=el('contextMenu'); if(m) m.classList.remove('open');
    openPanel(); newTerm(dir); return;
  }
  return _treeAction?_treeAction.apply(this,arguments):undefined;
};

/* ---------- calistirma + stdin ---------- */
function runShell(){
  var p=el('runPanel'); if(!p||p.dataset.sc==='1') return p;
  p.dataset.sc='1'; p.classList.add('sc-run');
  var hd=el('runHeader');
  if(hd){ var s=mk('span','sc-state','hazır'); s.id='scRunState'; hd.insertBefore(s,hd.firstChild.nextSibling); }
  var bar=mk('div'); bar.id='scRunBar';
  bar.innerHTML='<input id="scRunIn" placeholder="Program girdisi (stdin) — Enter ile gönder" disabled>'+
    '<button class="sc-btn pri" id="scRunSend">Gönder</button>'+
    '<button class="sc-btn" id="scRunInt" title="Ctrl+C">^C</button>'+
    '<button class="sc-btn dgr" id="scRunKill" title="Durdur">■</button>';
  p.appendChild(bar);
  function send(){ var i=el('scRunIn'); if(!i||i.disabled) return; var a=API(); if(!a) return;
    a.run_stdin(i.value+'\n').then(function(r){ if(r&&r.ok){ appendRun(i.value+'\n'); i.value=''; Sound.play('tick'); } else toast((r&&r.hata)||'Gönderilemedi','bad'); }); }
  el('scRunSend').onclick=send;
  el('scRunIn').addEventListener('keydown',function(e){ if(e.key==='Enter'){ e.preventDefault(); send(); } });
  el('scRunInt').onclick=function(){ var a=API(); if(a) a.run_stdin('\x03'); };
  el('scRunKill').onclick=function(){ window.durdur(); };
  return p;
}
function appendRun(s){ var o=el('runOutput'); if(!o) return; o.textContent+=s; if(o.textContent.length>400000) o.textContent=o.textContent.slice(-300000); o.scrollTop=o.scrollHeight; }
function runState(k,txt){ var s=el('scRunState'); if(s){ s.className='sc-state'+(k?' '+k:''); s.textContent=txt; } var i=el('scRunIn'); if(i) i.disabled=(k!=='run'); if(k==='run'&&i) setTimeout(function(){ try{i.focus();}catch(e){} },60); }
window.scRunOut=function(s){ appendRun(s); };
window.runOutput=function(s){ appendRun(s); };
window.scRunDone=function(rc){
  appendRun('\n[çıkış kodu: '+(rc==null?'?':rc)+']\n');
  runState(rc===0?'ok':'bad',rc===0?'başarılı':'hata');
  Sound.play(rc===0?'done':'err');
};
window.runDone=function(){ runState('ok','bitti'); Sound.play('done'); };
window.durdur=function(){ var a=API(); if(!a) return; a.run_durdur().then(function(r){ if(r&&r.ok){ appendRun('\n[durduruldu]\n'); runState('bad','durduruldu'); Sound.play('close'); } else toast((r&&r.hata)||'Çalışan süreç yok'); }); };
window.calistir=function(){
  var tb=null; try{ tb=aktifTab(); }catch(e){}
  if(!tb){ toast('Dosya yok','warn'); return; }
  var a=API(); if(!a||!a.run_baslat){ toast('Çalıştırma API hazır değil','bad'); return; }
  var st=window.settings||{};
  var go=function(content){
    runShell(); var p=el('runPanel'); p.classList.add('open');
    el('runOutput').textContent=''; runState('run','çalışıyor'); Sound.play('start');
    var cwd=tb.path?String(tb.path).replace(/[\\/][^\\/]*$/,''):(window._cwd||'');
    a.run_baslat(tb.path||'',content,cwd).then(function(r){
      if(!r||!r.ok){ appendRun('\nHata: '+((r&&r.hata)||'bilinmeyen')+'\n'); runState('bad','hata'); Sound.play('err'); return; }
      appendRun('> '+(r.cmd||'')+'\n\n');
    }).catch(function(e){ appendRun('\n'+e+'\n'); runState('bad','hata'); });
  };
  if(tb.dirty&&st.autoSaveBeforeRun!==false){ Promise.resolve(window.kaydet()).then(function(ok){ if(ok) go(null); }); return; }
  if(tb.dirty){ var c=''; try{ c=edGet(); }catch(e){} go(c); return; }
  if(!tb.path){ Promise.resolve(window.farkliKaydet()).then(function(ok){ if(ok) window.calistir(); }); return; }
  go(null);
};

/* ---------- watcher ---------- */
function watchTick(){
  var a=API(); if(!a||!a.izleme_poll) return;
  var tabs=window.tabs||[], paths=[];
  tabs.forEach(function(t){ if(t.path) paths.push(t.path); });
  var dirs=[];
  try{
    Array.prototype.forEach.call(document.querySelectorAll('#tree .tree-children'),function(n){
      if(n.style.display==='none') return;
      var pv=n.previousElementSibling; if(!pv||!pv.dataset) return;
      var p=window._treeFiles&&window._treeFiles[pv.dataset.fid];
      if(p) dirs.push(p);
    });
  }catch(e){}
  a.izleme_poll(window._cwd||'',paths,dirs).then(function(r){
    if(!r||!r.ok||r.init) return;
    if(r.tree&&r.tree.length&&Date.now()-LAST_TREE>1500){ LAST_TREE=Date.now(); try{ refreshTree(); }catch(e){} }
    (r.changed||[]).forEach(function(p){ onChange(p,false); });
    (r.deleted||[]).forEach(function(p){ onChange(p,true); });
  }).catch(function(){});
}
function onChange(p,del){
  var tabs=window.tabs||[], tb=null;
  for(var i=0;i<tabs.length;i++) if(tabs[i].path===p){ tb=tabs[i]; break; }
  if(!tb) return;
  if(del){ toast('Diskte silindi: '+tb.name,'bad'); return; }
  if(!tb.dirty){
    var a=API(); if(!a) return;
    a.dosya_oku(p).then(function(y){
      if(!y||!y.ok||!tb.model) return;
      var cur=tb.model.getValue(); if(cur===y.content) return;
      var old=cur;
      tb.saving=true; tb.model.setValue(y.content); tb.saving=false; tb.dirty=false;
      try{ renderTabs(); }catch(e){}
      Sound.play('find');
      pushUndo('Diskten yenilendi: '+tb.name,function(){ tb.model.setValue(old); tb.dirty=true; try{renderTabs();}catch(e){} });
    });
    return;
  }
  conflict(tb,p);
}
function conflict(tb,p){
  var bar=el('scWatchBar');
  if(!bar){
    bar=mk('div'); bar.id='scWatchBar';
    var c=el('center'); if(!c) return;
    c.insertBefore(bar,c.firstChild.nextSibling);
  }
  bar.classList.add('on');
  bar.innerHTML='<span>⚠ <b>'+esc(tb.name)+'</b> diskte değişti, sende kaydedilmemiş değişiklik var.</span><span class="sc-sp" style="flex:1"></span>';
  var b1=mk('button','sc-btn','Karşılaştır');
  var b2=mk('button','sc-btn','Diskten al');
  var b3=mk('button','sc-btn','Yoksay');
  bar.appendChild(b1); bar.appendChild(b2); bar.appendChild(b3);
  b3.onclick=function(){ bar.classList.remove('on'); };
  b2.onclick=function(){
    var a=API(); if(!a) return;
    a.dosya_oku(p).then(function(y){ if(!y||!y.ok) return; var old=tb.model.getValue();
      tb.saving=true; tb.model.setValue(y.content); tb.saving=false; tb.dirty=false; try{renderTabs();}catch(e){}
      bar.classList.remove('on');
      pushUndo('Diskten alındı: '+tb.name,function(){ tb.model.setValue(old); tb.dirty=true; try{renderTabs();}catch(e){} }); });
  };
  b1.onclick=function(){
    var a=API(); if(!a) return;
    a.dosya_oku(p).then(function(y){ if(!y||!y.ok) return; bar.classList.remove('on');
      diffModal(tb.name+' — disk ↔ editör',y.content,tb.model.getValue(),null); });
  };
}

/* ---------- diff ---------- */
function diffLines(a,b){
  var A=String(a).replace(/\r\n/g,'\n').split('\n'), B=String(b).replace(/\r\n/g,'\n').split('\n');
  var n=A.length,m=B.length,out=[];
  if(n*m>360000){ var mx=Math.max(n,m); for(var k=0;k<mx;k++){ if(A[k]===B[k]) out.push([' ',A[k]||'']); else { if(k<n) out.push(['-',A[k]]); if(k<m) out.push(['+',B[k]]); } } return out; }
  var dp=[]; for(var i=0;i<=n;i++) dp.push(new Int32Array(m+1));
  for(var i=n-1;i>=0;i--) for(var j=m-1;j>=0;j--) dp[i][j]=A[i]===B[j]?dp[i+1][j+1]+1:Math.max(dp[i+1][j],dp[i][j+1]);
  var i=0,j=0;
  while(i<n&&j<m){ if(A[i]===B[j]){ out.push([' ',A[i]]); i++; j++; } else if(dp[i+1][j]>=dp[i][j+1]){ out.push(['-',A[i]]); i++; } else { out.push(['+',B[j]]); j++; } }
  while(i<n) out.push(['-',A[i++]]);
  while(j<m) out.push(['+',B[j++]]);
  return out;
}
function modal(title,tag,bodyHtml,actions){
  var m=mk('div','sc-modal on');
  var box=mk('div','sc-box');
  var hd=mk('header'); hd.innerHTML='<h3>'+esc(title)+'</h3>'+(tag?'<span class="tag">'+esc(tag)+'</span>':'')+'<span style="flex:1"></span>';
  var x=mk('button','sc-btn dgr','✕'); x.onclick=function(){ m.remove(); }; hd.appendChild(x);
  var bd=mk('div','body',bodyHtml);
  var ft=mk('footer');
  box.appendChild(hd); box.appendChild(bd); box.appendChild(ft); m.appendChild(box);
  m.addEventListener('mousedown',function(e){ if(e.target===m) m.remove(); });
  (actions||[]).forEach(function(a){ var b=mk('button','sc-btn'+(a.pri?' pri':'')+(a.dgr?' dgr':''),esc(a.label)); b.onclick=function(){ a.fn(m,bd); }; ft.appendChild(b); });
  var sp=mk('span'); sp.style.flex='1'; ft.appendChild(sp);
  var cl=mk('button','sc-btn','Kapat'); cl.onclick=function(){ m.remove(); }; ft.appendChild(cl);
  document.body.appendChild(m);
  return {m:m,bd:bd};
}
function diffModal(title,oldT,newT,onApply){
  var d=diffLines(oldT,newT), add=0, del=0;
  var html='<div class="sc-diff"><div class="h">'+esc(title)+'</div>';
  d.forEach(function(r){ if(r[0]==='+')add++; if(r[0]==='-')del++;
    html+='<div class="'+(r[0]==='+'?'a':r[0]==='-'?'d':'s')+'">'+(r[0]===' '?'\u00a0':r[0])+' '+esc(r[1])+'</div>'; });
  html+='</div>';
  var acts=[];
  if(onApply) acts.push({label:'Uygula (+'+add+' / −'+del+')',pri:true,fn:function(m){ onApply(newT); m.remove(); }});
  acts.push({label:'Panoya kopyala',fn:function(){ try{ navigator.clipboard.writeText(newT); toast('Kopyalandı','ok'); }catch(e){} }});
  modal('Değişiklik önizleme','+'+add+' / −'+del,html,acts);
}

/* ---------- arama v2 ---------- */
var SOPT={regex:false,case:false,whole:false,gitignore:true};
function searchShell(){
  var ov=el('searchOverlay'); if(!ov) return null;
  var box=ov.querySelector('.modal'); if(!box) return null;
  if(box.dataset.sc==='1') return box;
  box.dataset.sc='1'; box.id='scSearch';
  box.innerHTML='<header style="display:flex;align-items:center;gap:10px;padding:13px 16px;border-bottom:1px solid var(--sc-line)">'+
    '<h3 style="margin:0;font:700 13px var(--font-ui)">Projede Ara &amp; Değiştir</h3>'+
    '<span class="tag" id="scSStat" style="font:600 10px var(--font-mono);padding:4px 7px;border-radius:6px;background:#0F1A30;border:1px solid var(--sc-line);color:var(--sc-cyan)">hazır</span>'+
    '<span style="flex:1"></span><button class="sc-btn dgr" id="scSx">✕</button></header>'+
    '<div class="body" style="flex:1;min-height:0;overflow:auto;padding:14px 16px">'+
    '<div class="row"><input type="text" id="scSq" placeholder="Aranacak metin veya regex…"></div>'+
    '<div class="row"><input type="text" id="scSr" placeholder="Değiştir (boş bırak = sadece ara)"></div>'+
    '<div class="row"><input type="text" id="scSi" placeholder="Dahil: *.py, src/**"><input type="text" id="scSe" placeholder="Hariç: *.min.js, tests/**"></div>'+
    '<div class="row"><span class="sc-chip" data-o="regex">.* Regex</span><span class="sc-chip" data-o="case">Aa Büyük/küçük</span>'+
    '<span class="sc-chip" data-o="whole">|w| Tam kelime</span><span class="sc-chip on" data-o="gitignore">.gitignore</span>'+
    '<span style="flex:1"></span><button class="sc-btn pri" id="scSgo">Ara</button><button class="sc-btn dgr" id="scSrep">Tümünü değiştir</button></div>'+
    '<div id="scSres"></div></div>';
  el('scSx').onclick=function(){ ov.classList.remove('open'); };
  Array.prototype.forEach.call(box.querySelectorAll('.sc-chip'),function(c){
    c.onclick=function(){ var k=c.dataset.o; SOPT[k]=!SOPT[k]; c.classList.toggle('on',SOPT[k]); Sound.play('tick'); runSearch(); };
  });
  el('scSgo').onclick=runSearch;
  el('scSrep').onclick=runReplace;
  var deb=null;
  el('scSq').addEventListener('input',function(){ clearTimeout(deb); deb=setTimeout(runSearch,320); });
  el('scSq').addEventListener('keydown',function(e){ if(e.key==='Enter'){ e.preventDefault(); runSearch(); } });
  ['scSi','scSe'].forEach(function(i){ el(i).addEventListener('input',function(){ clearTimeout(deb); deb=setTimeout(runSearch,420); }); });
  return box;
}
function sopts(){
  var o=JSON.parse(JSON.stringify(SOPT));
  o.include=(el('scSi')||{}).value||''; o.exclude=(el('scSe')||{}).value||''; o.limit=800;
  return o;
}
var LASTQ='';
function runSearch(){
  var a=API(); if(!a||!a.arama_v2) return;
  var q=(el('scSq')||{}).value||''; LASTQ=q;
  var res=el('scSres'), st=el('scSStat');
  if(!q){ res.innerHTML='<div class="sc-empty">Aramak için bir şey yaz.<br>Regex, tam kelime ve .gitignore filtreleri canlı çalışır.</div>'; st.textContent='hazır'; return; }
  if(!window._cwd){ res.innerHTML='<div class="sc-empty">Önce bir proje klasörü aç.</div>'; return; }
  st.textContent='arıyor…';
  a.arama_v2(q,window._cwd,sopts()).then(function(r){
    if(!r||!r.ok){ res.innerHTML='<div class="sc-empty">'+esc((r&&r.hata)||'Arama başarısız')+'</div>'; st.textContent='hata'; return; }
    st.textContent=r.hits.length+' sonuç · '+r.files+' dosya · '+r.scanned+' tarandı';
    if(!r.hits.length){ res.innerHTML='<div class="sc-empty">Eşleşme yok.</div>'; return; }
    Sound.play('find');
    var by={};
    r.hits.forEach(function(h){ (by[h.path]=by[h.path]||{rel:h.rel,rows:[]}).rows.push(h); });
    var html='';
    Object.keys(by).forEach(function(p){
      var g=by[p];
      html+='<div class="sc-file"><h5 data-p="'+esc(p)+'">📄 '+esc(g.rel)+'<span>'+g.rows.length+'</span></h5>';
      g.rows.slice(0,60).forEach(function(h){
        var t=esc(h.text), qq=esc(LASTQ);
        if(!SOPT.regex&&qq){ try{ t=t.replace(new RegExp(qq.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),SOPT.case?'g':'gi'),function(m){ return '<em>'+m+'</em>'; }); }catch(e){} }
        html+='<div class="sc-hit" data-p="'+esc(p)+'" data-l="'+h.line+'"><i>'+h.line+'</i><span>'+t+'</span></div>';
      });
      html+='</div>';
    });
    if(r.truncated) html+='<div class="sc-empty">İlk '+r.hits.length+' sonuç gösteriliyor — deseni daralt.</div>';
    res.innerHTML=html;
    Array.prototype.forEach.call(res.querySelectorAll('.sc-hit'),function(n){
      n.onclick=function(){
        ovClose();
        try{ dosyaAcYol(n.dataset.p); }catch(e){}
        var ln=parseInt(n.dataset.l,10)||1;
        setTimeout(function(){ try{ editor.revealLineInCenter(ln); editor.setPosition({lineNumber:ln,column:1}); editor.focus(); }catch(e){} },420);
      };
    });
  }).catch(function(e){ st.textContent='hata'; res.innerHTML='<div class="sc-empty">'+esc(String(e))+'</div>'; });
}
function ovClose(){ var o=el('searchOverlay'); if(o) o.classList.remove('open'); }
function runReplace(){
  var a=API(); if(!a||!a.degistir_v2) return;
  var q=(el('scSq')||{}).value||'', rp=(el('scSr')||{}).value||'';
  if(!q||!window._cwd){ toast('Arama metni ve proje gerekli','warn'); return; }
  if(!confirm('Tüm projede değiştirilsin mi?\n\n'+q+'  →  '+rp)) return;
  a.degistir_v2(q,rp,window._cwd,sopts()).then(function(r){
    if(!r||!r.ok){ toast((r&&r.hata)||'Değiştirilemedi','bad'); Sound.play('err'); return; }
    Sound.play('apply');
    var bk=r.backup||[];
    pushUndo(r.replacements+' değişiklik / '+r.changed_files+' dosya',function(){
      var a2=API(); if(a2&&a2.geri_al) a2.geri_al(bk).then(function(){ try{refreshTree();}catch(e){} toast('Değişiklikler geri alındı','ok'); });
    });
    try{ refreshTree(); }catch(e){}
    runSearch();
  });
}
window.searchAc=function(){ var ov=el('searchOverlay'); if(!ov) return; searchShell(); ov.classList.add('open'); setTimeout(function(){ var i=el('scSq'); if(i) i.focus(); },60); };
window.doSearch=function(){ runSearch(); };

/* ---------- AI streaming + diff apply ---------- */
function aiBlocks(text){
  var out=[], rx=/```([A-Za-z0-9_+-]*)\n([\s\S]*?)```/g, m;
  while((m=rx.exec(text))) out.push({lang:m[1]||'text',code:m[2]});
  return out;
}
function renderAi(node,text,streaming){
  var blocks=aiBlocks(text);
  if(!blocks.length){ node.textContent=text; if(streaming) node.appendChild(mk('span','sc-caret')); return; }
  var parts=text.split(/```[A-Za-z0-9_+-]*\n[\s\S]*?```/g), html='';
  for(var i=0;i<parts.length;i++){
    if(parts[i]) html+='<div style="white-space:pre-wrap">'+esc(parts[i])+'</div>';
    if(blocks[i]){
      html+='<div class="sc-ai-code"><div class="hd"><span>'+esc(blocks[i].lang)+'</span><span style="flex:1"></span>'+
        '<button class="sc-btn" data-copy="'+i+'">Kopyala</button><button class="sc-btn pri" data-apply="'+i+'">Editöre uygula</button></div>'+
        '<pre>'+esc(blocks[i].code)+'</pre></div>';
    }
  }
  node.innerHTML=html;
  if(streaming) node.appendChild(mk('span','sc-caret'));
  Array.prototype.forEach.call(node.querySelectorAll('[data-copy]'),function(b){
    b.onclick=function(){ try{ navigator.clipboard.writeText(blocks[+b.dataset.copy].code); toast('Kod kopyalandı','ok'); }catch(e){} };
  });
  Array.prototype.forEach.call(node.querySelectorAll('[data-apply]'),function(b){
    b.onclick=function(){
      var code=blocks[+b.dataset.apply].code, cur='';
      try{ cur=edGet(); }catch(e){}
      diffModal('AI önerisi → aktif editör',cur,code,function(nt){
        var old=cur;
        try{ edSet(nt); }catch(e){ toast('Editör yok','bad'); return; }
        Sound.play('apply');
        pushUndo('AI kodu uygulandı',function(){ try{ edSet(old); }catch(e){} });
      });
    };
  });
}
window.scAiChunk=function(sid,t){
  var s=STREAMS[sid]; if(!s) return;
  s.text+=t; renderAi(s.node,s.text,true);
  var m=el('aiMessages'); if(m) m.scrollTop=m.scrollHeight;
};
window.scAiDone=function(sid,full,err,cancelled){
  var s=STREAMS[sid]; if(!s) return;
  delete STREAMS[sid];
  var txt=full||s.text;
  if(err){ s.node.textContent='Hata: '+err; Sound.play('err'); }
  else { renderAi(s.node,txt,false); try{ _aiPush(txt); }catch(e){} Sound.play(cancelled?'close':'done'); }
  var b=el('aiSendBtn'); if(b){ b.disabled=false; b.innerHTML='➤'; b.onclick=window.aiSend; }
  var m=el('aiMessages'); if(m) m.scrollTop=m.scrollHeight;
};
function _aiPush(t){ if(window.__scAiHist) window.__scAiHist.push({role:'assistant',content:t}); }
window.__scAiHist=[];
window.aiSend=function(){
  var inp=el('aiInput'); if(!inp) return;
  var txt=(inp.value||'').trim(); if(!txt) return;
  var a=API(); if(!a||!a.ai_stream_baslat){ toast('AI streaming hazır değil','bad'); return; }
  var st=window.settings||{};
  if(!st.ai_provider){ toast('Ayarlar → AI sağlayıcı seç','warn'); return; }
  inp.value='';
  var msgs=el('aiMessages');
  var u=mk('div','ai-msg user'); u.textContent=txt; msgs.appendChild(u);
  window.__scAiHist.push({role:'user',content:txt});
  var node=mk('div','ai-msg assistant'); node.appendChild(mk('span','sc-caret')); msgs.appendChild(node);
  msgs.scrollTop=msgs.scrollHeight;
  var ctx=''; try{ ctx=edGet(); }catch(e){}
  Sound.play('start');
  a.ai_stream_baslat(window.__scAiHist.slice(-12),ctx).then(function(r){
    if(!r||!r.ok){ node.textContent='Hata: '+((r&&r.hata)||'başlatılamadı'); Sound.play('err'); return; }
    STREAMS[r.id]={node:node,text:''};
    var b=el('aiSendBtn');
    if(b){ b.innerHTML='■'; b.title='Durdur'; b.onclick=function(){ a.ai_stream_durdur(r.id); }; }
  }).catch(function(e){ node.textContent='Hata: '+e; Sound.play('err'); });
};
window.aiClear=function(){ window.__scAiHist=[]; var m=el('aiMessages'); if(m) m.innerHTML='<div class="ai-msg assistant">Temizlendi. Yeni bir soru sor!</div>'; };

/* ---------- kisayollar + boot ---------- */
document.addEventListener('keydown',function(e){
  var c=e.ctrlKey||e.metaKey;
  if(c&&e.shiftKey&&(e.key==='T'||e.key==='t')){ e.preventDefault(); openPanel(); newTerm(curCwd()); }
  else if(c&&e.shiftKey&&(e.key==='W'||e.key==='w')){ if(TABS.length){ e.preventDefault(); closeTab(ACT); } }
  else if(c&&e.altKey&&(e.key==='z'||e.key==='Z')){ e.preventDefault(); doUndo(); }
  else if(c&&e.shiftKey&&(e.key==='F'||e.key==='f')){ e.preventDefault(); window.searchAc(); }
},true);

function muteBtn(){
  var tb=el('topbar'); if(!tb||el('scMute')) return;
  var b=mk('button'); b.id='scMute'; b.textContent=CFG.sound?'🔊':'🔇';
  b.title=CFG.sound?'Sesi kapat':'Sesi aç';
  b.onclick=function(){ CFG.sound=!CFG.sound; Sound.on=CFG.sound; applyCfg(); if(CFG.sound) Sound.play('tab'); toast(CFG.sound?'Ses açık':'Ses kapalı'); };
  var sp=tb.querySelector('.spacer');
  if(sp&&sp.nextSibling) tb.insertBefore(b,sp.nextSibling); else tb.appendChild(b);
}
function boot(){
  var a=API();
  if(!a||!a.terminal_ac||!window.settings){ setTimeout(boot,220); return; }
  muteBtn();
  a.studio_ayar_yukle().then(function(d){
    if(d&&typeof d==='object'){ Object.keys(DEF).forEach(function(k){ if(k in d) CFG[k]=d[k]; }); }
    Sound.on=CFG.sound; applyCfg(false);
  }).catch(function(){ applyCfg(false); });
  runShell();
  if(WATCH_T) clearInterval(WATCH_T);
  WATCH_T=setInterval(watchTick,2500);
  window.addEventListener('resize',fitAll);
  document.addEventListener('mousedown',function(){ Sound.boot(); },{once:true});
  toast('Studio hazır — çoklu terminal, stdin, watcher, akıllı arama','ok');
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();
'''

# ══════════════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════════════

SKIP = {".git", ".venv", "venv", "node_modules", "_backups",
        ".idea", ".vscode", "dist", "build"}
MAXB = 25 * 1024 * 1024


def find_root(cli=None):
    c = []
    if cli:
        c.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    c += [here, os.getcwd(), os.path.dirname(here)]
    for x in c:
        if os.path.isdir(os.path.join(x, "splash_code")):
            return x
    return c[0]


def rd(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def wr(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def pycache(root):
    t = []
    for dp, dn, fn in os.walk(root):
        if os.path.basename(dp) == "__pycache__":
            t.append(dp)
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in SKIP]
    for x in t:
        shutil.rmtree(x, ignore_errors=True)
    return len(t)


def backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAXB:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def plan(root):
    ops, probs = [], []

    fp = os.path.join(root, "splash_code", "features.py")
    old = rd(fp) if os.path.isfile(fp) else None
    ops.append(("splash_code/features.py",
                None if old == FEATURES_PY else FEATURES_PY,
                "AYNI" if old == FEATURES_PY else
                ("YENI" if old is None else "GUNCELLE")))

    for rel, block in (("splash_code/api.py", API_APPEND),
                       ("splash_code/html_builder.py", HTMLB_APPEND)):
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            probs.append(rel + " yok")
            continue
        src = rd(p)
        if MARK in src:
            ops.append((rel, None, "ZATEN"))
            continue
        body = block.strip("\n")
        new = src if src.endswith("\n") else src + "\n"
        new += "\n" + body + "\n"
        ops.append((rel, new, "+%d satir" % len(body.splitlines())))

    hp = os.path.join(root, HTML_REL)
    if not os.path.isfile(hp):
        probs.append(HTML_REL + " yok")
    else:
        src = rd(hp)
        if MARK in src:
            ops.append((HTML_REL, None, "ZATEN"))
        else:
            payload = ("\n<!--%s-->\n<style>\n%s\n</style>\n<script>\n%s\n</script>\n"
                       % (MARK, STUDIO_CSS.strip("\n"), STUDIO_JS.strip("\n")))
            low = src.lower()
            i = low.rfind("</body>")
            if i < 0:
                probs.append(HTML_REL + ": </body> bulunamadi")
            else:
                ops.append((HTML_REL, src[:i] + payload + src[i:],
                            "+%d KB studio katmani"
                            % (len(payload) // 1024)))
    return ops, probs


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc008.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                t = os.path.join(root, rel)
                if k in names:
                    with open(t, "wb") as f:
                        f.write(z.read(k))
                    print("    geri: " + rel)
                else:
                    try:
                        os.remove(t)
                        print("    silindi: " + rel)
                    except Exception:
                        pass
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Elle ac: %s" % zp)


def restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: " + zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def check(root):
    print("\n  --- TANI ---")

    def g(rel):
        try:
            return rd(os.path.join(root, rel))
        except Exception:
            return ""

    api = g("splash_code/api.py")
    hb = g("splash_code/html_builder.py")
    idx = g(HTML_REL)
    print("  features.py            : %s" % ("VAR" if os.path.isfile(
        os.path.join(root, "splash_code", "features.py")) else "YOK"))
    print("  api studio metotlari   : %s" % ("VAR" if "Api.terminal_ac" in api else "YOK"))
    print("  html_builder offline   : %s" % ("VAR" if MARK in hb else "YOK"))
    print("  studio katmani (html)  : %s" % ("VAR" if MARK in idx else "YOK"))
    print("  xterm AMD kalkani      : %s" % ("VAR" if "SC-XT-SHIELD" in idx else "YOK"))
    ml = os.path.join(root, "splash_code", "static", "monaco", "vs", "loader.js")
    fl = os.path.join(root, "splash_code", "static", "fonts", "sc-fonts.css")
    print("  Yerel Monaco           : %s" % ("VAR" if os.path.isfile(ml) else "YOK"))
    print("  Yerel fontlar          : %s" % ("VAR" if os.path.isfile(fl) else "YOK -> Studio > Fontlari cevirimdisi yap"))
    print("  index.html             : %.0f KB" % (len(idx) / 1024.0))
    for m in ("webview", "winpty"):
        try:
            mm = __import__(m)
            print("  %-22s : KURULU (%s)" % (m, getattr(mm, "__version__", "?")))
        except Exception:
            print("  %-22s : YOK" % m)
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 66)
    print("  Splash Code Studio - Patch %s  \"Studio\"" % PATCH_ID)
    print("  " + TITLE)
    print("=" * 66)
    print("  Kok: " + root)

    if a.restore:
        return restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok. --root ver.")
        return 1
    if a.check:
        return check(root)

    print("\n  On-kontrol (bellekte derleme)...")
    for name, src in (("features.py", FEATURES_PY),):
        try:
            compile(src.encode("utf-8"), name, "exec")
        except SyntaxError as e:
            print("    X %s satir %s: %s" % (name, e.lineno, e.msg))
            return 2
    for rel, blk in (("splash_code/api.py", API_APPEND),
                     ("splash_code/html_builder.py", HTMLB_APPEND)):
        p = os.path.join(root, rel)
        if os.path.isfile(p):
            try:
                compile((rd(p) + "\n" + blk).encode("utf-8"), rel, "exec")
            except SyntaxError as e:
                print("    X %s (birlesik) satir %s: %s" % (rel, e.lineno, e.msg))
                return 2
    print("    Python OK  ·  JS %d KB  ·  CSS %d KB"
          % (len(STUDIO_JS) // 1024, len(STUDIO_CSS) // 1024))

    ops, probs = plan(root)
    print("\n  Plan:")
    for rel, new, info in ops:
        print("    %-34s %s" % (rel, info))
    if probs:
        print("\n  !! SORUN:")
        for x in probs:
            print("     - " + x)
        print("  Hicbir sey yazilmadi.")
        return 2

    todo = [(r, c) for r, c, _ in ops if c is not None]
    if not todo:
        print("\n  Zaten uygulanmis.")
        return 0
    if a.dry_run:
        print("\n  --dry-run: temiz. (%d dosya)" % len(todo))
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = backup(root)
        print("    %s (%d dosya)" % (zp, n))

    touched = []
    try:
        for rel, content in todo:
            wr(os.path.join(root, rel), content)
            touched.append(rel)
            print("    + " + rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Disk dogrulamasi...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK  ·  %d __pycache__ silindi" % pycache(root))

    print("\n" + "=" * 66)
    print("  Patch %s UYGULANDI — Studio aktif" % PATCH_ID)
    if zp:
        print("  Geri al: py path.py --restore \"%s\"" % zp)
    print("  py main.py")
    print("    Terminal ac -> sekmeler + sagda canli Terminal Studio reyonu")
    print("    F5 -> altta stdin kutusu (input() artik calisir)")
    print("    Ctrl+Shift+F -> regex / glob / .gitignore arama + geri al")
    print("    AI paneli -> akisli cevap + koda 'Editore uygula' + diff")
    print("    Studio > Fontlari cevirimdisi yap -> tam offline")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
