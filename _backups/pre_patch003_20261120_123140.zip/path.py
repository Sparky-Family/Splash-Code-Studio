#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 003
Append-tabanli: mevcut kod korunur, dosya sonuna kucuk blok eklenir.

    python patch.py --dry-run
    python patch.py
    python patch.py --restore _backups/pre_patch003_XXXX.zip
"""

import argparse
import os
import py_compile
import re
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "003"
TITLE = "xterm dedupe + LSP dil ID + settings/cache/ikon/AI fix"
MARK = "# ===== SC-PATCH-003 ====="
HTML_REL = "splash_code/templates/index.html"

# ══════════════════════════════════════════════════════════════
#  APPEND BLOKLARI  (docstring yok -> triple-quote cakismasi yok)
# ══════════════════════════════════════════════════════════════

B_CONSTANTS = r"""
# ===== SC-PATCH-003 =====
# get_lang() 'dockerfile'/'shell' dondurur ama LSP_SERVERS 'docker'/'bash' kullaniyordu.
for _old, _new in (('docker', 'dockerfile'), ('bash', 'shell')):
    if _old in LSP_SERVERS:
        LSP_SERVERS.setdefault(_new, LSP_SERVERS[_old])
        LSP_SERVERS.pop(_old, None)
    if _old in LSP_INSTALL_CMDS:
        LSP_INSTALL_CMDS.setdefault(_new, LSP_INSTALL_CMDS[_old])
        LSP_INSTALL_CMDS.pop(_old, None)
EXT_TO_LANG.setdefault('.cmake', 'cmake')
_sc003_orig_get_lang = get_lang
def get_lang(path):
    # CMakeLists.txt ve rc dosyalari icin dogru dil
    try:
        n = os.path.basename(str(path)).lower()
        if n == 'cmakelists.txt' or n.endswith('.cmake'):
            return 'cmake'
        if n in ('bashrc', '.bashrc', '.bash_profile', '.zshrc', '.profile'):
            return 'shell'
    except Exception:
        pass
    return _sc003_orig_get_lang(path)
LSP_MONACO_IDS.clear()
LSP_MONACO_IDS.update(LSP_SERVERS.keys())
# ===== /SC-PATCH-003 =====
"""

B_SETTINGS = r"""
# ===== SC-PATCH-003 =====
import shutil as _sc003_shutil
SETTINGS_SCHEMA.update({
    'fontFamily': str, 'customAccent': str, 'splitMode': str,
    'ai_provider': str, 'ai_gemini_key': str, 'ai_claude_key': str,
    'ai_model': str, 'largeFileWarnSize': int,
})
_sc003_orig_normalize = normalize_settings
_sc003_orig_save = save_settings
def normalize_settings(s):
    # enum + clamp dogrulamasi
    out = _sc003_orig_normalize(s)
    try:
        if out.get('splitMode') not in ('none', 'vertical', 'horizontal'):
            out['splitMode'] = 'none'
        if out.get('encoding') not in ('utf-8', 'utf-8-sig', 'latin-1', 'cp1254'):
            out['encoding'] = 'utf-8'
        if out.get('endOfLine') not in ('\n', '\r\n'):
            out['endOfLine'] = '\n'
        for _k in ('lastProject', 'themeCategory'):
            if out.get(_k) in ('', 'None'):
                out[_k] = None
        out['largeFileWarnSize'] = max(65536, min(67108864, int(out.get('largeFileWarnSize') or 5242880)))
        out['lspDebounceMs'] = max(50, min(2000, int(out.get('lspDebounceMs') or 250)))
        out['lspCacheTtl'] = max(1, min(600, int(out.get('lspCacheTtl') or 30)))
    except Exception:
        pass
    return out
def save_settings(s):
    # .bak artik gercekten yaziliyor -> load_settings fallback'i calisir
    try:
        if os.path.exists(SETTINGS_FILE):
            _sc003_shutil.copy2(SETTINGS_FILE, SETTINGS_BACKUP)
    except Exception:
        pass
    return _sc003_orig_save(s)
# ===== /SC-PATCH-003 =====
"""

B_HTMLB = r"""
# ===== SC-PATCH-003 =====
from .constants import THEMES_USER_FILE as _sc003_TF, ICON_MAP_FILE as _sc003_IF
_sc003_sig = None
_sc003_orig_build = build_html
def _sc003_mtime(p):
    try:
        return os.path.getmtime(p)
    except Exception:
        return 0
def build_html(settings):
    # proje / tema / ikon dosyasi degisince cache'i otomatik dusur
    global _sc003_sig, _themes_json_cache
    s = settings or {}
    sig = (s.get('lastProject'), s.get('theme'), s.get('iconPack'),
           s.get('useCustomAccent'), s.get('customAccent'),
           _sc003_mtime(_TEMPLATE_PATH), _sc003_mtime(_sc003_TF),
           _sc003_mtime(_sc003_IF))
    if sig != _sc003_sig:
        _sc003_sig = sig
        _build_cache.clear()
        _themes_json_cache = None
    return _sc003_orig_build(settings)
def clear_build_cache():
    # tema JSON cache'i de temizlenir (yeni tema restart istemez)
    global _themes_json_cache, _sc003_sig
    _build_cache.clear()
    _themes_json_cache = None
    _sc003_sig = None
# ===== /SC-PATCH-003 =====
"""

B_ICONS = r"""
# ===== SC-PATCH-003 =====
ICONS.setdefault('php', '<ellipse cx="12" cy="12" rx="10" ry="6"/><path d="M6 15l1.5-6h2a1.5 1.5 0 0 1 0 3h-2"/><path d="M12 15l1.5-6h2a1.5 1.5 0 0 1 0 3h-2"/>')
ICONS.setdefault('dart', '<path d="M5 12L12 3l7 7v9h-9z"/><path d="M12 3v9h7"/>')
ICONS.setdefault('swift', '<path d="M4 4c6 5 9 8 11 12"/><path d="M9 4c4 4 6 7 7 10"/><path d="M4 16c4 3 9 3 13 0"/>')
ICONS.setdefault('hs', '<path d="M3 4l6 8-6 8"/><path d="M9 4l6 8-6 8"/><path d="M15 10h6"/><path d="M17 14h4"/>')
ICONS.setdefault('ex', '<path d="M12 3c4 5 6 8 6 11a6 6 0 0 1-12 0c0-3 2-6 6-11z"/>')
ICONS.setdefault('wasm', '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M6 9l2 6 2-4 2 4 2-6"/><path d="M16 15v-5h2"/>')
ICONS.setdefault('docker', '<rect x="4" y="10" width="3" height="3"/><rect x="8" y="10" width="3" height="3"/><rect x="12" y="10" width="3" height="3"/><rect x="8" y="6" width="3" height="3"/><path d="M3 14c0 3 3 5 7 5s8-2 9-5"/>')
ICONS.setdefault('graphql', '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><circle cx="12" cy="3" r="1.4"/><circle cx="20" cy="7.5" r="1.4"/><circle cx="20" cy="16.5" r="1.4"/><circle cx="12" cy="21" r="1.4"/><circle cx="4" cy="16.5" r="1.4"/><circle cx="4" cy="7.5" r="1.4"/>')
_sc003_orig_svg = svg
def svg(name, size=16):
    # bilinmeyen isim -> 'file' (bos SVG donup ikon kaybolmasin)
    return _sc003_orig_svg(name if name in ICONS else 'file', size)
_svg_cache.clear()
# ===== /SC-PATCH-003 =====
"""

B_THEMES = r"""
# ===== SC-PATCH-003 =====
if THEMES.get('material', {}).get('name') == 'Material Ocean':
    THEMES['material']['name'] = 'Material'
# ===== /SC-PATCH-003 =====
"""

B_AI = r"""
# ===== SC-PATCH-003 =====
import json as _sc003_json
import urllib.request as _sc003_req
import urllib.error as _sc003_err
_SC003_GEMINI_DEFAULT = 'gemini-2.5-flash'
def ai_gemini(key, model, messages):
    # system mesaji 'model' rolune degil systemInstruction'a gidiyor
    if not key:
        return {'ok': False, 'hata': 'Gemini API key yok'}
    model = (model or _SC003_GEMINI_DEFAULT).strip()
    sys_parts, contents = [], []
    for m in (messages or []):
        role = m.get('role')
        txt = m.get('content') or ''
        if role == 'system':
            sys_parts.append(txt)
            continue
        contents.append({'role': 'user' if role == 'user' else 'model',
                         'parts': [{'text': txt}]})
    if not contents:
        return {'ok': False, 'hata': 'Bos mesaj'}
    if contents[0]['role'] != 'user':
        contents.insert(0, {'role': 'user', 'parts': [{'text': '(baglam)'}]})
    payload = {'contents': contents}
    if sys_parts:
        payload['systemInstruction'] = {'parts': [{'text': '\n\n'.join(sys_parts)}]}
    url = ('https://generativelanguage.googleapis.com/v1beta/models/'
           + model + ':generateContent')
    req = _sc003_req.Request(
        url, data=_sc003_json.dumps(payload).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'x-goog-api-key': key},
        method='POST')
    try:
        with _sc003_req.urlopen(req, timeout=90) as r:
            data = _sc003_json.loads(r.read().decode('utf-8'))
        cands = data.get('candidates') or []
        if not cands:
            fb = (data.get('promptFeedback') or {}).get('blockReason')
            return {'ok': False, 'hata': ('Engellendi: ' + fb) if fb else 'Bos cevap'}
        parts = (cands[0].get('content') or {}).get('parts') or []
        text = ''.join(p.get('text', '') for p in parts)
        if not text.strip():
            return {'ok': False, 'hata': 'Bos cevap'}
        return {'ok': True, 'text': text}
    except _sc003_err.HTTPError as e:
        try:
            err = e.read().decode('utf-8', 'ignore')[:400]
        except Exception:
            err = ''
        return {'ok': False, 'hata': 'HTTP %s: %s' % (e.code, err)}
    except Exception as e:
        return {'ok': False, 'hata': str(e)}
# ===== /SC-PATCH-003 =====
"""

APPEND = {
    "splash_code/constants.py": B_CONSTANTS,
    "splash_code/settings.py": B_SETTINGS,
    "splash_code/html_builder.py": B_HTMLB,
    "splash_code/icons.py": B_ICONS,
    "splash_code/themes.py": B_THEMES,
    "splash_code/ai.py": B_AI,
}

# ══════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════

SKIP_DIRS = {"__pycache__", ".git", ".venv", "venv", "node_modules",
             "_backups", ".idea", ".vscode", "dist", "build"}
MAX_BACKUP_FILE = 25 * 1024 * 1024


def find_root(cli=None):
    cands = []
    if cli:
        cands.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for c in cands:
        if os.path.isdir(os.path.join(c, "splash_code")):
            return c
    return cands[0]


def read_text(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, content):
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def dedupe_assets(html):
    """Ayni xterm.js / xterm.css blogunun 2. ve sonraki kopyalarini siler."""
    removed = []

    def run(pattern, marker, label, src):
        state = {"seen": False}

        def repl(m):
            if marker not in m.group(1):
                return m.group(0)
            if not state["seen"]:
                state["seen"] = True
                return m.group(0)
            removed.append((label, len(m.group(0))))
            return ""
        return pattern.sub(repl, src)

    html = run(re.compile(r"<script\b[^>]*>(.*?)</script>", re.S | re.I),
               "t.AccessibilityManager=void 0", "xterm.js", html)
    html = run(re.compile(r"<style\b[^>]*>(.*?)</style>", re.S | re.I),
               ".xterm-char-measure-element", "xterm.css", html)
    return html, removed


def make_plan(root):
    ops, problems = [], []
    for rel, block in APPEND.items():
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            problems.append("%s: dosya yok" % rel)
            continue
        src = read_text(p)
        if MARK in src:
            ops.append((rel, None, "ZATEN UYGULANMIS"))
            continue
        body = block.strip("\n")
        new = src if src.endswith("\n") else src + "\n"
        new += "\n" + body + "\n"
        ops.append((rel, new, "+%d satir" % len(body.splitlines())))

    p = os.path.join(root, HTML_REL)
    if not os.path.isfile(p):
        problems.append("%s: dosya yok" % HTML_REL)
    else:
        src = read_text(p)
        new, rem = dedupe_assets(src)
        if rem:
            info = ", ".join("%s -%d KB" % (l, n // 1024) for l, n in rem)
            ops.append((HTML_REL, new, info))
        else:
            ops.append((HTML_REL, None, "ZATEN tek kopya"))
    return ops, problems


def make_backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP_DIRS]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAX_BACKUP_FILE:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc003.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR...")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                if k in names:
                    with open(os.path.join(root, rel), "wb") as f:
                        f.write(z.read(k))
                    print("    geri: %s" % rel)
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Elle ac: %s" % zp)


def clear_pycache(root):
    targets = []
    for dp, dn, _ in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        if os.path.basename(dp) == "__pycache__":
            targets.append(dp)
    for t in targets:
        shutil.rmtree(t, ignore_errors=True)
    return len(targets)


def do_restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: %s" % zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    clear_pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 64)
    print("  Splash Code Studio - Patch %s" % PATCH_ID)
    print("  %s" % TITLE)
    print("=" * 64)
    print("  Kok: %s" % root)

    if a.restore:
        return do_restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok. --root ver.")
        return 1

    for f, tag, need in (("lsp_client.py", "peek_lsp", "001"),
                         ("api.py", "def format_dosya", "002")):
        p = os.path.join(root, "splash_code", f)
        if os.path.isfile(p):
            try:
                if need not in read_text(p):
                    print("  NOT: Patch %s uygulanmamis gibi (%s)."
                          % (tag, f))
            except Exception:
                pass

    ops, problems = make_plan(root)
    print("\n  Plan:")
    for rel, new, info in ops:
        print("    %-34s %s" % (rel, info))

    if problems:
        print("\n  !! SORUN:")
        for x in problems:
            print("     - %s" % x)
        print("  Hicbir sey yazilmadi.")
        return 2

    todo = [(r, c) for r, c, _ in ops if c is not None]
    if not todo:
        print("\n  Zaten tamamen uygulanmis. Yapilacak is yok.")
        return 0

    if a.dry_run:
        print("\n  --dry-run: temiz. Yazmak icin --dry-run'i kaldir.")
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = make_backup(root)
        print("    %s (%d dosya)" % (zp, n))
    else:
        print("\n  !! Backup KAPALI")

    touched = []
    try:
        for rel, content in todo:
            write_atomic(os.path.join(root, rel), content)
            touched.append(rel)
            print("    + %s" % rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Derleme dogrulamasi...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK")
    print("    %d __pycache__ temizlendi" % clear_pycache(root))

    print("\n" + "=" * 64)
    print("  Patch %s UYGULANDI" % PATCH_ID)
    if zp:
        print("  Geri al: python patch.py --restore \"%s\"" % zp)
    print("  Test: python main.py")
    print("    1) Acilis daha hizli mi (xterm artik tek kopya)")
    print("    2) Terminal hala calisiyor mu")
    print("    3) Tema galerisinden tema sec -> aninda uygulaniyor mu")
    print("    4) .php / .dart / Dockerfile ikonlari gorunuyor mu")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())
