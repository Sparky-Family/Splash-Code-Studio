#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 009 "Uyum"
Terminal Studio kaldirilir; terminal IDE temasiyla eslenir.
Girdi (stdin) kopuklugu, tema/ayar degisiminde kilitlenme giderilir.
Arayuz tamamen IDE'nin kendi tasarım diline tasinir.

    py path.py --check
    py path.py --dry-run
    py path.py
    py path.py --restore _backups/pre_patch009_XXXX.zip
"""

import argparse
import os
import py_compile
import re
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "009"
TITLE = "Terminal IDE temasiyla eslenir + girdi/kilitlenme fix"
OLD_MARK = "<!--SC-STUDIO-008-->"
MARK = "SC-STUDIO-009"
PY_MARK = "# ===== SC-STUDIO-009 ====="
HTML_REL = "splash_code/templates/index.html"

# ══════════════════════════════════════════════════════════════════════
#  api.py  APPEND
# ══════════════════════════════════════════════════════════════════════

API_APPEND = r'''
# ===== SC-STUDIO-009 =====
import re as _sc009_re
import time as _sc009_time
from . import terminal as _sc009_term


def _sc009_terminal_ac(self, cwd, shell=None, name=None, term_id=None):
    # Frontend'in istedigi id'yi KABUL ET. Onceki surum backend'de yeni id
    # uretiyordu; frontend kendi id'sine yazdigi icin her tus bos geliyordu.
    tid = str(term_id or '').strip()
    if not tid or not _sc009_re.fullmatch(r'[A-Za-z0-9_-]{1,64}', tid):
        tid = 's%d' % int(_sc009_time.time() * 1000)
    base = cwd or self._cwd or os.getcwd()
    r = _sc009_term.term_spawn(tid, base, shell)
    if r.get('ok'):
        r['term_id'] = tid
        r['name'] = name or 'Terminal'
        r['cwd'] = base
    return r


def _sc009_entry(tid):
    try:
        return _sc009_term._TERM_PROCS.get(tid)
    except Exception:
        return None


def _sc009_proc(entry):
    if entry is None:
        return None
    if isinstance(entry, dict):
        return entry.get('proc')
    return entry


def _sc009_terminal_canli(self, term_id):
    p = _sc009_proc(_sc009_entry(term_id))
    if p is None:
        return {'ok': True, 'alive': False}
    try:
        alive = bool(p.isalive())
    except Exception:
        alive = True
    return {'ok': True, 'alive': alive}


def _sc009_terminal_aktif(self, term_id):
    self._sc009_active = str(term_id or '')
    return {'ok': True}


def _sc009_send_to_term(self, cwd, cmd_text):
    # Debug / Test ciktisi GORUNEN sekmeye ve onun PTY'sine yazilir.
    tid = getattr(self, '_sc009_active', '') or 't1'
    if _sc009_entry(tid) is None:
        r = _sc009_term.term_spawn(tid, cwd or self._cwd or os.getcwd(), None)
        if not r.get('ok'):
            return r
        _sc009_time.sleep(0.7)
    line = ('& ' + cmd_text + '\r') if os.name == 'nt' else (cmd_text + '\n')
    return _sc009_term.term_write(tid, line)


def _sc009_studio_sifirla(self):
    try:
        from .features import studio_file
        p = studio_file()
        if os.path.exists(p):
            os.remove(p)
    except Exception:
        pass
    return {'ok': True}


Api.terminal_ac = _sc009_terminal_ac
Api.terminal_canli = _sc009_terminal_canli
Api.terminal_aktif_belirle = _sc009_terminal_aktif
Api._send_to_term = _sc009_send_to_term
Api.studio_ayar_sifirla = _sc009_studio_sifirla
# ===== /SC-STUDIO-009 =====
'''

# ══════════════════════════════════════════════════════════════════════
#  STUDIO CSS  —  sadece IDE degiskenleri
# ══════════════════════════════════════════════════════════════════════

STUDIO_CSS = r'''
#terminalPanel.sc9{height:260px;background:var(--bg);border-top:1px solid var(--border);display:none;flex-direction:column;flex-shrink:0;position:relative}
#terminalPanel.sc9.open{display:flex}
#terminalPanel.sc9 #termResizer{position:absolute;top:-4px;left:0;right:0;height:8px;cursor:ns-resize;z-index:20}
#terminalPanel.sc9 #termResizer:hover{background:var(--accent);opacity:.6}
#sc9Head{height:32px;flex:0 0 32px;display:flex;align-items:center;gap:3px;padding:0 6px;background:var(--bg-alt);border-bottom:1px solid var(--border)}
#sc9Tabs{display:flex;align-items:stretch;gap:2px;flex:1;min-width:0;height:100%;overflow-x:auto;overflow-y:hidden;scrollbar-width:none}
#sc9Tabs::-webkit-scrollbar{height:0}
.sc9-tab{display:flex;align-items:center;gap:7px;padding:0 8px 0 10px;height:32px;background:transparent;border:none;border-right:1px solid var(--border);color:var(--dim);font:500 12px/1 var(--font-ui);cursor:pointer;white-space:nowrap;flex:0 0 auto;max-width:190px;position:relative}
.sc9-tab:hover{background:var(--bg-hover);color:var(--text)}
.sc9-tab.on{background:var(--bg);color:var(--text)}
.sc9-tab.on::after{content:"";position:absolute;left:0;right:0;bottom:0;height:2px;background:var(--accent)}
.sc9-tab .dot{width:6px;height:6px;border-radius:50%;background:var(--success);flex:0 0 6px}
.sc9-tab.dead .dot{background:var(--dim)}
.sc9-tab.bell .dot{background:var(--warning)}
.sc9-tab .nm{overflow:hidden;text-overflow:ellipsis;min-width:0;flex:1}
.sc9-tab .cl{width:16px;height:16px;border-radius:3px;display:inline-flex;align-items:center;justify-content:center;font-size:13px;opacity:0;flex:0 0 16px}
.sc9-tab:hover .cl,.sc9-tab.on .cl{opacity:.6}
.sc9-tab .cl:hover{opacity:1;background:rgba(248,81,73,.2);color:var(--error)}
.sc9-btn{height:24px;min-width:24px;padding:0 7px;border-radius:5px;background:transparent;border:none;color:var(--dim);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:5px;font:500 12px/1 var(--font-ui)}
.sc9-btn:hover{background:var(--bg-hover);color:var(--text)}
.sc9-btn.pri{background:var(--accent);color:#fff}
.sc9-btn.pri:hover{filter:brightness(1.1)}
.sc9-btn.dgr:hover{color:var(--error)}
.sc9-btn:disabled{opacity:.4;cursor:not-allowed}
.sc9-sp{flex:1}
#terminalPanel.sc9 #xtermContainer{flex:1;position:relative;min-height:0;overflow:hidden;padding:0}
.sc9-term{position:absolute;inset:0;padding:6px 8px;display:none;overflow:hidden}
.sc9-term.on{display:block}
.sc9-term .xterm{height:100%}
.sc9-term .xterm-viewport::-webkit-scrollbar{width:10px}
.sc9-term .xterm-viewport::-webkit-scrollbar-track{background:transparent}
.sc9-term .xterm-viewport::-webkit-scrollbar-thumb{background:var(--border);border-radius:6px;border:2px solid transparent;background-clip:padding-box}
.sc9-term .xterm-viewport::-webkit-scrollbar-thumb:hover{background:var(--accent);background-clip:padding-box}
.sc9-term .xterm-viewport{scrollbar-width:thin;scrollbar-color:var(--border) transparent}
.sc9-fb{position:absolute;inset:6px 8px;display:flex;flex-direction:column;gap:6px}
.sc9-fb pre{flex:1;margin:0;overflow:auto;color:var(--text);font:12px/1.5 var(--font-mono);white-space:pre-wrap}
.sc9-fb input{height:28px;background:var(--bg-alt);border:1px solid var(--border);border-radius:5px;color:var(--text);padding:0 9px;font:12px var(--font-mono);outline:none}
.sc9-fb input:focus{border-color:var(--accent)}
#sc9Foot{flex:0 0 22px;height:22px;display:flex;align-items:center;gap:10px;padding:0 10px;background:var(--bg-alt);border-top:1px solid var(--border);font:500 10.5px/1 var(--font-mono);color:var(--dim);overflow:hidden;white-space:nowrap}
#sc9Foot b{color:var(--text);font-weight:600}
#sc9Foot .cs{overflow:hidden;text-overflow:ellipsis;max-width:46%}
#runPanel.sc9{height:220px;background:var(--bg);border-top:1px solid var(--border);display:none;flex-direction:column;flex-shrink:0}
#runPanel.sc9.open{display:flex}
#runPanel.sc9 #runOutput{flex:1;overflow:auto;padding:8px 12px;font:12px/1.55 var(--font-mono);color:var(--text);white-space:pre-wrap;background:transparent}
#runPanel.sc9 #runOutput::-webkit-scrollbar{width:10px}
#runPanel.sc9 #runOutput::-webkit-scrollbar-track{background:transparent}
#runPanel.sc9 #runOutput::-webkit-scrollbar-thumb{background:var(--border);border-radius:6px;border:2px solid transparent;background-clip:padding-box}
#runPanel.sc9 #runOutput::-webkit-scrollbar-thumb:hover{background:var(--accent);background-clip:padding-box}
#sc9RunBar{flex:0 0 38px;display:flex;align-items:center;gap:6px;padding:0 8px;background:var(--bg-alt);border-top:1px solid var(--border)}
#sc9RunIn{flex:1;min-width:0;height:26px;background:var(--bg);border:1px solid var(--border);border-radius:5px;color:var(--text);padding:0 9px;font:12px var(--font-mono);outline:none}
#sc9RunIn:focus{border-color:var(--accent)}
#sc9RunIn:disabled{opacity:.45}
.sc9-state{padding:2px 8px;border-radius:10px;font:600 10px/1.5 var(--font-ui);border:1px solid var(--border);color:var(--dim);margin-left:8px}
.sc9-state.run{color:var(--accent);border-color:var(--accent)}
.sc9-state.ok{color:var(--success);border-color:var(--success)}
.sc9-state.bad{color:var(--error);border-color:var(--error)}
#sc9Watch{display:none;align-items:center;gap:8px;padding:6px 12px;background:var(--bg-alt);border-bottom:1px solid var(--warning);font:500 11.5px/1.3 var(--font-ui);color:var(--text);flex:0 0 auto}
#sc9Watch.on{display:flex}
#sc9Undo{display:none;align-items:center;gap:5px;padding:1px 8px;border-radius:9px;background:rgba(255,255,255,.16);color:#fff;font:600 10px/1.6 var(--font-ui);cursor:pointer;border:none}
#sc9Undo.on{display:inline-flex}
#sc9Undo:hover{background:rgba(255,255,255,.3)}
.sc9-chip{padding:4px 10px;border-radius:12px;border:1px solid var(--border);background:var(--bg);color:var(--dim);font:600 11px/1 var(--font-ui);cursor:pointer;user-select:none}
.sc9-chip:hover{color:var(--text);background:var(--bg-hover)}
.sc9-chip.on{background:var(--accent);color:#fff;border-color:var(--accent)}
.sc9-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:9px}
.sc9-in{flex:1;min-width:170px;background:var(--bg);border:1px solid var(--border);color:var(--text);border-radius:6px;padding:8px 11px;font:12.5px var(--font-ui);outline:none}
.sc9-in:focus{border-color:var(--accent)}
.sc9-file{margin-bottom:8px;border:1px solid var(--border);border-radius:7px;overflow:hidden;background:var(--bg)}
.sc9-file>h5{margin:0;padding:6px 10px;background:var(--bg-alt);font:600 11px/1.3 var(--font-mono);color:var(--accent);display:flex;gap:8px;align-items:center}
.sc9-file>h5 span{margin-left:auto;color:var(--dim);font-size:10px}
.sc9-hit{padding:4px 10px;font:11.5px/1.5 var(--font-mono);color:var(--text);cursor:pointer;display:flex;gap:9px;border-top:1px solid var(--border)}
.sc9-hit:hover{background:var(--bg-hover)}
.sc9-hit i{color:var(--dim);font-style:normal;min-width:36px;text-align:right;flex:0 0 auto}
.sc9-hit em{font-style:normal;background:rgba(210,153,34,.32);border-radius:2px;padding:0 1px}
.sc9-empty{padding:30px;text-align:center;color:var(--dim);font:12px/1.6 var(--font-ui)}
.sc9-code{margin:7px 0;border:1px solid var(--border);border-radius:6px;overflow:hidden;background:var(--bg)}
.sc9-code .hd{display:flex;align-items:center;gap:6px;padding:4px 7px;background:var(--bg-alt);border-bottom:1px solid var(--border);font:600 10px/1.6 var(--font-mono);color:var(--dim)}
.sc9-code pre{margin:0;padding:8px 10px;overflow:auto;font:11.5px/1.55 var(--font-mono);color:var(--text);white-space:pre}
.sc9-code pre::-webkit-scrollbar{height:8px;width:8px}
.sc9-code pre::-webkit-scrollbar-thumb{background:var(--border);border-radius:5px}
.sc9-caret{display:inline-block;width:6px;height:12px;background:var(--accent);vertical-align:-2px;animation:sc9b .9s steps(2) infinite}
@keyframes sc9b{0%,50%{opacity:1}51%,100%{opacity:0}}
.sc9-diff{font:11.5px/1.6 var(--font-mono);white-space:pre;border:1px solid var(--border);border-radius:6px;overflow:hidden}
.sc9-diff div{padding:1px 11px}
.sc9-diff .a{background:rgba(63,185,80,.14)}
.sc9-diff .d{background:rgba(248,81,73,.14)}
.sc9-diff .s{color:var(--dim)}
.sc9-diff .h{background:var(--bg-alt);color:var(--accent);padding:5px 11px;font-weight:700}
.sc9-modal .modal{width:900px}
.sc9-modal .modal-body::-webkit-scrollbar{width:10px}
.sc9-modal .modal-body::-webkit-scrollbar-thumb{background:var(--border);border-radius:6px}
@media (max-width:760px){
  #terminalPanel.sc9{height:220px}
  #sc9Foot .cs{max-width:38%}
}
'''

# ══════════════════════════════════════════════════════════════════════
#  STUDIO JS
# ══════════════════════════════════════════════════════════════════════

STUDIO_JS = r'''
(function(){
'use strict';
if (window.__SC9__) return;
window.__SC9__ = true;

function API(){ return (window.pywebview && window.pywebview.api) || null; }
function el(i){ return document.getElementById(i); }
function mk(t,c,h){ var n=document.createElement(t); if(c)n.className=c; if(h!=null)n.innerHTML=h; return n; }
function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function say(m,t,d){ try{ toast(m,t||'info',d||2400); }catch(e){} }
function themes(){ return (typeof BUILTIN_THEMES!=='undefined' && BUILTIN_THEMES) || {}; }
function st(){ return window.settings || {}; }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }

/* ---------- renk: IDE temasindan terminal paleti ---------- */
function hex(v,f){
  var s=String(v==null?'':v).trim();
  if(!s) return f;
  if(s.charAt(0)!=='#') s='#'+s;
  if(/^#[0-9a-fA-F]{3}$/.test(s)) s='#'+s[1]+s[1]+s[2]+s[2]+s[3]+s[3];
  return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : f;
}
function rgb(h){ h=hex(h,'#000000'); return [parseInt(h.substr(1,2),16),parseInt(h.substr(3,2),16),parseInt(h.substr(5,2),16)]; }
function toHex(a){ return '#'+a.map(function(v){ var s=clamp(Math.round(v),0,255).toString(16); return s.length<2?'0'+s:s; }).join(''); }
function mix(a,b,t){ var x=rgb(a),y=rgb(b); return toHex([x[0]+(y[0]-x[0])*t,x[1]+(y[1]-x[1])*t,x[2]+(y[2]-x[2])*t]); }

function idePalette(){
  var s=st(), th=themes()[s.theme] || themes().obsidian || {};
  var light = (th.base==='vs');
  var bg   = hex(th.bg,      light?'#ffffff':'#0d1117');
  var surf = hex(th.bg_alt,  light?'#f6f8fa':'#161b22');
  var hov  = hex(th.bg_hover,light?'#eaeef2':'#1f242c');
  var fg   = hex(th.text,    light?'#1f2328':'#e6edf3');
  var dim  = hex(th.text_dim,light?'#656d76':'#7d8590');
  var acc  = hex(s.useCustomAccent ? s.customAccent : th.accent, '#2f81f7');
  var acc2 = hex(th.accent2, acc);
  var fn   = hex(th.function, acc2);
  var A = light
    ? {r:'#cf222e',g:'#1a7f37',y:'#9a6700',b:'#0969da',m:'#8250df',c:'#1b7c83',w:'#57606a',
       br:'#a40e26',bg2:'#116329',by:'#7d4e00',bb:'#0550ae',bm:'#6639ba',bc:'#0e6d77',bw:'#1f2328'}
    : {r:'#ff7b72',g:'#7ee787',y:'#f2cc60',b:'#79c0ff',m:'#d2a8ff',c:'#56d4dd',w:'#c9d1d9',
       br:'#ffa198',bg2:'#a5f3b4',by:'#f7de8b',bb:'#a5d6ff',bm:'#e2c5ff',bc:'#7fe3ea',bw:'#f0f6fc'};
  return {
    background: bg, foreground: fg,
    cursor: acc, cursorAccent: bg,
    selectionBackground: mix(bg, acc, light?0.22:0.34),
    selectionInactiveBackground: mix(bg, dim, 0.22),
    black: surf, red: A.r, green: A.g, yellow: A.y,
    blue: acc, magenta: fn, cyan: acc2, white: fg,
    brightBlack: dim, brightRed: A.br, brightGreen: A.bg2, brightYellow: A.by,
    brightBlue: mix(acc, A.bw, 0.35), brightMagenta: mix(fn, A.bw, 0.3),
    brightCyan: mix(acc2, A.bw, 0.3), brightWhite: light ? A.bw : mix(fg,'#ffffff',0.5),
    overviewRulerBorder: hov
  };
}
function termFont(){
  var f = String(st().fontFamily || 'JetBrains Mono').trim();
  if(/^(monospace|sans-serif|serif)$/i.test(f)) return f+', Consolas, monospace';
  return '"'+f+'", Consolas, "Courier New", monospace';
}
function termSize(){ return clamp(parseFloat(st().terminalFontSize)||13, 8, 28); }
function termScroll(){ return clamp(parseInt(st().terminalScrollback,10)||1500, 200, 20000); }

/* ---------- durum ---------- */
var TABS=[], ACT=null, SEQ=0, SIG='', paintQ=0, fitQ=0, tabSig='';
function find(id){ for(var i=0;i<TABS.length;i++) if(TABS[i].id===id) return TABS[i]; return null; }
function act(){ return find(ACT); }
function panel(){ return el('terminalPanel'); }
function stack(){ return el('xtermContainer'); }
function curCwd(){
  try{ if(typeof selectedPath!=='undefined' && selectedPath && selectedPath.path)
    return selectedPath.is_dir ? selectedPath.path : String(selectedPath.path).replace(/[\\/][^\\/]*$/,''); }catch(e){}
  try{ var t=aktifTab(); if(t&&t.path) return String(t.path).replace(/[\\/][^\\/]*$/,''); }catch(e){}
  return window._cwd || '';
}

/* ---------- tek seferlik DOM ---------- */
function shell(){
  var p=panel(); if(!p) return null;
  if(p.dataset.sc9==='1') return p;
  p.dataset.sc9='1'; p.classList.add('sc9');
  p.innerHTML='<div id="termResizer" title="Sürükle: yükseklik"></div>'+
    '<div id="sc9Head"><div id="sc9Tabs"></div>'+
    '<button class="sc9-btn" id="sc9New" title="Yeni terminal (Ctrl+Shift+T)">+</button>'+
    '<span class="sc9-sp"></span>'+
    '<button class="sc9-btn" id="sc9Clear" title="Ekranı temizle (Ctrl+L)">⌫</button>'+
    '<button class="sc9-btn dgr" id="sc9Kill" title="Süreci sonlandır">■</button>'+
    '<button class="sc9-btn dgr" id="sc9Close" title="Sekmeyi kapat (Ctrl+Shift+W)">✕</button></div>'+
    '<div id="xtermContainer"></div>'+
    '<div id="sc9Foot"><span class="cs" id="sc9Fcwd">—</span><span id="sc9Fsize">—</span>'+
    '<span id="sc9Ftheme">—</span><span class="sc9-sp"></span><span id="sc9Fstate">—</span></div>';
  el('sc9New').onclick=function(){ newTerm(curCwd()); };
  el('sc9Clear').onclick=function(){ var t=act(); if(t&&t.term) t.term.clear(); else if(t&&t.fbOut) t.fbOut.textContent=''; };
  el('sc9Kill').onclick=function(){ var t=act(); if(!t) return; var a=API(); if(a) a.terminal_kapat(t.id); t.dead=true; renderTabs(); say('Süreç sonlandırıldı','warning'); };
  el('sc9Close').onclick=function(){ closeTab(ACT); };
  var rz=el('termResizer'), drag=false, y0=0, h0=0;
  rz.addEventListener('mousedown',function(e){ drag=true; y0=e.clientY; h0=p.offsetHeight; document.body.style.userSelect='none'; e.preventDefault(); });
  document.addEventListener('mousemove',function(e){ if(!drag) return; p.style.height=clamp(h0-(e.clientY-y0),140,Math.round(window.innerHeight*0.8))+'px'; scheduleFit(); });
  document.addEventListener('mouseup',function(){ if(!drag) return; drag=false; document.body.style.userSelect=''; scheduleFit(); });
  return p;
}
function foot(){
  var t=act(), s=st(), th=themes()[s.theme]||{};
  var a=el('sc9Fcwd'), b=el('sc9Fsize'), c=el('sc9Ftheme'), d=el('sc9Fstate');
  if(a){ a.textContent=t?(t.cwd||'—'):'—'; a.title=t?(t.cwd||''):''; }
  if(b) b.textContent=t&&t.term?(t.term.cols+'×'+t.term.rows):'—';
  if(c) c.textContent=th.name||s.theme||'tema';
  if(d) d.textContent=t?(t.dead?'kapandı':'canlı'):'sekme yok';
}
function renderTabs(){
  var c=el('sc9Tabs'); if(!c) return;
  var sig=TABS.map(function(t){ return t.id+':'+t.name+':'+(t.dead?1:0); }).join('|');
  if(sig!==tabSig){
    tabSig=sig;
    c.innerHTML=TABS.map(function(t){
      return '<div class="sc9-tab'+(t.dead?' dead':'')+'" data-id="'+esc(t.id)+'">'+
        '<span class="dot"></span><span class="nm">'+esc(t.name)+'</span>'+
        '<span class="cl" data-cl="'+esc(t.id)+'">✕</span></div>';
    }).join('');
    Array.prototype.forEach.call(c.querySelectorAll('.sc9-tab'),function(n){
      n.onclick=function(e){ if(e.target.dataset.cl){ closeTab(e.target.dataset.cl); return; } activate(n.dataset.id); };
      n.ondblclick=function(){ var t=find(n.dataset.id); if(!t) return; var v=prompt('Terminal adı:',t.name); if(v){ t.name=v; renderTabs(); } };
    });
  }
  Array.prototype.forEach.call(c.querySelectorAll('.sc9-tab'),function(n){ n.classList.toggle('on', n.dataset.id===ACT); });
  foot();
}

/* ---------- olcu + fit (rAF ile birlestirilir) ---------- */
function dims(t){
  try{
    var w=t.host.clientWidth, h=t.host.clientHeight;
    if(w<24||h<24) return null;
    var core=t.term._core, d=core&&core._renderService&&core._renderService.dimensions;
    var cw=0, ch=0;
    if(d&&d.css&&d.css.cell.width>0&&d.css.cell.height>0){ cw=d.css.cell.width; ch=d.css.cell.height; }
    if(!cw||!ch){ var fs=t.term.options.fontSize||13; cw=fs*0.6; ch=Math.ceil(fs*1.2); }
    var sb=(core&&core.viewport&&core.viewport.scrollBarWidth)||0;
    var cs=getComputedStyle(t.host);
    var px=(parseFloat(cs.paddingLeft)||0)+(parseFloat(cs.paddingRight)||0);
    var py=(parseFloat(cs.paddingTop)||0)+(parseFloat(cs.paddingBottom)||0);
    return { cols:Math.max(2,Math.floor((w-px-sb)/cw)), rows:Math.max(1,Math.floor((h-py)/ch)) };
  }catch(e){ return null; }
}
function fit(t){
  if(!t||!t.term||!t.host||!t.host.offsetParent) return;
  var d=dims(t); if(!d) return;
  if(t.term.cols===d.cols && t.term.rows===d.rows) return;
  try{ t.term.resize(d.cols,d.rows); }catch(e){}
}
function scheduleFit(){
  if(fitQ) return;
  fitQ=requestAnimationFrame(function(){ fitQ=0; fit(act()); foot(); });
}

/* ---------- tema uygula: SADECE degisen secenekler ---------- */
function paint(){
  var pal=idePalette(), fs=termSize(), ff=termFont(), sb=termScroll();
  var sig=JSON.stringify(pal)+'|'+fs+'|'+ff+'|'+sb;
  if(sig===SIG){ foot(); return; }
  SIG=sig;
  var fontChanged=false;
  TABS.forEach(function(t){
    if(!t.term) return;
    var o=t.term.options;
    if(o.fontSize!==fs){ o.fontSize=fs; fontChanged=true; }
    if(o.fontFamily!==ff){ o.fontFamily=ff; fontChanged=true; }
    if(o.scrollback!==sb){ o.scrollback=sb; }
    o.theme=pal;
  });
  if(fontChanged) scheduleFit();
  foot();
}
function schedulePaint(){
  if(paintQ) return;
  paintQ=requestAnimationFrame(function(){ paintQ=0; paint(); });
}

/* ---------- terminal yasam dongusu ---------- */
function mount(t){
  if(typeof Terminal==='undefined'){ fallback(t); return; }
  try{
    var term=new Terminal({
      fontSize:termSize(), fontFamily:termFont(), lineHeight:1.2, letterSpacing:0,
      cursorStyle:'bar', cursorBlink:true, cursorWidth:2,
      scrollback:termScroll(), theme:idePalette(),
      allowProposedApi:true, allowTransparency:false,
      macOptionIsMeta:true, rightClickSelectsWord:true, smoothScrollDuration:0
    });
    t.term=term;
    term.open(t.host);
    term.onData(function(d){ var a=API(); if(a) a.terminal_yaz(t.id,d); });
    term.onResize(function(s){ var a=API(); if(a) a.terminal_yeniden_boyutlandir(t.id,s.rows,s.cols); foot(); });
    term.onBell(function(){
      var n=el('sc9Tabs') && el('sc9Tabs').querySelector('[data-id="'+t.id+'"]');
      if(n){ n.classList.add('bell'); setTimeout(function(){ n.classList.remove('bell'); },900); }
    });
    term.onTitleChange(function(x){ if(x && String(x).trim()){ t.name=String(x).trim().slice(0,40); renderTabs(); } });
    term.attachCustomKeyEventHandler(function(e){
      if(e.type!=='keydown') return true;
      if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==='c'&&term.hasSelection()){ try{ navigator.clipboard.writeText(term.getSelection()); }catch(x){} return false; }
      if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==='v'){ try{ navigator.clipboard.readText().then(function(x){ term.paste(x); }); }catch(x){} return false; }
      return true;
    });
    if(window.ResizeObserver){ t.ro=new ResizeObserver(scheduleFit); t.ro.observe(t.host); }
    requestAnimationFrame(function(){ fit(t); try{ term.focus(); }catch(e){} });
  }catch(e){ fallback(t); }
}
function fallback(t){
  t.host.innerHTML='<div class="sc9-fb"><pre></pre><input placeholder="Komut + Enter" autocomplete="off" spellcheck="false"></div>';
  t.fbOut=t.host.querySelector('pre');
  var i=t.host.querySelector('input');
  i.addEventListener('keydown',function(e){
    if(e.key!=='Enter') return;
    var a=API(); if(a) a.terminal_yaz(t.id,i.value+'\r');
    i.value='';
  });
  setTimeout(function(){ try{i.focus();}catch(e){} },50);
}
function newTerm(cwd,name){
  var a=API();
  if(!a||!a.terminal_ac){ say('Terminal API hazır değil','error'); return; }
  shell();
  var id='t'+(++SEQ)+'x'+Date.now().toString(36);
  var host=mk('div','sc9-term'); host.id='sc9Term_'+id;
  stack().appendChild(host);
  var t={id:id,name:name||('Terminal '+(TABS.length+1)),cwd:cwd||curCwd()||'',host:host,term:null,dead:false};
  TABS.push(t);
  openPanel(); activate(id);
  a.terminal_ac(t.cwd,null,t.name,t.id).then(function(r){
    if(!r||!r.ok){ t.dead=true; renderTabs(); say((r&&r.hata)||'PTY başlatılamadı','error',5000); return; }
    if(r.term_id && r.term_id!==t.id){
      var old=t.id; t.id=r.term_id; t.host.id='sc9Term_'+t.id;
      if(ACT===old) ACT=t.id;
      tabSig='';
    }
    if(r.cwd) t.cwd=r.cwd;
    mount(t); renderTabs(); schedulePaint();
    var a2=API(); if(a2&&a2.terminal_aktif_belirle) a2.terminal_aktif_belirle(t.id);
  }).catch(function(e){ t.dead=true; renderTabs(); say(String(e),'error'); });
}
function activate(id){
  var t=find(id); if(!t) return;
  ACT=id;
  TABS.forEach(function(x){ x.host.classList.toggle('on', x.id===id); });
  renderTabs(); scheduleFit();
  if(t.term){ try{ t.term.focus(); }catch(e){} }
  var a=API(); if(a&&a.terminal_aktif_belirle) a.terminal_aktif_belirle(t.id);
}
function closeTab(id){
  var t=find(id); if(!t) return;
  var a=API(); if(a) a.terminal_kapat(t.id);
  var snap={cwd:t.cwd,name:t.name};
  try{ if(t.ro) t.ro.disconnect(); }catch(e){}
  try{ if(t.term) t.term.dispose(); }catch(e){}
  try{ t.host.remove(); }catch(e){}
  var i=TABS.indexOf(t); TABS.splice(i,1); tabSig='';
  pushUndo('Terminal kapatıldı: '+snap.name, function(){ newTerm(snap.cwd,snap.name); });
  if(!TABS.length){ ACT=null; var p=panel(); if(p) p.classList.remove('open'); foot(); }
  else activate(TABS[Math.max(0,i-1)].id);
}
function openPanel(){ var p=shell(); if(!p) return; p.classList.add('open'); scheduleFit(); }

/* ---------- global kopru ---------- */
window.termWrite=function(d,id){
  var t=find(id)||act(); if(!t) return;
  if(t.term){ try{ t.term.write(d); }catch(e){} }
  else if(t.fbOut){ t.fbOut.textContent+=d; t.fbOut.scrollTop=t.fbOut.scrollHeight; }
};
window.termClosed=function(id){
  var t=find(id); if(!t) return;
  t.dead=true; renderTabs();
  if(t.term){ try{ t.term.write('\r\n\x1b[90m[oturum kapandı — + ile yenisi]\x1b[0m\r\n'); }catch(e){} }
};
window.terminalToggle=function(){
  var s=st();
  if((s.terminalMode||'internal')==='external'){
    var a=API(); if(a&&a.harici_terminal_ac){ a.harici_terminal_ac(curCwd(),null).then(function(r){ say(r&&r.ok?('Terminal: '+(r.terminal||'')):((r&&r.hata)||'Açılamadı'), r&&r.ok?'success':'error'); }); return; }
  }
  var p=shell(); if(!p) return;
  if(p.classList.contains('open') && TABS.length){ p.classList.remove('open'); return; }
  openPanel(); if(!TABS.length) newTerm(curCwd()); else scheduleFit();
};
window.initTerminal=function(){ openPanel(); if(!TABS.length) newTerm(curCwd()); };
window.terminalClose=function(){ if(TABS.length) closeTab(ACT); else { var p=panel(); if(p) p.classList.remove('open'); } };
window.terminalClear=function(){ var t=act(); if(t&&t.term) t.term.clear(); else if(t&&t.fbOut) t.fbOut.textContent=''; };
window._scFitTerm=scheduleFit;

var _treeAction=window.treeAction;
window.treeAction=function(a){
  if(a==='terminal'){
    var sp=(typeof selectedPath!=='undefined')?selectedPath:null;
    var dir=(sp&&sp.path)?(sp.is_dir?sp.path:String(sp.path).replace(/[\\/][^\\/]*$/,'')):curCwd();
    var m=el('contextMenu'); if(m) m.classList.remove('open');
    if((st().terminalMode||'internal')==='external'){
      var api=API(); if(api&&api.harici_terminal_ac){ api.harici_terminal_ac(dir,null); return; }
    }
    openPanel(); newTerm(dir); return;
  }
  return _treeAction ? _treeAction.apply(this,arguments) : undefined;
};

/* ---------- tema/ayar degisimini dinle ---------- */
var _tema=window.temaUygula;
if(typeof _tema==='function'){
  window.temaUygula=function(){ var r=_tema.apply(this,arguments); schedulePaint(); return r; };
}
var _ayk=window.ayarlariKaydet;
if(typeof _ayk==='function'){
  window.ayarlariKaydet=function(){ var r=_ayk.apply(this,arguments); SIG=''; schedulePaint(); return r; };
}
try{
  new MutationObserver(function(ms){
    for(var i=0;i<ms.length;i++){ if(ms[i].attributeName==='style'){ schedulePaint(); return; } }
  }).observe(document.documentElement,{attributes:true,attributeFilter:['style']});
}catch(e){}
window.addEventListener('resize',scheduleFit);

/* ---------- undo ---------- */
var UNDO=[];
function undoChip(){
  var c=el('sc9Undo');
  if(!c){
    var right=document.querySelector('#status .right'); if(!right) return;
    c=mk('button'); c.id='sc9Undo'; c.onclick=doUndo;
    right.insertBefore(c,right.firstChild);
  }
  if(UNDO.length){ c.classList.add('on'); c.textContent='↶ '+UNDO[UNDO.length-1].label; c.title='Geri al (Ctrl+Alt+Z)'; }
  else c.classList.remove('on');
}
function pushUndo(label,fn){
  UNDO.push({label:label,fn:fn});
  if(UNDO.length>20) UNDO.shift();
  undoChip(); say(label,'warning',3200);
}
function doUndo(){
  var u=UNDO.pop(); undoChip();
  if(!u){ say('Geri alınacak işlem yok'); return; }
  try{ u.fn(); say('Geri alındı: '+u.label,'success'); }catch(e){ say(String(e),'error'); }
}
window.sc9Undo=doUndo;

/* ---------- calistirma + stdin ---------- */
function runShell(){
  var p=el('runPanel'); if(!p||p.dataset.sc9==='1') return p;
  p.dataset.sc9='1'; p.classList.add('sc9');
  var hd=el('runHeader');
  if(hd && !el('sc9State')){ var s=mk('span','sc9-state','hazır'); s.id='sc9State'; hd.insertBefore(s,hd.children[1]||null); }
  if(!el('sc9RunBar')){
    var bar=mk('div'); bar.id='sc9RunBar';
    bar.innerHTML='<input id="sc9RunIn" placeholder="Program girdisi (stdin) — Enter ile gönder" disabled>'+
      '<button class="sc9-btn pri" id="sc9Send">Gönder</button>'+
      '<button class="sc9-btn" id="sc9Int" title="Ctrl+C">^C</button>'+
      '<button class="sc9-btn dgr" id="sc9Stop" title="Durdur">■</button>';
    p.appendChild(bar);
    function send(){
      var i=el('sc9RunIn'); if(!i||i.disabled) return;
      var a=API(); if(!a||!a.run_stdin) return;
      a.run_stdin(i.value+'\n').then(function(r){
        if(r&&r.ok){ out(i.value+'\n'); i.value=''; }
        else say((r&&r.hata)||'Gönderilemedi','error');
      });
    }
    el('sc9Send').onclick=send;
    el('sc9RunIn').addEventListener('keydown',function(e){ if(e.key==='Enter'){ e.preventDefault(); send(); } });
    el('sc9Int').onclick=function(){ var a=API(); if(a&&a.run_stdin) a.run_stdin('\x03'); };
    el('sc9Stop').onclick=function(){ window.durdur(); };
  }
  return p;
}
function out(s){
  var o=el('runOutput'); if(!o) return;
  o.textContent+=s;
  if(o.textContent.length>400000) o.textContent=o.textContent.slice(-300000);
  o.scrollTop=o.scrollHeight;
}
function runState(k,txt){
  var s=el('sc9State'); if(s){ s.className='sc9-state'+(k?' '+k:''); s.textContent=txt; }
  var i=el('sc9RunIn'); if(i) i.disabled=(k!=='run');
}
window.scRunOut=out;
window.runOutput=out;
window.scRunDone=function(rc){
  out('\n[çıkış kodu: '+(rc==null?'?':rc)+']\n');
  runState(rc===0?'ok':'bad', rc===0?'başarılı':'hata');
};
window.runDone=function(){ runState('ok','bitti'); };
window.durdur=function(){
  var a=API(); if(!a) return;
  var m=a.run_durdur||a.durdur;
  m.call(a).then(function(r){
    if(r&&r.ok){ out('\n[durduruldu]\n'); runState('bad','durduruldu'); }
    else say((r&&r.hata)||'Çalışan süreç yok');
  });
};
window.calistir=function(){
  var tb=null; try{ tb=aktifTab(); }catch(e){}
  if(!tb){ say('Dosya yok','warning'); return; }
  var a=API(); if(!a||!a.run_baslat){ say('Çalıştırma API hazır değil','error'); return; }
  var s=st();
  function go(content){
    runShell();
    var p=el('runPanel'); if(p) p.classList.add('open');
    var o=el('runOutput'); if(o) o.textContent='';
    runState('run','çalışıyor');
    var cwd=tb.path?String(tb.path).replace(/[\\/][^\\/]*$/,''):(window._cwd||'');
    a.run_baslat(tb.path||'',content,cwd).then(function(r){
      if(!r||!r.ok){ out('\nHata: '+((r&&r.hata)||'bilinmeyen')+'\n'); runState('bad','hata'); return; }
      out('> '+(r.cmd||'')+'\n\n');
    }).catch(function(e){ out('\n'+e+'\n'); runState('bad','hata'); });
  }
  if(tb.dirty && s.autoSaveBeforeRun!==false){ Promise.resolve(window.kaydet()).then(function(ok){ if(ok) go(null); }); return; }
  if(tb.dirty){ var c=''; try{ c=edGet(); }catch(e){} go(c); return; }
  if(!tb.path){ Promise.resolve(window.farkliKaydet()).then(function(ok){ if(ok) window.calistir(); }); return; }
  go(null);
};

/* ---------- dosya watcher ---------- */
var LAST_TREE=0;
function watchTick(){
  var a=API(); if(!a||!a.izleme_poll) return;
  var paths=[], tabs=window.tabs||[];
  tabs.forEach(function(t){ if(t.path) paths.push(t.path); });
  var dirs=[];
  try{
    Array.prototype.forEach.call(document.querySelectorAll('#tree .tree-children'),function(n){
      if(n.style.display==='none') return;
      var pv=n.previousElementSibling; if(!pv||!pv.dataset) return;
      var p=window._treeFiles&&window._treeFiles[pv.dataset.fid];
      if(p) dirs.push(p);
    });
  }catch(e){}
  a.izleme_poll(window._cwd||'',paths,dirs).then(function(r){
    if(!r||!r.ok||r.init) return;
    if(r.tree&&r.tree.length&&Date.now()-LAST_TREE>1600){ LAST_TREE=Date.now(); try{ refreshTree(); }catch(e){} }
    (r.changed||[]).forEach(function(p){ changed(p,false); });
    (r.deleted||[]).forEach(function(p){ changed(p,true); });
  }).catch(function(){});
}
function tabOf(p){ var ts=window.tabs||[]; for(var i=0;i<ts.length;i++) if(ts[i].path===p) return ts[i]; return null; }
function changed(p,del){
  var tb=tabOf(p); if(!tb) return;
  if(del){ say('Diskte silindi: '+tb.name,'error',4000); return; }
  var a=API(); if(!a) return;
  a.dosya_oku(p).then(function(y){
    if(!y||!y.ok||!tb.model) return;
    var old=tb.model.getValue(); if(old===y.content) return;
    if(!tb.dirty){
      tb.saving=true; tb.model.setValue(y.content); tb.saving=false; tb.dirty=false;
      try{ renderTabs(); }catch(e){}
      pushUndo('Diskten yenilendi: '+tb.name, function(){ tb.model.setValue(old); tb.dirty=true; try{renderTabs();}catch(e){} });
    } else conflict(tb,p,y.content,old);
  }).catch(function(){});
}
function conflict(tb,p,disk,mine){
  var bar=el('sc9Watch');
  if(!bar){
    bar=mk('div'); bar.id='sc9Watch';
    var c=el('center'); if(!c) return;
    c.insertBefore(bar,c.children[1]||c.firstChild);
  }
  bar.classList.add('on');
  bar.innerHTML='<span>⚠ <b>'+esc(tb.name)+'</b> diskte değişti; sende kaydedilmemiş değişiklik var.</span><span class="sc9-sp"></span>';
  var b1=mk('button','sc9-btn','Karşılaştır'), b2=mk('button','sc9-btn','Diskten al'), b3=mk('button','sc9-btn','Yoksay');
  bar.appendChild(b1); bar.appendChild(b2); bar.appendChild(b3);
  b3.onclick=function(){ bar.classList.remove('on'); };
  b2.onclick=function(){
    bar.classList.remove('on');
    tb.saving=true; tb.model.setValue(disk); tb.saving=false; tb.dirty=false; try{renderTabs();}catch(e){}
    pushUndo('Diskten alındı: '+tb.name, function(){ tb.model.setValue(mine); tb.dirty=true; try{renderTabs();}catch(e){} });
  };
  b1.onclick=function(){ bar.classList.remove('on'); diffModal(tb.name+' — disk ↔ editör', disk, mine, null); };
}

/* ---------- diff ---------- */
function diffLines(a,b){
  var A=String(a).replace(/\r\n/g,'\n').split('\n'), B=String(b).replace(/\r\n/g,'\n').split('\n');
  var n=A.length,m=B.length,out=[];
  if(n*m>360000){ var mx=Math.max(n,m); for(var k=0;k<mx;k++){ if(A[k]===B[k]) out.push([' ',A[k]||'']); else { if(k<n) out.push(['-',A[k]]); if(k<m) out.push(['+',B[k]]); } } return out; }
  var dp=[]; for(var i=0;i<=n;i++) dp.push(new Int32Array(m+1));
  for(var i=n-1;i>=0;i--) for(var j=m-1;j>=0;j--) dp[i][j]=A[i]===B[j]?dp[i+1][j+1]+1:Math.max(dp[i+1][j],dp[i][j+1]);
  var i=0,j=0;
  while(i<n&&j<m){ if(A[i]===B[j]){ out.push([' ',A[i]]); i++; j++; } else if(dp[i+1][j]>=dp[i][j+1]){ out.push(['-',A[i]]); i++; } else { out.push(['+',B[j]]); j++; } }
  while(i<n) out.push(['-',A[i++]]);
  while(j<m) out.push(['+',B[j++]]);
  return out;
}
function modal(title,bodyHtml,actions){
  var ov=mk('div','modal-overlay open sc9-modal');
  var box=mk('div','modal');
  var hd=mk('div','modal-header','<h2>'+esc(title)+'</h2>');
  var x=mk('button','icon-btn','✕'); x.onclick=function(){ ov.remove(); }; hd.appendChild(x);
  var bd=mk('div','modal-body',bodyHtml);
  var ft=mk('div','modal-footer');
  var sp=mk('span'); sp.style.flex='1';
  ft.appendChild(sp);
  (actions||[]).forEach(function(a){
    var b=mk('button','btn'+(a.pri?' primary':''),esc(a.label));
    b.onclick=function(){ a.fn(ov,bd); }; ft.appendChild(b);
  });
  var cl=mk('button','btn','Kapat'); cl.onclick=function(){ ov.remove(); }; ft.appendChild(cl);
  box.appendChild(hd); box.appendChild(bd); box.appendChild(ft); ov.appendChild(box);
  ov.addEventListener('mousedown',function(e){ if(e.target===ov) ov.remove(); });
  document.body.appendChild(ov);
  return {ov:ov,bd:bd};
}
function diffModal(title,oldT,newT,onApply){
  var d=diffLines(oldT,newT), add=0, del=0;
  var h='<div class="sc9-diff"><div class="h">'+esc(title)+'</div>';
  d.forEach(function(r){
    if(r[0]==='+')add++; if(r[0]==='-')del++;
    h+='<div class="'+(r[0]==='+'?'a':r[0]==='-'?'d':'s')+'">'+(r[0]===' '?'\u00a0':r[0])+' '+esc(r[1])+'</div>';
  });
  h+='</div>';
  var acts=[];
  if(onApply) acts.push({label:'Uygula (+'+add+' / −'+del+')',pri:true,fn:function(ov){ onApply(newT); ov.remove(); }});
  acts.push({label:'Panoya kopyala',fn:function(){ try{ navigator.clipboard.writeText(newT); say('Kopyalandı','success'); }catch(e){} }});
  modal('Değişiklik önizleme  ·  +'+add+' / −'+del,h,acts);
}

/* ---------- gelismis arama ---------- */
var SOPT={regex:false,case:false,whole:false,gitignore:true}, LASTQ='', deb=null;
function searchShell(){
  var ov=el('searchOverlay'); if(!ov) return null;
  var box=ov.querySelector('.modal'); if(!box) return null;
  if(box.dataset.sc9==='1') return box;
  box.dataset.sc9='1';
  box.innerHTML='<div class="modal-header"><h2>Projede Ara &amp; Değiştir</h2>'+
    '<span id="sc9SStat" style="margin-left:10px;font:600 10.5px var(--font-mono);color:var(--dim)">hazır</span>'+
    '<button class="icon-btn" id="sc9Sx">✕</button></div>'+
    '<div class="modal-body">'+
    '<div class="sc9-row"><input class="sc9-in" id="sc9Sq" placeholder="Aranacak metin veya regex…"></div>'+
    '<div class="sc9-row"><input class="sc9-in" id="sc9Sr" placeholder="Değiştir (boş = sadece ara)"></div>'+
    '<div class="sc9-row"><input class="sc9-in" id="sc9Si" placeholder="Dahil: *.py, src/**"><input class="sc9-in" id="sc9Se" placeholder="Hariç: *.min.js, tests/**"></div>'+
    '<div class="sc9-row"><span class="sc9-chip" data-o="regex">.* Regex</span>'+
    '<span class="sc9-chip" data-o="case">Aa Büyük/küçük</span>'+
    '<span class="sc9-chip" data-o="whole">|w| Tam kelime</span>'+
    '<span class="sc9-chip on" data-o="gitignore">.gitignore</span>'+
    '<span class="sc9-sp"></span><button class="btn primary" id="sc9Sgo">Ara</button>'+
    '<button class="btn" id="sc9Srep">Tümünü değiştir</button></div>'+
    '<div id="sc9Sres"></div></div>';
  el('sc9Sx').onclick=function(){ ov.classList.remove('open'); };
  Array.prototype.forEach.call(box.querySelectorAll('.sc9-chip'),function(c){
    c.onclick=function(){ var k=c.dataset.o; SOPT[k]=!SOPT[k]; c.classList.toggle('on',SOPT[k]); runSearch(); };
  });
  el('sc9Sgo').onclick=runSearch;
  el('sc9Srep').onclick=runReplace;
  el('sc9Sq').addEventListener('input',function(){ clearTimeout(deb); deb=setTimeout(runSearch,300); });
  el('sc9Sq').addEventListener('keydown',function(e){ if(e.key==='Enter'){ e.preventDefault(); runSearch(); } });
  ['sc9Si','sc9Se'].forEach(function(i){ el(i).addEventListener('input',function(){ clearTimeout(deb); deb=setTimeout(runSearch,400); }); });
  return box;
}
function sopts(){
  var o=JSON.parse(JSON.stringify(SOPT));
  o.include=(el('sc9Si')||{}).value||''; o.exclude=(el('sc9Se')||{}).value||''; o.limit=800;
  return o;
}
function runSearch(){
  var a=API(); if(!a||!a.arama_v2) return;
  var q=(el('sc9Sq')||{}).value||''; LASTQ=q;
  var res=el('sc9Sres'), stt=el('sc9SStat'); if(!res) return;
  if(!q){ res.innerHTML='<div class="sc9-empty">Aramak için bir şey yaz.<br>Regex, tam kelime ve .gitignore filtreleri canlı çalışır.</div>'; if(stt) stt.textContent='hazır'; return; }
  if(!window._cwd){ res.innerHTML='<div class="sc9-empty">Önce bir proje klasörü aç.</div>'; return; }
  if(stt) stt.textContent='arıyor…';
  a.arama_v2(q,window._cwd,sopts()).then(function(r){
    if(!r||!r.ok){ res.innerHTML='<div class="sc9-empty">'+esc((r&&r.hata)||'Arama başarısız')+'</div>'; if(stt) stt.textContent='hata'; return; }
    if(stt) stt.textContent=r.hits.length+' sonuç · '+r.files+' dosya · '+r.scanned+' tarandı';
    if(!r.hits.length){ res.innerHTML='<div class="sc9-empty">Eşleşme yok.</div>'; return; }
    var by={};
    r.hits.forEach(function(h){ (by[h.path]=by[h.path]||{rel:h.rel,rows:[]}).rows.push(h); });
    var h='';
    Object.keys(by).forEach(function(p){
      var g=by[p];
      h+='<div class="sc9-file"><h5>'+esc(g.rel)+'<span>'+g.rows.length+'</span></h5>';
      g.rows.slice(0,60).forEach(function(x){
        var t=esc(x.text), qq=esc(LASTQ);
        if(!SOPT.regex&&qq){ try{ t=t.replace(new RegExp(qq.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),SOPT.case?'g':'gi'),function(m){ return '<em>'+m+'</em>'; }); }catch(e){} }
        h+='<div class="sc9-hit" data-p="'+esc(p)+'" data-l="'+x.line+'"><i>'+x.line+'</i><span>'+t+'</span></div>';
      });
      h+='</div>';
    });
    if(r.truncated) h+='<div class="sc9-empty">İlk '+r.hits.length+' sonuç gösteriliyor — deseni daralt.</div>';
    res.innerHTML=h;
    Array.prototype.forEach.call(res.querySelectorAll('.sc9-hit'),function(n){
      n.onclick=function(){
        var ov=el('searchOverlay'); if(ov) ov.classList.remove('open');
        try{ dosyaAcYol(n.dataset.p); }catch(e){}
        var ln=parseInt(n.dataset.l,10)||1;
        setTimeout(function(){ try{ editor.revealLineInCenter(ln); editor.setPosition({lineNumber:ln,column:1}); editor.focus(); }catch(e){} },380);
      };
    });
  }).catch(function(e){ if(stt) stt.textContent='hata'; res.innerHTML='<div class="sc9-empty">'+esc(String(e))+'</div>'; });
}
function runReplace(){
  var a=API(); if(!a||!a.degistir_v2) return;
  var q=(el('sc9Sq')||{}).value||'', rp=(el('sc9Sr')||{}).value||'';
  if(!q||!window._cwd){ say('Arama metni ve proje gerekli','warning'); return; }
  if(!confirm('Tüm projede değiştirilsin mi?\n\n'+q+'  →  '+rp)) return;
  a.degistir_v2(q,rp,window._cwd,sopts()).then(function(r){
    if(!r||!r.ok){ say((r&&r.hata)||'Değiştirilemedi','error'); return; }
    var bk=r.backup||[];
    pushUndo(r.replacements+' değişiklik / '+r.changed_files+' dosya', function(){
      var a2=API(); if(a2&&a2.geri_al) a2.geri_al(bk).then(function(){ try{refreshTree();}catch(e){} });
    });
    try{ refreshTree(); }catch(e){}
    runSearch();
  });
}
window.searchAc=function(){
  var ov=el('searchOverlay'); if(!ov) return;
  searchShell(); ov.classList.add('open');
  setTimeout(function(){ var i=el('sc9Sq'); if(i) i.focus(); },50);
};
window.doSearch=runSearch;

/* ---------- AI akis + diff uygula ---------- */
var STREAMS={};
window.__scAiHist=window.__scAiHist||[];
function blocks(text){ var o=[],rx=/```([A-Za-z0-9_+-]*)\n([\s\S]*?)```/g,m; while((m=rx.exec(text))) o.push({lang:m[1]||'text',code:m[2]}); return o; }
function renderAi(node,text,live){
  var bs=blocks(text);
  if(!bs.length){ node.textContent=text; if(live) node.appendChild(mk('span','sc9-caret')); return; }
  var parts=text.split(/```[A-Za-z0-9_+-]*\n[\s\S]*?```/g), h='';
  for(var i=0;i<parts.length;i++){
    if(parts[i]) h+='<div style="white-space:pre-wrap">'+esc(parts[i])+'</div>';
    if(bs[i]) h+='<div class="sc9-code"><div class="hd"><span>'+esc(bs[i].lang)+'</span><span class="sc9-sp"></span>'+
      '<button class="sc9-btn" data-copy="'+i+'">Kopyala</button>'+
      '<button class="sc9-btn pri" data-apply="'+i+'">Editöre uygula</button></div><pre>'+esc(bs[i].code)+'</pre></div>';
  }
  node.innerHTML=h;
  if(live) node.appendChild(mk('span','sc9-caret'));
  Array.prototype.forEach.call(node.querySelectorAll('[data-copy]'),function(b){
    b.onclick=function(){ try{ navigator.clipboard.writeText(bs[+b.dataset.copy].code); say('Kod kopyalandı','success'); }catch(e){} };
  });
  Array.prototype.forEach.call(node.querySelectorAll('[data-apply]'),function(b){
    b.onclick=function(){
      var code=bs[+b.dataset.apply].code, cur='';
      try{ cur=edGet(); }catch(e){}
      diffModal('AI önerisi → aktif editör',cur,code,function(nt){
        var old=cur;
        try{ edSet(nt); }catch(e){ say('Editör yok','error'); return; }
        pushUndo('AI kodu uygulandı',function(){ try{ edSet(old); }catch(e){} });
      });
    };
  });
}
window.scAiChunk=function(sid,t){
  var s=STREAMS[sid]; if(!s) return;
  s.text+=t; renderAi(s.node,s.text,true);
  var m=el('aiMessages'); if(m) m.scrollTop=m.scrollHeight;
};
window.scAiDone=function(sid,full,err,cancelled){
  var s=STREAMS[sid]; if(!s) return;
  delete STREAMS[sid];
  var txt=full||s.text;
  if(err){ s.node.textContent='Hata: '+err; }
  else { renderAi(s.node,txt,false); window.__scAiHist.push({role:'assistant',content:txt}); }
  var b=el('aiSendBtn');
  if(b){ b.disabled=false; b.innerHTML=(typeof svgIcon==='function')?svgIcon('send',16):'➤'; b.onclick=window.aiSend; b.title='Gönder'; }
  var m=el('aiMessages'); if(m) m.scrollTop=m.scrollHeight;
};
window.aiSend=function(){
  var inp=el('aiInput'); if(!inp) return;
  var txt=(inp.value||'').trim(); if(!txt) return;
  var a=API(); if(!a||!a.ai_stream_baslat){ say('AI akışı hazır değil','error'); return; }
  if(!st().ai_provider){ say('Ayarlar → AI sağlayıcı seç','warning'); return; }
  inp.value='';
  var msgs=el('aiMessages');
  var u=mk('div','ai-msg user'); u.textContent=txt; msgs.appendChild(u);
  window.__scAiHist.push({role:'user',content:txt});
  var node=mk('div','ai-msg assistant'); node.appendChild(mk('span','sc9-caret')); msgs.appendChild(node);
  msgs.scrollTop=msgs.scrollHeight;
  var ctx=''; try{ ctx=edGet(); }catch(e){}
  a.ai_stream_baslat(window.__scAiHist.slice(-12),ctx).then(function(r){
    if(!r||!r.ok){ node.textContent='Hata: '+((r&&r.hata)||'başlatılamadı'); return; }
    STREAMS[r.id]={node:node,text:''};
    var b=el('aiSendBtn');
    if(b){ b.innerHTML='■'; b.title='Durdur'; b.onclick=function(){ a.ai_stream_durdur(r.id); }; }
  }).catch(function(e){ node.textContent='Hata: '+e; });
};
window.aiClear=function(){
  window.__scAiHist=[];
  var m=el('aiMessages'); if(m) m.innerHTML='<div class="ai-msg assistant">Temizlendi. Yeni bir soru sor!</div>';
};

/* ---------- komut paleti entegrasyonu ---------- */
var EXTRA=[
  {label:'Yeni Terminal Sekmesi',shortcut:'Ctrl+Shift+T',action:function(){ openPanel(); newTerm(curCwd()); }},
  {label:'Terminal Sekmesini Kapat',shortcut:'Ctrl+Shift+W',action:function(){ if(TABS.length) closeTab(ACT); }},
  {label:'Terminali Temizle',action:function(){ window.terminalClear(); }},
  {label:'Projede Ara (gelişmiş)',shortcut:'Ctrl+Shift+F',action:function(){ window.searchAc(); }},
  {label:'Son İşlemi Geri Al',shortcut:'Ctrl+Alt+Z',action:doUndo},
  {label:'Fontları Çevrimdışı Yap',action:function(){
    var a=API(); if(!a||!a.font_yerellestir) return;
    say('Fontlar indiriliyor…');
    a.font_yerellestir().then(function(r){
      if(r&&r.ok) say(r.files+' font yerelleştirildi. Yeniden başlat.','success',5000);
      else say((r&&r.hata)||'Font indirilemedi','error',5000);
    });
  }},
  {label:'Terminal Temasını Yenile',action:function(){ SIG=''; schedulePaint(); say('Terminal teması yenilendi','success'); }}
];
var _rcp=window.renderCmdPalette;
if(typeof _rcp==='function'){
  window.renderCmdPalette=function(q){
    _rcp.apply(this,arguments);
    var list=el('cmdPaletteList'); if(!list) return;
    var ql=String(q||'').toLowerCase();
    var hits=EXTRA.filter(function(c){ return c.label.toLowerCase().indexOf(ql)>=0; });
    if(!hits.length) return;
    window._cmdList=(window._cmdList||[]).concat(hits);
    var base=window._cmdList.length-hits.length;
    var h=hits.map(function(c,i){
      return '<div class="cmd-item" onclick="runCmd('+(base+i)+',\'\')"><span class="cmd-label">'+esc(c.label)+
        '</span>'+(c.shortcut?'<span class="cmd-shortcut">'+c.shortcut+'</span>':'')+'</div>';
    }).join('');
    list.insertAdjacentHTML('beforeend',h);
  };
}

/* ---------- kisayollar ---------- */
document.addEventListener('keydown',function(e){
  var c=e.ctrlKey||e.metaKey;
  if(c&&e.shiftKey&&e.key.toLowerCase()==='t'){ e.preventDefault(); e.stopPropagation(); openPanel(); newTerm(curCwd()); }
  else if(c&&e.shiftKey&&e.key.toLowerCase()==='w'){ if(TABS.length){ e.preventDefault(); e.stopPropagation(); closeTab(ACT); } }
  else if(c&&e.altKey&&e.key.toLowerCase()==='z'){ e.preventDefault(); e.stopPropagation(); doUndo(); }
},true);

/* ---------- boot ---------- */
function boot(){
  var a=API();
  if(!a||!a.terminal_ac||!window.settings){ setTimeout(boot,200); return; }
  if(a.studio_ayar_sifirla) a.studio_ayar_sifirla();
  runShell(); undoChip(); paint();
  setInterval(watchTick,2500);
  setTimeout(function(){ try{ gitYenile(); }catch(e){} },1200);
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();
'''

# ══════════════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════════════

SKIP = {".git", ".venv", "venv", "node_modules", "_backups",
        ".idea", ".vscode", "dist", "build"}
MAXB = 25 * 1024 * 1024
OLD_RE = re.compile(
    r"[ \t]*<!--SC-STUDIO-008-->\s*<style>.*?</style>\s*<script>.*?</script>\s*",
    re.S)


def find_root(cli=None):
    cands = []
    if cli:
        cands.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    cands.append(here)
    cands.append(os.getcwd())
    cands.append(os.path.dirname(here))
    for p in cands:
        try:
            if p and os.path.isdir(os.path.join(p, 'splash_code')):
                return p
        except Exception:
            continue
    return here


def rd(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def wr(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def pycache(root):
    t = []
    for dp, dn, fn in os.walk(root):
        if os.path.basename(dp) == "__pycache__":
            t.append(dp)
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in SKIP]
    for x in t:
        shutil.rmtree(x, ignore_errors=True)
    return len(t)


def backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAXB:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def strip_old(src):
    if OLD_MARK not in src:
        return src, 0
    m = OLD_RE.search(src)
    if m:
        return src[:m.start()] + src[m.end():], len(m.group(0))
    i = src.index(OLD_MARK)
    j = src.find("</script>", i)
    if j >= 0:
        j = src.find("</script>", j + 9)
    if j >= 0:
        j += 9
        return src[:i] + src[j:], j - i
    return src, -1


def plan(root):
    ops, probs, notes = [], [], []

    p = os.path.join(root, "splash_code", "api.py")
    if not os.path.isfile(p):
        probs.append("splash_code/api.py yok")
    else:
        src = rd(p)
        if PY_MARK in src:
            ops.append(("splash_code/api.py", None, "ZATEN"))
        else:
            body = API_APPEND.strip("\n")
            new = src if src.endswith("\n") else src + "\n"
            new += "\n" + body + "\n"
            ops.append(("splash_code/api.py", new,
                        "+%d satir" % len(body.splitlines())))

    hp = os.path.join(root, HTML_REL)
    if not os.path.isfile(hp):
        probs.append(HTML_REL + " yok")
    else:
        src = rd(hp)
        if MARK in src:
            ops.append((HTML_REL, None, "ZATEN"))
        else:
            base, removed = strip_old(src)
            if removed < 0:
                probs.append("008 blogu bulunamadi ama isaretci var")
            elif removed:
                notes.append(("KALDIR", "Studio 008 blogu: -%d KB"
                              % (removed // 1024)))
            else:
                notes.append(("BILGI", "008 blogu yok (temiz kurulum)"))
            payload = ("\n<!--%s-->\n<style>\n%s\n</style>\n<script>\n%s\n</script>\n"
                       % (MARK, STUDIO_CSS.strip("\n"), STUDIO_JS.strip("\n")))
            low = base.lower()
            i = low.rfind("</body>")
            if i < 0:
                probs.append(HTML_REL + ": </body> yok")
            else:
                ops.append((HTML_REL, base[:i] + payload + base[i:],
                            "+%d KB uyum katmani" % (len(payload) // 1024)))
                notes.append(("EKLE", "Terminal IDE temasina baglandi"))
                notes.append(("EKLE", "Studio reyonu / neon palet kaldirildi"))
    return ops, probs, notes


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc009.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                if k in names:
                    with open(os.path.join(root, rel), "wb") as f:
                        f.write(z.read(k))
                    print("    geri: " + rel)
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Elle ac: %s" % zp)


def restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: " + zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def check(root):
    print("\n  --- TANI ---")

    def g(rel):
        try:
            return rd(os.path.join(root, rel))
        except Exception:
            return ""

    idx = g(HTML_REL)
    api = g("splash_code/api.py")
    print("  Studio 008 (neon)      : %s"
          % ("VAR -> kaldirilacak" if OLD_MARK in idx else "YOK"))
    print("  Uyum 009               : %s"
          % ("VAR" if MARK in idx else "YOK"))
    print("  api terminal_ac id fix : %s"
          % ("VAR" if PY_MARK in api else "YOK  <-- GIRDISIZ TERMINAL SEBEBI"))
    print("  api _send_to_term fix  : %s"
          % ("VAR" if "Api._send_to_term" in api else "YOK"))
    print("  xterm AMD kalkani      : %s"
          % ("VAR" if "SC-XT-SHIELD" in idx else "YOK"))
    print("  xterm inline kopya     : %d"
          % idx.count("t.AccessibilityManager=void 0"))
    ml = os.path.join(root, "splash_code", "static", "monaco", "vs", "loader.js")
    fl = os.path.join(root, "splash_code", "static", "fonts", "sc-fonts.css")
    print("  Yerel Monaco           : %s"
          % ("VAR" if os.path.isfile(ml) else "YOK"))
    print("  Yerel fontlar          : %s"
          % ("VAR" if os.path.isfile(fl) else "YOK -> komut paletinden indir"))
    sf = os.path.join(os.path.expanduser("~"), ".splash_code", "studio.json")
    print("  Eski neon ayari        : %s"
          % ("VAR -> silinecek" if os.path.isfile(sf) else "YOK"))
    print("  index.html             : %.0f KB" % (len(idx) / 1024.0))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 66)
    print("  Splash Code Studio - Patch %s  \"Uyum\"" % PATCH_ID)
    print("  " + TITLE)
    print("=" * 66)
    print("  Kok: " + root)

    if a.restore:
        return restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok. --root ver.")
        return 1
    if a.check:
        return check(root)

    print("\n  On-kontrol (bellekte derleme)...")
    p = os.path.join(root, "splash_code", "api.py")
    if os.path.isfile(p):
        try:
            compile((rd(p) + "\n" + API_APPEND).encode("utf-8"),
                    "api.py", "exec")
        except SyntaxError as e:
            print("    X api.py satir %s: %s" % (e.lineno, e.msg))
            print("  Hicbir sey yazilmadi.")
            return 2
    print("    Python OK  ·  JS %d KB  ·  CSS %d KB"
          % (len(STUDIO_JS) // 1024, len(STUDIO_CSS) // 1024))

    ops, probs, notes = plan(root)
    if notes:
        print("\n  Islem:")
        for t, d in notes:
            print("    [%-7s] %s" % (t, d))
    print("\n  Plan:")
    for rel, new, info in ops:
        print("    %-34s %s" % (rel, info))
    if probs:
        print("\n  !! SORUN:")
        for x in probs:
            print("     - " + x)
        print("  Hicbir sey yazilmadi.")
        return 2

    todo = [(r, c) for r, c, _ in ops if c is not None]
    if not todo:
        print("\n  Zaten uygulanmis.")
        return 0
    if a.dry_run:
        print("\n  --dry-run: temiz. (%d dosya)" % len(todo))
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = backup(root)
        print("    %s (%d dosya)" % (zp, n))

    touched = []
    try:
        for rel, content in todo:
            wr(os.path.join(root, rel), content)
            touched.append(rel)
            print("    + " + rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Disk dogrulamasi...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK  ·  %d __pycache__ silindi" % pycache(root))

    print("\n" + "=" * 66)
    print("  Patch %s UYGULANDI" % PATCH_ID)
    if zp:
        print("  Geri al: py path.py --restore \"%s\"" % zp)
    print("  py main.py")
    print("    1) Terminal ac -> IDE temasiyla ayni zemin/renk")
    print("    2) Komut yaz -> ARTIK CALISIYOR")
    print("    3) Tema galerisinden tema degistir -> aninda, takilmadan")
    print("    4) Ayarlar > terminal font/scrollback -> aninda")
    print("    5) Ctrl+Shift+T / Ctrl+Shift+W -> sekme ac/kapat")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
