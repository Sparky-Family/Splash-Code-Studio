#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 001
Çekirdek stabilizasyon: log altyapısı + terminal + LSP

Kullanım:
    python patch.py                 # uygula (backup + doğrulama + auto-rollback)
    python patch.py --dry-run       # sadece ne değişeceğini göster
    python patch.py --no-backup     # backup almadan (önerilmez)
    python patch.py --restore ZIP   # eski bir backup'tan geri dön
"""

import argparse
import os
import py_compile
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "001"
TITLE = "Cekirdek stabilizasyon: log + terminal + LSP"

# ══════════════════════════════════════════════════════════════
#  DOSYA İÇERİKLERİ
# ══════════════════════════════════════════════════════════════

LOG_PY = r'''"""
Splash Code Studio - Merkezi loglama ve hata yakalama
~/.splash_code/splash.log (2MB x 3 rotasyon)
"""
import functools
import logging
import logging.handlers
import os
import sys
import traceback

from .constants import SETTINGS_DIR

LOG_FILE = os.path.join(SETTINGS_DIR, "splash.log")
_logger = None


def get_logger():
    """Singleton logger (thread-safe enough: logging modülü kilitli)."""
    global _logger
    if _logger is not None:
        return _logger
    lg = logging.getLogger("splash")
    lg.setLevel(logging.DEBUG)
    lg.propagate = False
    if not lg.handlers:
        try:
            os.makedirs(SETTINGS_DIR, exist_ok=True)
            fh = logging.handlers.RotatingFileHandler(
                LOG_FILE, maxBytes=2 * 1024 * 1024,
                backupCount=3, encoding="utf-8")
            fh.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)-7s [%(threadName)s] %(message)s"))
            lg.addHandler(fh)
        except Exception:
            lg.addHandler(logging.NullHandler())
        if os.environ.get("SPLASH_DEBUG"):
            sh = logging.StreamHandler(sys.stderr)
            sh.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
            lg.addHandler(sh)
    _logger = lg
    return lg


def info(msg, *args):
    try:
        get_logger().info(msg, *args)
    except Exception:
        pass


def warn(msg, *args):
    try:
        get_logger().warning(msg, *args)
    except Exception:
        pass


def error(msg, *args):
    try:
        get_logger().error(msg, *args)
    except Exception:
        pass


def exc(msg, e=None):
    """Aktif exception'ı traceback ile loglar."""
    try:
        suffix = (": %s" % e) if e is not None else ""
        get_logger().error("%s%s\n%s", msg, suffix, traceback.format_exc())
    except Exception:
        pass


def safe(default=None):
    """Decorator: hatayı loglar ve varsayılan değeri döndürür.

    @safe(default=lambda: {"ok": False})
    def bir_sey(): ...
    """
    def deco(fn):
        @functools.wraps(fn)
        def wrap(*a, **kw):
            try:
                return fn(*a, **kw)
            except Exception as e:
                exc(fn.__qualname__, e)
                return default() if callable(default) else default
        return wrap
    return deco
'''

TERMINAL_PY = r'''"""
Splash Code Studio - Terminal PTY Yönetimi
pywinpty (Windows) / ptyprocess (Unix)

Düzeltmeler:
  * RLock  -> iç içe kilitlenme yok
  * Kilit altında asla I/O yapılmaz
  * Queue'lu writer thread -> sıralı çıktı + zaman tabanlı flush
  * env winpty'ye de geçiriliyor
  * Reader: ölü süreçte sonsuz döngü koruması
  * Çoklu terminal altyapısı hazır
"""
import os
import queue
import shutil
import threading
import time

from .log import exc, info, warn

_TERM_PROCS = {}
_TERM_LOCK = threading.RLock()

_MAX_CHUNK = 8000
_FLUSH_INTERVAL = 0.035
_READ_ERRORS_LIMIT = 20


def _alive(proc):
    try:
        return bool(proc.isalive())
    except Exception:
        return False


def _notify_frontend(func_name, data, term_id):
    """Frontend'e JS çağrısı gönderir (kilit DIŞINDA çağrılmalı)."""
    try:
        import webview
        if not webview.windows:
            return
        import json as _json
        if data is None:
            js = (f"if(window.{func_name}) "
                  f"window.{func_name}({_json.dumps(term_id)});")
        else:
            js = (f"if(window.{func_name}) "
                  f"window.{func_name}({_json.dumps(data)}, "
                  f"{_json.dumps(term_id)});")
        webview.windows[0].evaluate_js(js)
    except Exception as e:
        warn("term notify %s basarisiz: %s", func_name, e)


def term_spawn(term_id, cwd, shell_cmd=None):
    """Yeni PTY terminal süreci başlatır."""
    term_id = str(term_id or "t1")
    try:
        term_close(term_id)

        if not cwd or not os.path.isdir(str(cwd)):
            cwd = os.getcwd()
        cwd = os.path.abspath(cwd)

        env = dict(os.environ)
        env.setdefault("TERM", "xterm-256color")
        env.setdefault("COLORTERM", "truecolor")
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUNBUFFERED"] = "1"

        if os.name == "nt":
            try:
                from winpty import PtyProcess as WPy
            except ImportError:
                return {"ok": False,
                        "hata": "pywinpty yok. pip install pywinpty"}
            shell = shell_cmd or (
                shutil.which("pwsh")
                or shutil.which("powershell")
                or "powershell.exe")
            argv = [shell] if isinstance(shell, str) else list(shell)
            try:
                proc = WPy.spawn(argv, cwd=cwd, env=env,
                                 dimensions=(30, 120))
            except TypeError:
                proc = WPy.spawn(argv, cwd=cwd, dimensions=(30, 120))
        else:
            try:
                import ptyprocess
            except ImportError:
                return {"ok": False,
                        "hata": "ptyprocess yok. pip install ptyprocess"}
            shell = shell_cmd or os.environ.get("SHELL", "/bin/bash")
            argv = [shell] if isinstance(shell, str) else list(shell)
            proc = ptyprocess.PtyProcessUnicode.spawn(
                argv, cwd=cwd, env=env, dimensions=(30, 120))

        q = queue.Queue()
        stop = threading.Event()
        entry = {"proc": proc, "q": q, "stop": stop, "cwd": cwd}
        with _TERM_LOCK:
            _TERM_PROCS[term_id] = entry

        def reader():
            errs = 0
            while not stop.is_set():
                try:
                    data = proc.read(4096)
                except EOFError:
                    break
                except Exception:
                    errs += 1
                    if errs > _READ_ERRORS_LIMIT or not _alive(proc):
                        break
                    time.sleep(0.02)
                    continue
                if not data:
                    if not _alive(proc):
                        break
                    continue
                errs = 0
                if isinstance(data, bytes):
                    data = data.decode("utf-8", "replace")
                q.put(data)
            q.put(None)

        def writer():
            buf, size, first = [], 0, 0.0
            while True:
                wait = _FLUSH_INTERVAL if not size else _FLUSH_INTERVAL / 3
                try:
                    item = q.get(timeout=wait)
                except queue.Empty:
                    item = ""
                if item is None:
                    break
                if item:
                    if not size:
                        first = time.time()
                    buf.append(item)
                    size += len(item)
                if size and (size >= _MAX_CHUNK
                             or time.time() - first >= _FLUSH_INTERVAL):
                    chunk = "".join(buf)
                    buf, size, first = [], 0, 0.0
                    _notify_frontend("termWrite", chunk, term_id)
            if buf:
                _notify_frontend("termWrite", "".join(buf), term_id)
            _notify_frontend("termClosed", None, term_id)
            with _TERM_LOCK:
                cur = _TERM_PROCS.get(term_id)
                if cur is entry:
                    _TERM_PROCS.pop(term_id, None)
            info("terminal kapandi: %s", term_id)

        threading.Thread(target=reader, name=f"term-r-{term_id}",
                         daemon=True).start()
        threading.Thread(target=writer, name=f"term-w-{term_id}",
                         daemon=True).start()
        info("terminal basladi: %s (cwd=%s)", term_id, cwd)
        return {"ok": True, "cwd": cwd, "term_id": term_id}

    except Exception as e:
        exc("term_spawn", e)
        return {"ok": False, "hata": str(e)}


def _get_proc(term_id):
    with _TERM_LOCK:
        entry = _TERM_PROCS.get(term_id)
        return entry["proc"] if entry else None


def term_write(term_id, data):
    """Terminale veri yazar (kilit dışında I/O)."""
    try:
        proc = _get_proc(term_id)
        if not proc:
            return {"ok": False}
        if not isinstance(data, str):
            data = str(data)
        proc.write(data)
        return {"ok": True}
    except Exception as e:
        exc("term_write", e)
        return {"ok": False, "hata": str(e)}


def term_resize(term_id, rows, cols):
    """Terminal boyutunu değiştirir."""
    try:
        rows = max(5, min(200, int(rows or 30)))
        cols = max(20, min(500, int(cols or 120)))
        proc = _get_proc(term_id)
        if not proc:
            return {"ok": False}
        done = False
        for args in ((rows, cols), (cols, rows)):
            try:
                proc.setwinsize(*args)
                done = True
                break
            except Exception:
                continue
        if not done:
            warn("term_resize basarisiz: %s", term_id)
        return {"ok": True, "rows": rows, "cols": cols}
    except Exception as e:
        exc("term_resize", e)
        return {"ok": False}


def term_close(term_id):
    """Terminal sürecini kapatır."""
    try:
        with _TERM_LOCK:
            entry = _TERM_PROCS.pop(term_id, None)
        if not entry:
            return {"ok": True}
        entry["stop"].set()
        proc = entry["proc"]
        try:
            proc.terminate(force=True)
        except TypeError:
            try:
                proc.terminate()
            except Exception:
                pass
        except Exception:
            pass
        try:
            entry["q"].put_nowait(None)
        except Exception:
            pass
        return {"ok": True}
    except Exception as e:
        exc("term_close", e)
        return {"ok": False}


def term_list():
    """Aktif terminal id listesi."""
    with _TERM_LOCK:
        return list(_TERM_PROCS.keys())


def close_all_terminals():
    """Tüm terminal süreçlerini kapatır (deadlock-safe)."""
    with _TERM_LOCK:
        ids = list(_TERM_PROCS.keys())
    for tid in ids:
        try:
            term_close(tid)
        except Exception as e:
            exc("close_all_terminals", e)
'''

LSP_PY = r'''"""
Splash Code Studio - LSP İstemcisi
Gerçek JSON-RPC / stdio Language Server Protocol

Düzeltmeler:
  * stderr drain thread  -> pipe dolup sunucu bloke olmuyor
  * bufsize=-1 + _read_exact -> kısmi okuma / bozuk JSON yok
  * İstek öncesi _sync() -> sunucu asla bayat doküman görmüyor
  * initialize() cevap doğrulaması
  * Pool eviction kilit DIŞINDA (2sn global blok yok)
  * peek_lsp() -> diagnostics için sunucu spawn etmez
"""
import json
import os
import shutil
import subprocess
import threading
import time
from collections import deque

from .constants import LSP_SERVERS
from .log import exc, info, warn
from .utils import path_to_uri

_THROTTLE = 0.25
_CREATE_NO_WINDOW = 0x08000000


class LspClient:
    """Tek bir LSP sunucusu ile JSON-RPC iletişimi."""

    def __init__(self, lang, root_path):
        self.lang = lang
        self.cmd = LSP_SERVERS.get(lang)
        self.proc = None
        self._id = 0
        self._wlock = threading.Lock()
        self._plock = threading.Lock()
        self._pending = {}
        self._open_files = set()
        self._versions = {}
        self._diagnostics = {}
        self._diag_lock = threading.Lock()
        self._last_text = {}
        self._pending_text = {}
        self._last_did_change = {}
        self._last_used = time.time()
        self._ready = False
        self._init_lock = threading.Lock()
        self.capabilities = {}
        self.stderr_tail = deque(maxlen=200)
        self._root = root_path or os.getcwd()
        self._reader = None
        self._errreader = None
        self._start()

    # ── Süreç ────────────────────────────────────────
    def _start(self):
        if not self.cmd:
            return
        exe = self.cmd[0]
        if not (shutil.which(exe)
                or (os.path.isabs(exe) and os.path.isfile(exe))):
            return
        try:
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = _CREATE_NO_WINDOW
            if os.path.isdir(self._root):
                kw["cwd"] = self._root
            self.proc = subprocess.Popen(
                self.cmd, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                bufsize=-1, **kw)
        except Exception as e:
            exc("lsp start %s" % self.lang, e)
            self.proc = None
            return

        def drain_stderr():
            try:
                for raw in iter(self.proc.stderr.readline, b""):
                    line = raw.decode("utf-8", "replace").rstrip()
                    if line:
                        self.stderr_tail.append(line)
            except Exception:
                pass

        self._errreader = threading.Thread(
            target=drain_stderr, name="lsp-err-%s" % self.lang, daemon=True)
        self._errreader.start()
        self._reader = threading.Thread(
            target=self._read_loop, name="lsp-r-%s" % self.lang, daemon=True)
        self._reader.start()
        info("lsp basladi: %s (root=%s)", self.lang, self._root)

    # ── Okuma ────────────────────────────────────────
    def _read_headers(self, stream):
        headers = {}
        while True:
            line = stream.readline()
            if not line:
                return None
            try:
                line = line.decode("ascii", errors="ignore").strip()
            except Exception:
                return None
            if not line:
                return headers
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip()] = v.strip()

    def _read_exact(self, stream, n):
        chunks = []
        left = n
        while left > 0:
            b = stream.read(left)
            if not b:
                return None
            chunks.append(b)
            left -= len(b)
        return b"".join(chunks)

    def _read_loop(self):
        p = self.proc
        try:
            while p and p.poll() is None:
                headers = self._read_headers(p.stdout)
                if not headers:
                    break
                try:
                    length = int(headers.get("Content-Length", 0))
                except Exception:
                    continue
                if length <= 0:
                    continue
                body = self._read_exact(p.stdout, length)
                if body is None:
                    break
                try:
                    msg = json.loads(body.decode("utf-8", "replace"))
                except Exception as e:
                    warn("lsp %s bozuk mesaj: %s", self.lang, e)
                    continue
                try:
                    self._dispatch(msg)
                except Exception as e:
                    exc("lsp dispatch %s" % self.lang, e)
        except Exception:
            pass
        finally:
            self._ready = False
            with self._plock:
                for pend in self._pending.values():
                    try:
                        pend["event"].set()
                    except Exception:
                        pass
            info("lsp reader bitti: %s", self.lang)

    def _dispatch(self, msg):
        mid = msg.get("id")
        method = msg.get("method")
        if method is not None and mid is None:
            self._handle_notification(msg)
            return
        if method is not None and mid is not None:
            self._handle_server_request(msg, mid)
            return
        if mid is not None:
            with self._plock:
                pend = self._pending.get(mid)
            if pend:
                pend["response"] = msg
                pend["event"].set()

    def _handle_notification(self, msg):
        method = msg.get("method", "")
        params = msg.get("params") or {}
        if method == "textDocument/publishDiagnostics":
            uri = params.get("uri", "")
            diags = params.get("diagnostics") or []
            with self._diag_lock:
                self._diagnostics[uri] = diags[:200]
        elif method in ("window/logMessage", "window/showMessage"):
            warn("lsp %s: %s", self.lang, params.get("message", ""))

    def _handle_server_request(self, msg, mid):
        method = msg.get("method", "")
        params = msg.get("params") or {}
        if method == "workspace/configuration":
            items = params.get("items") or [{}]
            result = [{} for _ in items]
        elif method == "workspace/workspaceFolders":
            result = [{"uri": path_to_uri(self._root),
                       "name": os.path.basename(self._root) or "root"}]
        elif method == "workspace/applyEdit":
            result = {"applied": False}
        elif method in ("window/workDoneProgress/create",
                        "client/registerCapability",
                        "client/unregisterCapability"):
            result = None
        else:
            result = None
        body = json.dumps({"jsonrpc": "2.0", "id": mid,
                           "result": result}).encode("utf-8")
        self._write_raw(body)

    # ── Yazma ────────────────────────────────────────
    def _write_raw(self, body):
        try:
            header = ("Content-Length: %d\r\n\r\n" % len(body)).encode("ascii")
            with self._wlock:
                if not self.proc or not self.proc.stdin:
                    return False
                self.proc.stdin.write(header + body)
                self.proc.stdin.flush()
            return True
        except Exception as e:
            exc("lsp write %s" % self.lang, e)
            return False

    def _send(self, method, params, is_request=True):
        if not self.proc or self.proc.poll() is not None:
            return None
        msg = {"jsonrpc": "2.0", "method": method, "params": params}
        mid = None
        if is_request:
            with self._plock:
                self._id += 1
                mid = self._id
                self._pending[mid] = {"event": threading.Event(),
                                      "response": None}
            msg["id"] = mid
        body = json.dumps(msg, ensure_ascii=False).encode("utf-8")
        if not self._write_raw(body):
            if mid is not None:
                with self._plock:
                    self._pending.pop(mid, None)
            return None
        return mid if is_request else True

    def _request(self, method, params, timeout=10):
        mid = self._send(method, params, True)
        if mid is None:
            return None
        with self._plock:
            pend = self._pending.get(mid)
        if pend is None:
            return None
        try:
            ok = pend["event"].wait(timeout)
        finally:
            with self._plock:
                self._pending.pop(mid, None)
        if not ok:
            warn("lsp %s timeout: %s", self.lang, method)
            return None
        return pend["response"]

    # ── Yaşam döngüsü ────────────────────────────────
    def initialize(self):
        if self._ready:
            return True
        if not self.proc:
            return False
        with self._init_lock:
            if self._ready:
                return True
            if not self.proc or self.proc.poll() is not None:
                return False
            root_uri = path_to_uri(self._root)
            resp = self._request("initialize", {
                "processId": os.getpid(),
                "rootUri": root_uri,
                "rootPath": self._root,
                "clientInfo": {"name": "Splash Code Studio",
                               "version": "3.0.0"},
                "workspaceFolders": [{
                    "uri": root_uri,
                    "name": os.path.basename(self._root) or "root",
                }],
                "capabilities": {
                    "workspace": {
                        "workspaceFolders": True,
                        "configuration": True,
                        "didChangeConfiguration": {
                            "dynamicRegistration": False},
                    },
                    "textDocument": {
                        "synchronization": {
                            "dynamicRegistration": False, "didSave": True},
                        "completion": {
                            "dynamicRegistration": False,
                            "completionItem": {
                                "snippetSupport": False,
                                "documentationFormat": [
                                    "markdown", "plaintext"],
                            },
                        },
                        "hover": {
                            "dynamicRegistration": False,
                            "contentFormat": ["markdown", "plaintext"],
                        },
                        "definition": {
                            "dynamicRegistration": False,
                            "linkSupport": True},
                        "publishDiagnostics": {"relatedInformation": True},
                        "documentSymbol": {
                            "hierarchicalDocumentSymbolSupport": True},
                        "formatting": {"dynamicRegistration": False},
                    },
                    "window": {"workDoneProgress": True},
                },
            }, timeout=20)
            if not resp or "result" not in resp:
                warn("lsp %s initialize basarisiz: %s",
                     self.lang, (resp or {}).get("error"))
                return False
            self.capabilities = (resp.get("result") or {}).get(
                "capabilities") or {}
            self._send("initialized", {}, False)
            self._ready = True
            info("lsp hazir: %s", self.lang)
            return True

    def did_open(self, file_uri, text):
        if file_uri in self._open_files:
            return
        ok = self._send("textDocument/didOpen", {
            "textDocument": {"uri": file_uri, "languageId": self.lang,
                             "version": 1, "text": text},
        }, False)
        if ok:
            self._open_files.add(file_uri)
            self._versions[file_uri] = 1
            self._last_text[file_uri] = text
            self._last_did_change[file_uri] = time.time()

    def _sync(self, file_uri, text):
        """İstek ÖNCESİ dokümanı sunucuya eksiksiz gönderir."""
        self._last_used = time.time()
        if text is None:
            text = self._pending_text.get(file_uri)
            if text is None:
                text = self._last_text.get(file_uri, "")
        if file_uri not in self._open_files:
            self._pending_text.pop(file_uri, None)
            self.did_open(file_uri, text)
            return
        if (self._last_text.get(file_uri) == text
                and file_uri not in self._pending_text):
            return
        self._pending_text.pop(file_uri, None)
        self._last_text[file_uri] = text
        self._last_did_change[file_uri] = time.time()
        self._versions[file_uri] = self._versions.get(file_uri, 1) + 1
        self._send("textDocument/didChange", {
            "textDocument": {"uri": file_uri,
                             "version": self._versions[file_uri]},
            "contentChanges": [{"text": text}],
        }, False)

    def did_change(self, file_uri, text):
        """Arka plan senkronu (throttle'lı, ama metin kaybolmaz)."""
        if file_uri not in self._open_files:
            self._sync(file_uri, text)
            return
        if (self._last_text.get(file_uri) == text
                and file_uri not in self._pending_text):
            return
        self._pending_text[file_uri] = text
        if time.time() - self._last_did_change.get(file_uri, 0) < _THROTTLE:
            return
        self._sync(file_uri, text)

    def did_save(self, file_uri, text=None):
        try:
            self._send("textDocument/didSave", {
                "textDocument": {"uri": file_uri},
            }, False)
        except Exception as e:
            exc("lsp did_save", e)

    def did_close(self, file_uri):
        if not self.proc:
            return
        try:
            self._send("textDocument/didClose", {
                "textDocument": {"uri": file_uri},
            }, False)
        except Exception as e:
            exc("lsp did_close", e)
        self._open_files.discard(file_uri)
        self._pending_text.pop(file_uri, None)

    # ── İstekler ─────────────────────────────────────
    def completion(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/completion", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=3)
        if not resp:
            return None
        result = resp.get("result")
        if not result:
            return None
        if isinstance(result, list):
            return result
        return result.get("items", [])

    def hover(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/hover", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=10)
        return resp.get("result") if resp else None

    def definition(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/definition", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=10)
        return resp.get("result") if resp else None

    def formatting(self, file_uri, text, tab_size=4, insert_spaces=True):
        """formatOnSave için (002'de bağlanacak)."""
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/formatting", {
            "textDocument": {"uri": file_uri},
            "options": {"tabSize": int(tab_size),
                        "insertSpaces": bool(insert_spaces)},
        }, timeout=10)
        return resp.get("result") if resp else None

    def diagnostics_for(self, file_uri):
        with self._diag_lock:
            return list(self._diagnostics.get(file_uri, []))

    # ── Kapanış ──────────────────────────────────────
    def shutdown(self):
        proc = self.proc
        if not proc:
            return
        try:
            if proc.poll() is None:
                try:
                    self._request("shutdown", {}, timeout=2)
                except Exception:
                    pass
                try:
                    self._send("exit", {}, False)
                except Exception:
                    pass
                try:
                    proc.wait(timeout=2)
                except Exception:
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        try:
                            proc.kill()
                        except Exception:
                            pass
        finally:
            self._ready = False
            for stream in (proc.stdin, proc.stdout, proc.stderr):
                try:
                    if stream:
                        stream.close()
                except Exception:
                    pass
            with self._plock:
                for pend in self._pending.values():
                    try:
                        pend["event"].set()
                    except Exception:
                        pass
                self._pending.clear()
            self.proc = None
            info("lsp kapandi: %s", self.lang)


# ── LSP Client Pool ──────────────────────────────────
_LSP_CLIENTS = {}
_LSP_LOCK = threading.RLock()
_MAX_CLIENTS = 3


def get_lsp(lang, root):
    """LSP istemcisi alır veya oluşturur (eviction kilit dışında)."""
    root = root or os.getcwd()
    key = (lang, root)
    doomed = []
    with _LSP_LOCK:
        c = _LSP_CLIENTS.get(key)
        if c is not None:
            if c.proc and c.proc.poll() is None:
                c._last_used = time.time()
                return c
            _LSP_CLIENTS.pop(key, None)
            doomed.append(c)
        while len(_LSP_CLIENTS) >= _MAX_CLIENTS:
            oldest = min(_LSP_CLIENTS,
                         key=lambda k: getattr(_LSP_CLIENTS[k],
                                               "_last_used", 0))
            doomed.append(_LSP_CLIENTS.pop(oldest))
        c = LspClient(lang, root)
        _LSP_CLIENTS[key] = c
    for d in doomed:
        threading.Thread(target=d.shutdown, daemon=True).start()
    return c


def peek_lsp(lang, root=None):
    """Var olan istemciyi döndürür; YENİ SUNUCU BAŞLATMAZ."""
    root = root or os.getcwd()
    with _LSP_LOCK:
        c = _LSP_CLIENTS.get((lang, root))
        if c and c.proc and c.proc.poll() is None:
            return c
    return None


def shutdown_all_lsp():
    """Tüm LSP istemcilerini paralel kapatır."""
    with _LSP_LOCK:
        clients = list(_LSP_CLIENTS.values())
        _LSP_CLIENTS.clear()
    threads = []
    for c in clients:
        t = threading.Thread(target=c.shutdown, daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join(timeout=3)
'''

FILES = {
    "splash_code/log.py": LOG_PY,
    "splash_code/terminal.py": TERMINAL_PY,
    "splash_code/lsp_client.py": LSP_PY,
}

# ══════════════════════════════════════════════════════════════
#  PATCH MOTORU
# ══════════════════════════════════════════════════════════════

SKIP_DIRS = {"__pycache__", ".git", ".venv", "venv", "node_modules",
             "_backups", ".idea", ".vscode", "dist", "build"}
MAX_BACKUP_FILE = 20 * 1024 * 1024


def find_root(cli_root=None):
    cands = []
    if cli_root:
        cands.append(os.path.abspath(cli_root))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for c in cands:
        if os.path.isdir(os.path.join(c, "splash_code")):
            return c
    return cands[0] if cands else os.getcwd()


def make_backup(root):
    bdir = os.path.join(root, "_backups")
    os.makedirs(bdir, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    zpath = os.path.join(bdir, "pre_patch%s_%s.zip" % (PATCH_ID, stamp))
    count = 0
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAX_BACKUP_FILE:
                        continue
                    z.write(full, rel)
                    count += 1
                except Exception:
                    pass
    return zpath, count


def write_atomic(path, content):
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        p = os.path.join(root, rel)
        try:
            py_compile.compile(
                p, cfile=os.path.join(tempfile.gettempdir(), "sc_chk.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zpath, rels):
    print("  ! Geri aliniyor...")
    try:
        with zipfile.ZipFile(zpath) as z:
            names = set(z.namelist())
            for rel in rels:
                key = rel.replace("\\", "/")
                target = os.path.join(root, rel)
                if key in names:
                    with open(target, "wb") as f:
                        f.write(z.read(key))
                    print("    geri yuklendi: %s" % rel)
                else:
                    try:
                        os.remove(target)
                        print("    silindi (yeniydi): %s" % rel)
                    except Exception:
                        pass
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Backup'i elle ac: %s" % zpath)


def clear_pycache(root):
    targets = []
    for dirpath, dirnames, _ in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        if os.path.basename(dirpath) == "__pycache__":
            targets.append(dirpath)
    for t in targets:
        shutil.rmtree(t, ignore_errors=True)
    return len(targets)


def do_restore(root, zpath):
    if not os.path.isfile(zpath):
        print("Backup bulunamadi: %s" % zpath)
        return 1
    n = 0
    with zipfile.ZipFile(zpath) as z:
        for name in z.namelist():
            target = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with open(target, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    clear_pycache(root)
    print("%d dosya geri yuklendi: %s" % (n, zpath))
    return 0


def main():
    ap = argparse.ArgumentParser(description="Splash Code Studio patch")
    ap.add_argument("--root", help="Proje kok dizini")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    a = ap.parse_args()

    root = find_root(a.root)

    print("=" * 62)
    print("  Splash Code Studio - Patch %s" % PATCH_ID)
    print("  %s" % TITLE)
    print("=" * 62)
    print("  Kok: %s" % root)

    if a.restore:
        return do_restore(root, a.restore)

    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ bulunamadi.")
        print("  patch.py'yi main.py'nin yanina koy veya --root ver.")
        return 1

    print("\n  Plan:")
    plan = []
    for rel, content in FILES.items():
        p = os.path.join(root, rel)
        if not os.path.exists(p):
            state = "YENI      "
        else:
            try:
                with open(p, "r", encoding="utf-8-sig") as f:
                    state = "AYNI      " if f.read() == content \
                        else "GUNCELLE  "
            except Exception:
                state = "GUNCELLE  "
        print("    [%s] %-32s %4d satir"
              % (state, rel, len(content.splitlines())))
        plan.append(rel)

    if a.dry_run:
        print("\n  --dry-run: hicbir sey yazilmadi.")
        return 0

    zpath = None
    if not a.no_backup:
        print("\n  Backup aliniyor...")
        zpath, n = make_backup(root)
        print("    %s  (%d dosya)" % (zpath, n))
    else:
        print("\n  !! Backup KAPALI (--no-backup)")

    print("\n  Yaziliyor...")
    written = []
    try:
        for rel in plan:
            write_atomic(os.path.join(root, rel), FILES[rel])
            written.append(rel)
            print("    + %s" % rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zpath:
            rollback(root, zpath, written)
        return 1

    print("\n  Derleme dogrulamasi...")
    bad = verify(root, written)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zpath:
            rollback(root, zpath, written)
        else:
            print("    Backup yok - elle duzeltmen gerekiyor!")
        return 1
    print("    Tum dosyalar OK")

    n = clear_pycache(root)
    print("    %d __pycache__ temizlendi" % n)

    print("\n" + "=" * 62)
    print("  Patch %s BASARIYLA UYGULANDI" % PATCH_ID)
    if zpath:
        print("  Geri almak icin:")
        print("    python patch.py --restore \"%s\"" % zpath)
    print("  Log: ~/.splash_code/splash.log")
    print("  Detayli log icin: SPLASH_DEBUG=1 ortami ile baslat")
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
