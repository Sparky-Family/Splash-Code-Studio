﻿"""
Splash Code Studio - Terminal PTY Yönetimi
pywinpty (Windows) / ptyprocess (Unix) tabanlı
"""
import os
import shutil
import threading
import time

_TERM_PROCS = {}
_TERM_LOCK = threading.Lock()


def term_spawn(term_id: str, cwd: str,
               shell_cmd: str = None) -> dict:
    """Yeni PTY terminal süreci başlatır."""
    try:
        # Eski süreci kapat (aynı id ile 2 proc kalmasın)
        try:
            term_close(term_id)
        except Exception:
            pass

        if not cwd or not os.path.isdir(str(cwd)):
            cwd = os.getcwd()

        env = dict(os.environ)
        env.setdefault("TERM", "xterm-256color")

        if os.name == "nt":
            try:
                from winpty import PtyProcess as WPy
                shell = shell_cmd or (
                    shutil.which("pwsh")
                    or shutil.which("powershell")
                    or "powershell.exe"
                )
                proc = WPy.spawn(shell, cwd=cwd,
                                 dimensions=(30, 120))
            except ImportError:
                return {"ok": False,
                        "hata": "pywinpty yok. pip install pywinpty"}
        else:
            try:
                import ptyprocess
                shell = shell_cmd or os.environ.get(
                    "SHELL", "/bin/bash")
                proc = ptyprocess.PtyProcessUnicode.spawn(
                    [shell], cwd=cwd, dimensions=(30, 120), env=env)
            except ImportError:
                return {"ok": False,
                        "hata": "ptyprocess yok. pip install ptyprocess"}

        with _TERM_LOCK:
            _TERM_PROCS[term_id] = proc

        def reader():
            buf = ""
            last_flush = time.time()
            while True:
                try:
                    data = proc.read(4096)
                    if not data:
                        break
                    if isinstance(data, bytes):
                        try:
                            data = data.decode("utf-8", "replace")
                        except Exception:
                            data = str(data)
                    buf += data
                    if (len(buf) > 8000
                            or time.time() - last_flush > 0.04):
                        chunk = buf
                        buf = ""
                        last_flush = time.time()
                        _notify_frontend(
                            "termWrite", chunk, term_id)
                except EOFError:
                    break
                except Exception:
                    time.sleep(0.05)
            if buf:
                _notify_frontend("termWrite", buf, term_id)
            _notify_frontend("termClosed", None, term_id)
            with _TERM_LOCK:
                _TERM_PROCS.pop(term_id, None)

        threading.Thread(target=reader, daemon=True).start()
        return {"ok": True, "cwd": cwd}
    except Exception as e:
        return {"ok": False, "hata": str(e)}


def _notify_frontend(func_name: str, data, term_id: str):
    """Frontend'e JS çağrısı gönderir."""
    try:
        import webview
        if webview.windows:
            import json as _json
            if data is not None:
                webview.windows[0].evaluate_js(
                    f"if(window.{func_name}) "
                    f"window.{func_name}("
                    f"{_json.dumps(data)},"
                    f"{_json.dumps(term_id)});")
            else:
                webview.windows[0].evaluate_js(
                    f"if(window.{func_name}) "
                    f"window.{func_name}({_json.dumps(term_id)});")
    except Exception:
        pass


def term_write(term_id: str, data: str) -> dict:
    """Terminale veri yazar."""
    try:
        with _TERM_LOCK:
            proc = _TERM_PROCS.get(term_id)
        if not proc:
            return {"ok": False}
        if not isinstance(data, str):
            data = str(data)
        proc.write(data)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "hata": str(e)}


def term_resize(term_id: str, rows: int, cols: int) -> dict:
    """Terminal boyutunu değiştirir."""
    try:
        rows = max(5, min(200, int(rows or 30)))
        cols = max(20, min(500, int(cols or 120)))
        with _TERM_LOCK:
            proc = _TERM_PROCS.get(term_id)
        if proc:
            done = False
            for args in [(rows, cols), (cols, rows)]:
                try:
                    proc.setwinsize(*args)
                    done = True
                    break
                except Exception:
                    continue
            if not done:
                try:
                    proc.setwinsize(rows, cols)
                except Exception:
                    pass
        return {"ok": True, "rows": rows, "cols": cols}
    except Exception:
        return {"ok": False}


def term_close(term_id: str) -> dict:
    """Terminal sürecini kapatır."""
    try:
        with _TERM_LOCK:
            proc = _TERM_PROCS.pop(term_id, None)
        if proc:
            try:
                proc.terminate(force=True)
            except Exception:
                pass
        return {"ok": True}
    except Exception:
        return {"ok": False}


def close_all_terminals():
    """Tüm terminal süreçlerini kapatır."""
    with _TERM_LOCK:
        ids = list(_TERM_PROCS.keys())
    for tid in ids:
        try:
            term_close(tid)
        except Exception:
            pass
