﻿"""
Splash Code Studio - LSP İstemcisi
Gerçek JSON-RPC ile Language Server Protocol desteği
"""
import json
import os
import shutil
import subprocess
import threading
import time

from .constants import LSP_SERVERS
from .utils import path_to_uri


class LspClient:
    """Tek bir LSP sunucusu ile JSON-RPC iletişimi."""

    def __init__(self, lang: str, root_path: str):
        self.lang = lang
        self.cmd = LSP_SERVERS.get(lang)
        self.proc = None
        self._id = 0
        self._lock = threading.Lock()
        self._pending = {}
        self._open_files = set()
        self._versions = {}
        self._diagnostics = {}
        self._diag_lock = threading.Lock()
        self._cache = {}
        self._last_text = {}
        self._last_did_change = {}
        self._last_used = time.time()
        self._ready = False
        self._root = root_path or os.getcwd()
        self._start()

    def _start(self):
        if not self.cmd:
            return
        exe = self.cmd[0]
        if not (shutil.which(exe)
                or (os.path.isabs(exe) and os.path.isfile(exe))):
            return
        try:
            self.proc = subprocess.Popen(
                self.cmd, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                bufsize=0,
            )
            self._reader = threading.Thread(
                target=self._read_loop, daemon=True)
            self._reader.start()
        except Exception:
            self.proc = None

    def _read_loop(self):
        try:
            while self.proc and self.proc.poll() is None:
                try:
                    headers = self._read_headers()
                    if not headers:
                        break
                    length = int(headers.get("Content-Length", 0))
                    if length <= 0:
                        continue
                    body = self.proc.stdout.read(length)
                    if not body:
                        break
                    msg = json.loads(body)
                    mid = msg.get("id")
                    if mid is None and "method" in msg:
                        self._handle_notification(msg)
                        continue
                    if mid is not None and mid in self._pending:
                        self._pending[mid]["response"] = msg
                        self._pending[mid]["event"].set()
                    elif mid is not None and "method" in msg:
                        self._handle_server_request(msg, mid)
                except Exception:
                    break
        finally:
            for pend in list(self._pending.values()):
                try:
                    pend["event"].set()
                except Exception:
                    pass

    def _handle_notification(self, msg: dict):
        method = msg.get("method", "")
        params = msg.get("params") or {}
        if method == "textDocument/publishDiagnostics":
            uri = params.get("uri", "")
            diags = params.get("diagnostics") or []
            with self._diag_lock:
                self._diagnostics[uri] = diags[:200]

    def _handle_server_request(self, msg: dict, mid):
        method = msg.get("method", "")
        if method == "workspace/configuration":
            items = msg.get("params", {}).get("items") or [{}]
            result = [{} for _ in items]
        else:
            result = None
        try:
            resp_body = json.dumps({
                "jsonrpc": "2.0", "id": mid, "result": result,
            }).encode("utf-8")
            header = f"Content-Length: {len(resp_body)}\r\n\r\n".encode()
            with self._lock:
                if self.proc and self.proc.stdin:
                    self.proc.stdin.write(header + resp_body)
                    self.proc.stdin.flush()
        except Exception:
            pass

    def _read_headers(self):
        headers = {}
        while True:
            line = self.proc.stdout.readline()
            if not line:
                return None
            try:
                line = line.decode("ascii", errors="ignore").strip()
            except Exception:
                return None
            if not line:
                return headers
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip()] = v.strip()

    def _send(self, method: str, params: dict,
              is_request: bool = True):
        if not self.proc:
            return None
        with self._lock:
            msg = {"jsonrpc": "2.0", "method": method, "params": params}
            mid = None
            if is_request:
                self._id += 1
                mid = self._id
                msg["id"] = mid
                self._pending[mid] = {
                    "event": threading.Event(), "response": None,
                }
            try:
                body = json.dumps(msg).encode("utf-8")
                header = f"Content-Length: {len(body)}\r\n\r\n".encode()
                self.proc.stdin.write(header + body)
                self.proc.stdin.flush()
            except Exception:
                return None
            return mid

    def _request(self, method: str, params: dict,
                 timeout: float = 10):
        mid = self._send(method, params, is_request=True)
        if not mid:
            return None
        pending = self._pending.get(mid)
        if not pending:
            return None
        if pending["event"].wait(timeout):
            resp = pending["response"]
            del self._pending[mid]
            return resp
        self._pending.pop(mid, None)
        return None

    def initialize(self) -> bool:
        if self._ready:
            return True
        if not self.proc:
            return False
        try:
            root_uri = path_to_uri(self._root)
            self._request("initialize", {
                "processId": os.getpid(),
                "rootUri": root_uri,
                "capabilities": {
                    "textDocument": {
                        "completion": {
                            "completionItem": {"snippetSupport": False},
                        },
                        "hover": {
                            "contentFormat": ["plaintext", "markdown"],
                        },
                    },
                },
            }, timeout=10)
            self._send("initialized", {}, is_request=False)
            self._ready = True
            return True
        except Exception:
            return False

    def did_open(self, file_uri: str, text: str):
        if file_uri in self._open_files:
            return
        self._send("textDocument/didOpen", {
            "textDocument": {
                "uri": file_uri, "languageId": self.lang,
                "version": 1, "text": text,
            },
        }, is_request=False)
        self._open_files.add(file_uri)
        self._versions[file_uri] = 1

    def did_change(self, file_uri: str, text: str):
        if self._last_text.get(file_uri) == text:
            return
        now = time.time()
        last = self._last_did_change.get(file_uri, 0)
        if now - last < 0.25 and file_uri in self._open_files:
            return
        self._last_text[file_uri] = text
        self._last_did_change[file_uri] = now
        self._last_used = now
        if file_uri not in self._open_files:
            self.did_open(file_uri, text)
            return
        self._versions[file_uri] += 1
        self._send("textDocument/didChange", {
            "textDocument": {
                "uri": file_uri,
                "version": self._versions[file_uri],
            },
            "contentChanges": [{"text": text}],
        }, is_request=False)

    def did_save(self, file_uri: str, text: str):
        try:
            self._send("textDocument/didSave", {
                "textDocument": {"uri": file_uri},
            }, is_request=False)
        except Exception:
            pass

    def completion(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self.did_change(file_uri, text)
        resp = self._request("textDocument/completion", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=2)
        if not resp:
            return None
        result = resp.get("result")
        if not result:
            return None
        if isinstance(result, list):
            return result
        return result.get("items", [])

    def hover(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self.did_change(file_uri, text)
        resp = self._request("textDocument/hover", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=10)
        return resp.get("result") if resp else None

    def definition(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self.did_change(file_uri, text)
        resp = self._request("textDocument/definition", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=10)
        return resp.get("result") if resp else None

    def did_close(self, file_uri: str):
        if not self.proc:
            return
        try:
            self._send("textDocument/didClose", {
                "textDocument": {"uri": file_uri},
            }, is_request=False)
        except Exception:
            pass
        self._open_files.discard(file_uri)

    def diagnostics_for(self, file_uri: str) -> list:
        with self._diag_lock:
            return list(self._diagnostics.get(file_uri, []))

    def shutdown(self):
        try:
            if self.proc and self.proc.poll() is None:
                try:
                    self._request("shutdown", {}, timeout=2)
                except Exception:
                    pass
                try:
                    self._send("exit", {}, is_request=False)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            if self.proc:
                self.proc.terminate()
        except Exception:
            pass
        for p in list(self._pending.values()):
            try:
                p["event"].set()
            except Exception:
                pass


# ── LSP Client Pool ───────────────────────────────────
_LSP_CLIENTS = {}
_LSP_LOCK = threading.Lock()
_MAX_CLIENTS = 3


def get_lsp(lang: str, root: str) -> LspClient:
    """LSP istemcisi alır veya oluşturur (pool yönetimi)."""
    with _LSP_LOCK:
        key = (lang, root or os.getcwd())
        c = _LSP_CLIENTS.get(key)
        if c and c.proc and c.proc.poll() is None:
            c._last_used = time.time()
            return c
        if c is not None:
            _LSP_CLIENTS.pop(key, None)
        # En fazla N client - en eski idle olan kapatılır
        if len(_LSP_CLIENTS) >= _MAX_CLIENTS:
            oldest = min(
                _LSP_CLIENTS.items(),
                key=lambda kv: getattr(kv[1], "_last_used", 0),
            )
            try:
                oldest[1].shutdown()
            except Exception:
                pass
            _LSP_CLIENTS.pop(oldest[0], None)
        c = LspClient(lang, root or os.getcwd())
        _LSP_CLIENTS[key] = c
        return c


def shutdown_all_lsp():
    """Tüm LSP istemcilerini kapatır."""
    with _LSP_LOCK:
        for c in list(_LSP_CLIENTS.values()):
            try:
                c.shutdown()
            except Exception:
                pass
        _LSP_CLIENTS.clear()
