#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 014 "Oturum & Proje Hatırlama"
- rememberSession: açık sekmeleri kaydet ve geri yükle
- rememberProject: proje klasörünü ve tree'yi kaydet ve geri yükle
- Debounced arka plan kayıt (her değişimde değil, 2s sonra)
- Kapanışta garantili kayıt

    py path.py --check
    py path.py --dry-run
    py path.py
"""

import argparse
import os
import py_compile
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "014"
TITLE = "Oturum & Proje Hatırlama Fix"
API_REL = "splash_code/api.py"
HTML_REL = "splash_code/templates/index.html"
PY_MARK = "# ===== SC-SESSION-014 ====="
PY_END = "# ===== /SC-SESSION-014 ====="
HTML_MARK = "<!--SC-SESSION-014-->"
HTML_END = "<!--/SC-SESSION-014-->"

# ══════════════════════════════════════════════════════════════
#  api.py APPEND
# ══════════════════════════════════════════════════════════════

API_APPEND = r"""
# ===== SC-SESSION-014 =====
# rememberProject / rememberSession gercekten calisir

_sc014_orig_init = Api.__init__
_sc014_orig_klasor_sec = Api.klasor_sec
_sc014_orig_oturum_yukle = Api.oturum_yukle
_sc014_orig_oturum_kaydet = Api.oturum_kaydet
_sc014_orig_cleanup = Api.cleanup


def _sc014_init(self):
    _sc014_orig_init(self)
    # rememberProject kapaliysa _cwd yukleme
    if not self.settings.get("rememberProject", True):
        self._cwd = None


def _sc014_klasor_sec(self):
    r = _sc014_orig_klasor_sec(self)
    # rememberProject kapaliysa lastProject'i kaldir
    if isinstance(r, dict) and r.get("ok"):
        if not self.settings.get("rememberProject", True):
            self.settings["lastProject"] = None
            try:
                save_settings(self.settings)
            except Exception:
                pass
    return r


def _sc014_oturum_yukle(self):
    if not self.settings.get("rememberSession", True):
        return {"cwd": None, "tabs": [], "activeTab": None,
                "recentFiles": [], "tree": []}
    return _sc014_orig_oturum_yukle(self)


def _sc014_oturum_kaydet(self, s):
    if not self.settings.get("rememberSession", True):
        # Kapaliysa bos oturum kaydet (eski veriyi temizle)
        self.session = {"cwd": None, "tabs": [], "activeTab": None,
                        "recentFiles": [], "tree": []}
        save_session(self.session)
        return {"ok": True, "skipped": True}
    return _sc014_orig_oturum_kaydet(self, s)


def _sc014_cleanup(self):
    # Kapanista oturumu kaydet
    try:
        if self.settings.get("rememberSession", True):
            save_session(self.session)
    except Exception:
        pass
    _sc014_orig_cleanup(self)


Api.__init__ = _sc014_init
Api.klasor_sec = _sc014_klasor_sec
Api.oturum_yukle = _sc014_oturum_yukle
Api.oturum_kaydet = _sc014_oturum_kaydet
Api.cleanup = _sc014_cleanup
# ===== /SC-SESSION-014 =====
"""

# ══════════════════════════════════════════════════════════════
#  index.html INJECT
# ══════════════════════════════════════════════════════════════

HTML_INJECT = r"""
<!--SC-SESSION-014-->
<script>
(function(){
'use strict';
if(window.__SC014__)return;
window.__SC014__=true;

var _saveTimer=null;
var _treeSaveTimer=null;

/* === Debounced oturum kaydet === */
function scheduleSessionSave(){
  if(!window.settings||!window.settings.rememberSession)return;
  clearTimeout(_saveTimer);
  _saveTimer=setTimeout(doSessionSave,2000);
}

function doSessionSave(){
  var a=scApi();if(!a)return;
  if(!window.settings||!window.settings.rememberSession)return;
  var tabData=[];
  (window.tabs||[]).forEach(function(t){
    if(t.path)tabData.push({path:t.path,name:t.name,lang:t.lang});
  });
  a.oturum_kaydet({
    cwd:window._cwd||null,
    recentFiles:window.recentFiles||[],
    tabs:tabData,
    activeTab:activeTabId,
    tree:getExpandedTree()
  });
}

/* === Agac genisletilmis klasorleri kaydet === */
function getExpandedTree(){
  var expanded=[];
  try{
    document.querySelectorAll('#tree .tree-item[data-dir="1"]').forEach(function(el){
      var arrow=el.querySelector('.folder-arrow');
      if(arrow&&arrow.classList.contains('open')){
        var fid=el.dataset.fid;
        var p=fid?getCachedPath(fid):null;
        if(p)expanded.push(p);
      }
    });
  }catch(e){}
  return expanded;
}

/* === Oturum geri yukleme === */
function restoreSession(){
  var a=scApi();if(!a)return;
  a.oturum_yukle().then(function(sess){
    if(!sess)return;
    /* Proje klasoru */
    if(sess.cwd&&!window._cwd){
      window._cwd=sess.cwd;
      var lbl=document.getElementById('cwdLabel');
      if(lbl)lbl.textContent=sess.cwd;
      a.klasor_icerik(sess.cwd).then(function(files){
        if(files&&files.length)listele(files);
        /* Genisletilmis klasorleri geri yukle */
        if(sess.tree&&sess.tree.length){
          setTimeout(function(){restoreExpandedTree(sess.tree);},300);
        }
      });
    }
    /* Son dosyalar */
    if(sess.recentFiles&&sess.recentFiles.length){
      window.recentFiles=sess.recentFiles;
    }
    /* Sekmeleri geri yukle */
    if(sess.tabs&&sess.tabs.length&&window.settings.rememberSession){
      var count=0;
      sess.tabs.forEach(function(t){
        if(t.path){
          dosyaAcYol(t.path);
          count++;
        }
      });
      /* Aktif sekmeyi ayarla */
      if(sess.activeTab!=null){
        setTimeout(function(){
          var tb=window.tabs.find(function(x){return x.id===sess.activeTab;});
          if(tb)aktifSekmeYap(tb.id);
          else if(window.tabs.length)aktifSekmeYap(window.tabs[0].id);
        },count*200+500);
      }
    }
  });
}

function restoreExpandedTree(paths){
  if(!paths||!paths.length)return;
  paths.forEach(function(p){
    try{
      var items=document.querySelectorAll('#tree .tree-item[data-dir="1"]');
      items.forEach(function(el){
        var fid=el.dataset.fid;
        var cp=fid?getCachedPath(fid):null;
        if(cp===p){
          var arrow=el.querySelector('.folder-arrow');
          if(arrow&&!arrow.classList.contains('open')){
            toggleDir(el,null);
          }
        }
      });
    }catch(e){}
  });
}

/* === Sekme degisikliklerini izle === */
var _origRenderTabs=window.renderTabs;
if(typeof _origRenderTabs==='function'){
  window.renderTabs=function(){
    _origRenderTabs();
    scheduleSessionSave();
  };
}

/* === Kapanista kaydet === */
window.addEventListener('beforeunload',function(){
  try{doSessionSave();}catch(e){}
});

/* === Baslangicta geri yukle === */
setTimeout(function(){
  restoreSession();
},1500);

})();
</script>
<!--/SC-SESSION-014-->
"""

# ══════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════

SKIP = {".git", ".venv", "venv", "node_modules", "_backups",
        ".idea", ".vscode", "dist", "build"}
MAXB = 25 * 1024 * 1024


def find_root(cli=None):
    cands = []
    if cli:
        cands.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for p in cands:
        if p and os.path.isdir(os.path.join(p, "splash_code")):
            return p
    return cands[0] if cands else os.getcwd()


def rd(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def wr(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def strip_block(src, start, end):
    i = src.find(start)
    if i < 0:
        return src
    j = src.find(end, i)
    if j < 0:
        return src[:i]
    return src[:i] + src[j + len(end):]


def pycache(root):
    targets = []
    for dp, dn, fn in os.walk(root):
        if os.path.basename(dp) == "__pycache__":
            targets.append(dp)
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in SKIP]
    for t in targets:
        shutil.rmtree(t, ignore_errors=True)
    return len(targets)


def backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAXB:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def plan(root):
    ops, probs = [], []

    # api.py
    ap = os.path.join(root, API_REL)
    if not os.path.isfile(ap):
        probs.append(API_REL + " yok")
    else:
        src = rd(ap)
        src = strip_block(src, PY_MARK, PY_END)
        body = API_APPEND.strip("\n")
        new = src if src.endswith("\n") else src + "\n"
        new += "\n" + body + "\n"
        ops.append((API_REL, new, "append"))

    # index.html
    hp = os.path.join(root, HTML_REL)
    if not os.path.isfile(hp):
        probs.append(HTML_REL + " yok")
    else:
        src = rd(hp)
        src = strip_block(src, HTML_MARK, HTML_END)
        low = src.lower()
        i = low.rfind("</body>")
        if i < 0:
            probs.append(HTML_REL + ": </body> yok")
        else:
            new = src[:i] + HTML_INJECT + src[i:]
            ops.append((HTML_REL, new, "inject"))

    return ops, probs


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc014.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                if k in names:
                    with open(os.path.join(root, rel), "wb") as f:
                        f.write(z.read(k))
                    print("    geri: " + rel)
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)


def restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: " + zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def check(root):
    print("\n  --- TANI ---")
    api = rd(os.path.join(root, API_REL)) if os.path.isfile(
        os.path.join(root, API_REL)) else ""
    idx = rd(os.path.join(root, HTML_REL)) if os.path.isfile(
        os.path.join(root, HTML_REL)) else ""
    print("  api.py session fix    : %s"
          % ("VAR" if PY_MARK in api else "YOK"))
    print("  index.html session JS : %s"
          % ("VAR" if HTML_MARK in idx else "YOK"))
    print("  rememberSession kontrol: %s"
          % ("VAR" if "_sc014_oturum_yukle" in api else "YOK"))
    print("  rememberProject kontrol: %s"
          % ("VAR" if "_sc014_klasor_sec" in api else "YOK"))
    print("  Tab geri yukleme      : %s"
          % ("VAR" if "restoreSession" in idx else "YOK"))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 64)
    print("  Splash Code Studio - Patch %s" % PATCH_ID)
    print("  " + TITLE)
    print("=" * 64)
    print("  Kok: " + root)

    if a.restore:
        return restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok.")
        return 1
    if a.check:
        return check(root)

    ops, probs = plan(root)
    if probs:
        print("\n  !! SORUN:")
        for x in probs:
            print("     - " + x)
        return 2

    print("\n  Plan:")
    for rel, new, info in ops:
        print("    %-34s %s" % (rel, info))

    if a.dry_run:
        print("\n  --dry-run: temiz.")
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = backup(root)
        print("    %s (%d dosya)" % (zp, n))

    touched = []
    try:
        for rel, content in ops:
            wr(os.path.join(root, rel), content)
            touched.append(rel)
            print("    + " + rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Dogrulama...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK  ·  %d __pycache__ silindi" % pycache(root))

    print("\n" + "=" * 64)
    print("  Patch %s UYGULANDI" % PATCH_ID)
    if zp:
        print("  Geri al: py path.py --restore \"%s\"" % zp)
    print("  Test: py main.py")
    print("    1) Ayarlar > 'Oturumu hatırla' AÇIK")
    print("    2) Birkaç dosya aç, IDE'yi kapat")
    print("    3) Tekrar aç -> sekmeler geri gelmeli")
    print("    4) Ayarlar > 'Proje klasörünü hatırla' AÇIK")
    print("    5) Klasör aç, IDE'yi kapat")
    print("    6) Tekrar aç -> tree geri gelmeli")
    print("    7) Her iki ayarı KAPAT -> yeniden başlat")
    print("    8) Sekmeler ve tree boş gelmeli")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())
