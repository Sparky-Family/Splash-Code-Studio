"""
Splash Code Studio v3.0 - Modüler Entry Point
================================================
Tüm mantık splash_code/ paketinde.
Bu dosya sadece uygulamayı başlatır.
"""
import sys
import os
import traceback
import datetime

# ── Crash Handler ─────────────────────────────────────
_CRASH_LOG = os.path.join(
    os.path.expanduser("~"), ".splash_code", "error.log")


def _install_crash_handler():
    def handler(et, ev, etb):
        try:
            os.makedirs(os.path.dirname(_CRASH_LOG), exist_ok=True)
            with open(_CRASH_LOG, "a", encoding="utf-8") as f:
                f.write(
                    f"\n{'='*60}\n"
                    f"{datetime.datetime.now().isoformat()}\n"
                    f"{'='*60}\n")
                traceback.print_exception(et, ev, etb, file=f)
            import webview
            if webview.windows:
                msg = str(ev)[:200].replace("'", "\\'").replace("\n", " ")
                webview.windows[0].evaluate_js(
                    f"if(window.scToast) "
                    f"scToast('Hata: {msg}','error',8000);")
        except Exception:
            pass
        sys.__excepthook__(et, ev, etb)
    sys.excepthook = handler


_install_crash_handler()

from splash_code import __app_name__, __version__
from splash_code.settings import load_settings
from splash_code.api import Api
from splash_code.html_builder import build_html


def main():
    print("=" * 60)
    print(f"{__app_name__} v{__version__}")
    print("=" * 60)

    import webview

    settings = load_settings()
    api = Api()
    html = build_html(settings)

    window = webview.create_window(
        __app_name__, html=html, js_api=api,
        width=1400, height=900, min_size=(900, 600),
        text_select=True,
    )

    def on_closed():
        try:
            api.cleanup()
        except Exception:
            pass

    window.events.closed += on_closed
    webview.start(debug=False, http_server=False)


if __name__ == "__main__":
    main()
