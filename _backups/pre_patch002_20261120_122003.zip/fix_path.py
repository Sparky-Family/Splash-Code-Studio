#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Splash Code Studio - patch.py hotfix
# Sebep: API_PY raw blogunun icinde gecen 3x tek-tirnak, dis string'i
#        erken kapatiyordu -> SyntaxError (satir ~206).
# Bu script o tek satiri duzeltir ve patch.py'yi derleyerek dogrular.

import os
import py_compile
import sys
import tempfile

DQ = chr(34)
SQ = chr(39)

OLD = ("if code.startswith(" + SQ + DQ * 3 + SQ + ", i)"
       " or code.startswith(" + DQ + SQ * 3 + DQ + ", i):")
NEW = ("if code.startswith(chr(34)*3, i)"
       " or code.startswith(chr(39)*3, i):")

TARGET = sys.argv[1] if len(sys.argv) > 1 else "path.py"


def main():
    p = os.path.abspath(TARGET)
    if not os.path.isfile(p):
        print("Dosya yok: %s" % p)
        return 1

    with open(p, "r", encoding="utf-8", newline="") as f:
        src = f.read()

    n = src.count(OLD)
    if n == 0:
        if NEW in src:
            print("Zaten duzeltilmis.")
        else:
            print("Anchor bulunamadi. Satir 206 civarini elle kontrol et.")
            return 2
    elif n > 1:
        print("Beklenmeyen: anchor %d kez bulundu." % n)
        return 2
    else:
        bak = p + ".bak"
        with open(bak, "w", encoding="utf-8", newline="") as f:
            f.write(src)
        src = src.replace(OLD, NEW)
        with open(p, "w", encoding="utf-8", newline="") as f:
            f.write(src)
        print("Duzeltildi. Yedek: %s" % bak)

    print("Derleme kontrolu...")
    try:
        py_compile.compile(
            p,
            cfile=os.path.join(tempfile.gettempdir(), "sc_patch_chk.pyc"),
            doraise=True)
    except Exception as e:
        print("HALA HATA VAR:")
        print(e)
        return 1

    print("OK - patch.py derleniyor.")
    print("Simdi: py path.py --dry-run")
    return 0


if __name__ == "__main__":
    sys.exit(main())
