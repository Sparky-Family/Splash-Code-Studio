﻿"""
Splash Code Studio - WebView API
Frontend (JS) ile backend (Python) arasındaki köprü
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading

from .constants import (
    APP_NAME, APP_VERSION, LSP_SERVERS, LSP_INSTALL_CMDS,
    LSP_INSTALL_NOTES, LSP_MONACO_IDS, BUILTINS,
    ICON_PACKS, DEFAULT_ICON_MAP, ICON_MAP_FILE, SETTINGS_DIR,
    get_lang,
)
from .settings import (
    load_settings, save_settings, load_session, save_session,
    load_icon_map, save_icon_map, normalize_settings,
)
from .lsp_client import get_lsp, shutdown_all_lsp
from .terminal import (
    term_spawn, term_write, term_resize, term_close,
    close_all_terminals,
)
from .ai import ai_gemini, ai_claude
from .themes import all_themes, save_user_theme, delete_user_theme
from .html_builder import clear_build_cache
from .utils import atomic_write, is_binary_path, path_to_uri


class Api:
    """pywebview js_api olarak kullanılan ana API sınıfı."""

    def __init__(self):
        self.settings = load_settings()
        self.session = load_session()
        self._cwd = self.settings.get("lastProject")
        self._cwd = (self._cwd
                     if (self._cwd and os.path.isdir(self._cwd))
                     else None)
        self._cur_path = None
        self._cur_tab_id = None

    # ── Ayarlar ───────────────────────────────────────
    def ayarlari_yukle(self):
        return self.settings

    def ayarlari_kaydet(self, s):
        try:
            _s = dict(s or {})
            if ("saveBeforeRun" in _s
                    and "autoSaveBeforeRun" not in _s):
                _s["autoSaveBeforeRun"] = _s["saveBeforeRun"]
            merged = dict(self.settings)
            merged.update(_s)
            self.settings = normalize_settings(merged)
            save_settings(self.settings)
            try:
                clear_build_cache()
            except Exception:
                pass
            return {"ok": True, "settings": self.settings}
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    # ── Oturum ────────────────────────────────────────
    def oturum_yukle(self):
        return self.session

    def oturum_kaydet(self, s):
        try:
            self.session.update(s or {})
            save_session(self.session)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    # ── Dosya İşlemleri ───────────────────────────────
    def dosya_ac(self):
        try:
            import webview
            w = webview.windows[0]
            r = w.create_file_dialog(
                webview.OPEN_DIALOG, allow_multiple=False)
            if not r:
                return None
            p = r[0] if isinstance(r, (list, tuple)) else r
            return self._read_file(p)
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def dosya_oku(self, path):
        return self._read_file(path)

    def _read_file(self, path):
        try:
            path = os.path.abspath(path)
            if not os.path.exists(path):
                return {"ok": False, "hata": "Dosya bulunamadı"}
            size = os.path.getsize(path)
            with open(path, "rb") as f:
                raw = f.read()
            try:
                content = raw.decode("utf-8")
                enc = "utf-8"
            except UnicodeDecodeError:
                content = raw.decode("latin-1")
                enc = "latin-1"
            return {
                "ok": True, "path": path,
                "name": os.path.basename(path),
                "lang": get_lang(path), "content": content,
                "encoding": enc,
                "hash": hashlib.sha1(raw).hexdigest(),
                "size": size,
            }
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def kaydet(self, path, content):
        try:
            if not path:
                return self.farkli_kaydet(content)
            path = os.path.abspath(path)
            dirname = os.path.dirname(path)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            with open(path, "w",
                      encoding=self.settings.get("encoding", "utf-8"),
                      newline="") as f:
                f.write(content)
            self._cur_path = path
            return {
                "ok": True, "path": path,
                "name": os.path.basename(path),
                "lang": get_lang(path),
            }
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def farkli_kaydet(self, content):
        try:
            import webview
            w = webview.windows[0]
            r = w.create_file_dialog(
                webview.SAVE_DIALOG, save_filename="untitled.py")
            if not r:
                return {"ok": False, "hata": "İptal"}
            path = r if isinstance(r, str) else (
                r[0] if r else None)
            if not path:
                return {"ok": False, "hata": "İptal"}
            return self.kaydet(path, content)
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def klasor_sec(self):
        try:
            import webview
            w = webview.windows[0]
            r = w.create_file_dialog(webview.FOLDER_DIALOG)
            if not r:
                return {"ok": False, "hata": "İptal"}
            cwd = r[0] if isinstance(r, (list, tuple)) else r
            if not cwd or not os.path.isdir(cwd):
                return {"ok": False, "hata": "Geçersiz klasör"}
            self._cwd = cwd
            self.settings["lastProject"] = cwd
            save_settings(self.settings)
            files = self._list_dir(cwd, top=True)
            return {"ok": True, "cwd": cwd, "files": files}
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def _list_dir(self, cwd, top=False, max_items=5000):
        out = []
        try:
            for entry in sorted(
                os.scandir(cwd),
                key=lambda e: (not e.is_dir(), e.name.lower()),
            ):
                if entry.name.startswith(".") and entry.name not in (
                        ".env", ".gitignore"):
                    continue
                if entry.name in (
                    "node_modules", "__pycache__", ".git", "venv",
                    ".venv", "dist", "build", ".next", "target",
                ):
                    continue
                out.append({
                    "name": entry.name,
                    "path": entry.path,
                    "is_dir": entry.is_dir(),
                })
                if len(out) >= max_items:
                    break
        except Exception:
            pass
        return out

    def klasor_icerik(self, path):
        try:
            if not path or not os.path.isdir(path):
                return []
            return self._list_dir(path)
        except Exception:
            return []

    def yeni_dosya(self, parent, name):
        try:
            if not name:
                return {"ok": False, "hata": "İsim gerekli"}
            path = os.path.join(
                parent or self._cwd or os.getcwd(), name)
            if os.path.exists(path):
                return {"ok": False, "hata": "Zaten var"}
            dirname = os.path.dirname(path)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write("")
            return {"ok": True, "path": path,
                    "name": os.path.basename(path)}
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def yeni_klasor(self, parent, name):
        try:
            if not name:
                return {"ok": False, "hata": "İsim gerekli"}
            path = os.path.join(
                parent or self._cwd or os.getcwd(), name)
            os.makedirs(path, exist_ok=True)
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def dosya_sil(self, path):
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def dosya_yeniden_adlandir(self, old, new):
        try:
            if os.path.exists(new):
                return {"ok": False, "hata": "Hedef var"}
            os.rename(old, new)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    # ── LSP ───────────────────────────────────────────
    def lsp_check(self, lang):
        try:
            cmd = LSP_SERVERS.get(lang)
            if not cmd:
                return {"active": False, "reason": "desteklenmiyor"}
            exe = cmd[0]
            if not (shutil.which(exe)
                    or (os.path.isabs(exe)
                        and os.path.isfile(exe))):
                return {"active": False, "reason": "sunucu yok"}
            return {"active": True}
        except Exception:
            return {"active": False}

    def lsp_kur(self, lang):
        try:
            cmd = LSP_INSTALL_CMDS.get(lang)
            if cmd is None:
                return {
                    "ok": False,
                    "hata": LSP_INSTALL_NOTES.get(
                        lang, "Elle kurulum gerekli"),
                    "manuel": True,
                }
            r = subprocess.run(
                cmd, capture_output=True, text=True, timeout=300)
            ok = r.returncode == 0
            return {
                "ok": ok,
                "out": (r.stdout or "")[-2000:],
                "err": (r.stderr or "")[-2000:] if not ok else "",
            }
        except Exception as e:
            return {"ok": False, "hata": str(e)}

    def lsp_complete(self, lang, uri, text, line, col):
        try:
            c = get_lsp(lang, self._cwd)
            if not c.proc:
                return {"items": []}
            items = c.completion(uri, line, col, text)
            return {"items": items or []}
        except Exception:
            return {"items": []}

    def lsp_hover(self, lang, uri, text, line, col):
        try:
            c = get_lsp(lang, self._cwd)
            if not c.proc:
                return None
            h = c.hover(uri, line, col, text)
            if not h:
                return None
            contents = h.get("contents")
            if isinstance(contents, dict):
                return {"content": contents.get("value", "")}
            if isinstance(contents, list):
                parts = []
                for x in contents:
                    if isinstance(x, dict):
                        parts.append(x.get("value", ""))
                    else:
                        parts.append(str(x))
                return {"content": "\n".join(parts)}
            if isinstance(contents, str):
                return {"content": contents}
            return {"content": str(contents)}
        except Exception:
            return None

    def lsp_definition(self, lang, uri, text, line, col):
        try:
            c = get_lsp(lang, self._cwd)
            if not c.proc:
                return None
            d = c.definition(uri, line, col, text)
            if not d:
                return None
            if isinstance(d, list):
                d = d[0] if d else None
            if not d:
                return None
            return {
                "location": {
                    "uri": d.get("uri"),
                    "range": d.get("range"),
                },
            }
        except Exception:
            return None

    def lsp_diagnostics(self, lang, uri):
        try:
            c = get_lsp(lang, self._cwd)
            if not c.proc:
                return {"items": []}
            return {"items": c.diagnostics_for(uri)}
        except Exception:
            return {"items": []}

    def fake_complete(self, lang, text, line, col):
        try:
            lines = text.split("\n") if text else []
            prefix = ""
            if 0 <= line < len(lines):
                prefix = lines[line][:col]
            m = re.search(r"([A-Za-z_][A-Za-z0-9_]*)$", prefix)
            word = m.group(1) if m else ""
            if not word:
                return []
            wl = word.lower()
            candidates = []
            for b in BUILTINS.get(lang, []):
                if b.lower().startswith(wl) and b != word:
                    candidates.append({
                        "label": b, "insertText": b,
                        "sortText": "0_" + b,
                    })
            words = set(re.findall(
                r"[A-Za-z_][A-Za-z0-9_]{2,}", text or ""))
            for w in sorted(words):
                if (w.lower().startswith(wl) and w != word
                        and w not in BUILTINS.get(lang, [])):
                    candidates.append({
                        "label": w, "insertText": w,
                        "sortText": "1_" + w,
                    })
            return candidates[:80]
        except Exception:
            return []

    # ── Terminal ──────────────────────────────────────
    def terminal_baslat(self, cwd, shell_cmd=None):
        return term_spawn(
            "t1", cwd or self._cwd or os.getcwd(), shell_cmd)

    def terminal_yaz(self, term_id, data):
        return term_write(term_id or "t1", data)

    def terminal_yeniden_boyutlandir(self, term_id, rows, cols):
        return term_resize(term_id or "t1", rows, cols)

    def terminal_kapat(self, term_id):
        return term_close(term_id or "t1")

    # ── Çalıştırma ────────────────────────────────────
    def calistir(self, path, cwd):
        if not path:
            return {"ok": False, "hata": "Dosya yok"}
        ext = os.path.splitext(path)[1].lower()
        if ext == ".py":
            cmd = [sys.executable, "-u", path]
        elif ext in (".js", ".mjs"):
            cmd = ["node", path]
        elif ext == ".sh":
            cmd = ["bash", path]
        elif ext == ".ps1":
            cmd = ["powershell", "-ExecutionPolicy", "Bypass",
                   "-File", path]
        elif ext == ".rb":
            cmd = ["ruby", path]
        elif ext == ".go":
            cmd = ["go", "run", path]
        elif ext == ".rs":
            cmd = ["cargo", "run", "--manifest-path",
                   os.path.join(cwd or ".", "Cargo.toml")]
        else:
            return {"ok": False,
                    "hata": f"Desteklenmeyen: {ext}"}
        return self._run_cmd(
            "run1", cwd or os.path.dirname(path) or os.getcwd(), cmd)

    def _run_cmd(self, term_id, cwd, cmd):
        try:
            proc = subprocess.Popen(
                cmd, cwd=cwd, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                shell=isinstance(cmd, str), bufsize=0,
            )
        except Exception as e:
            return {"ok": False, "hata": str(e)}

        def reader():
            try:
                while True:
                    chunk = proc.stdout.read(512)
                    if not chunk:
                        break
                    txt = chunk.decode("utf-8", "replace")
                    try:
                        import webview
                        if webview.windows:
                            webview.windows[0].evaluate_js(
                                f"if(window.runOutput) "
                                f"window.runOutput("
                                f"{json.dumps(txt)});")
                    except Exception:
                        pass
            except Exception:
                pass
            try:
                import webview
                if webview.windows:
                    webview.windows[0].evaluate_js(
                        "if(window.runDone) window.runDone();")
            except Exception:
                pass

        threading.Thread(target=reader, daemon=True).start()
        return {"ok": True}

    def durdur(self):
        return {"ok": True}  # Basit impl

    # ── AI ────────────────────────────────────────────
    def ai_gonder(self, messages, context):
        s = self.settings
        provider = s.get("ai_provider", "")
        if not provider:
            return {"ok": False,
                    "hata": "AI sağlayıcı seçilmemiş"}
        msgs = []
        if context:
            msgs.append({
                "role": "system",
                "content": "Aşağıdaki kod bağlamında yardımcı ol:\n"
                           + context,
            })
        msgs.extend(messages or [])
        if provider == "gemini":
            return ai_gemini(
                s.get("ai_gemini_key", ""),
                s.get("ai_model", ""), msgs)
        if provider == "claude":
            return ai_claude(
                s.get("ai_claude_key", ""),
                s.get("ai_model", ""), msgs)
        return {"ok": False, "hata": "Bilinmeyen sağlayıcı"}

    # ── Arama ─────────────────────────────────────────
    def projede_ara(self, query, cwd, use_regex=False,
                    case_sensitive=False, max_results=500):
        out = []
        if not query or not cwd:
            return out
        try:
            pattern = re.compile(
                query if use_regex else re.escape(query),
                0 if case_sensitive else re.IGNORECASE,
            )
        except re.error:
            pattern = re.compile(re.escape(query), re.IGNORECASE)
        try:
            for root, dirs, files in os.walk(cwd):
                dirs[:] = [
                    d for d in dirs
                    if not d.startswith(".")
                    and d not in (
                        "node_modules", "__pycache__", "venv",
                        ".venv", "dist", "build", ".git",
                    )
                ]
                for fn in files:
                    p = os.path.join(root, fn)
                    try:
                        if os.path.getsize(p) > 2 * 1024 * 1024:
                            continue
                        if is_binary_path(p):
                            continue
                        with open(p, "r", encoding="utf-8",
                                  errors="ignore") as f:
                            for i, ln in enumerate(f, 1):
                                if pattern.search(ln):
                                    out.append({
                                        "path": p, "line": i,
                                        "text": ln.rstrip()[:200],
                                    })
                                if len(out) >= max_results:
                                    return out
                    except Exception:
                        continue
        except Exception:
            pass
        return out

    # ── Git ───────────────────────────────────────────
    def _git(self, cwd, args):
        try:
            r = subprocess.run(
                ["git"] + args, cwd=cwd,
                capture_output=True, text=True, timeout=20,
            )
            return {
                "ok": r.returncode == 0,
                "out": r.stdout, "err": r.stderr,
            }
        except Exception as e:
            return {"ok": False, "err": str(e), "out": ""}

    def git_durum(self):
        if not self._cwd:
            return {"ok": False, "branch": None, "changes": []}
        b = self._git(self._cwd, ["branch", "--show-current"])
        branch = b.get("out", "").strip() or "(detached)"
        st = self._git(self._cwd, ["status", "--porcelain"])
        changes = []
        for ln in (st.get("out") or "").splitlines():
            if len(ln) >= 4:
                changes.append({
                    "status": ln[:2].strip(),
                    "path": ln[3:].strip(),
                })
        return {
            "ok": st.get("ok", False),
            "branch": branch, "changes": changes,
        }

    def git_commit(self, msg):
        if not self._cwd:
            return {"ok": False, "hata": "cwd yok"}
        if not (msg or "").strip():
            return {"ok": False,
                    "hata": "Commit mesaji bos olamaz"}
        a = self._git(self._cwd, ["add", "-A"])
        if not a["ok"]:
            return a
        return self._git(self._cwd, ["commit", "-m", msg or "update"])

    def git_push(self):
        if not self._cwd:
            return {"ok": False, "hata": "cwd yok"}
        return self._git(self._cwd, ["push"])

    def git_pull(self):
        if not self._cwd:
            return {"ok": False, "hata": "cwd yok"}
        return self._git(self._cwd, ["pull"])

    # ── İkonlar ───────────────────────────────────────
    def ikon_haritasi_yukle(self):
        return load_icon_map()

    def ikon_haritasi_kaydet(self, m):
        ok = save_icon_map(m or {})
        return {"ok": ok}

    def ikon_haritasi_sifirla(self):
        try:
            if os.path.exists(ICON_MAP_FILE):
                os.remove(ICON_MAP_FILE)
        except Exception:
            pass
        return {"ok": True, "map": dict(DEFAULT_ICON_MAP)}

    def ikon_paketleri(self):
        return {
            "packs": [
                {
                    "id": k, "name": v["name"],
                    "desc": v["desc"], "colors": v["colors"],
                }
                for k, v in ICON_PACKS.items()
            ],
            "current": self.settings.get("iconPack", "splash"),
        }

    def ikon_paket_sec(self, name):
        if name not in ICON_PACKS:
            return {"ok": False, "hata": "paket yok"}
        self.settings["iconPack"] = name
        try:
            save_settings(self.settings)
        except Exception:
            pass
        clear_build_cache()
        return {
            "ok": True, "pack": name,
            "colors": ICON_PACKS[name]["colors"],
        }

    # ── Temalar ───────────────────────────────────────
    def tema_ekle(self, name, theme):
        ok = save_user_theme(name, theme)
        return {"ok": ok}

    def tema_sil(self, name):
        ok = delete_user_theme(name)
        return {"ok": ok}

    # ── Bilgi ─────────────────────────────────────────
    def bilgi(self):
        return {
            "app": APP_NAME,
            "version": APP_VERSION,
            "platform": sys.platform,
            "python": sys.version,
            "cwd": self._cwd,
            "lsp_servers": {
                k: bool(
                    shutil.which(v[0])
                    or (os.path.isabs(v[0])
                        and os.path.isfile(v[0]))
                )
                for k, v in LSP_SERVERS.items()
            },
        }

    # ── Temizlik ──────────────────────────────────────
    def cleanup(self):
        """Uygulama kapanırken kaynakları serbest bırakır."""
        try:
            shutdown_all_lsp()
            close_all_terminals()
            save_settings(self.settings)
        except Exception:
            pass
