﻿"""Splash Code Studio - Modüler IDE"""

__version__ = "3.0.0"
__app_name__ = "Splash Code Studio"
__version_name__ = "Modular"
