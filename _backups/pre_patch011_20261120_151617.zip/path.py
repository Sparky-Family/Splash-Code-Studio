#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 011 "Ayarlar"
- Ayarlar panelini profesyonel, açıklamalı, kategorili hale getirir.
- "Son projeyi hatırla" ve "oturumu hatırla" backend tarafında gerçekten uygulanır.
- Kayıtta biçimlendir / lint isimleri anlaşılır hale gelir.
- splitMode, editör, terminal, AI ve görünüm ayarları kaydedilince uygulanır.

Kullanım:
    py path.py --check
    py path.py --dry-run
    py path.py
"""

import argparse
import os
import py_compile
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "011"
TITLE = "Profesyonel ayarlar paneli + hatırlama ayarları fix"
API_REL = "splash_code/api.py"
HTML_REL = "splash_code/templates/index.html"
PY_MARK = "# ===== SC-SETTINGS-011 ====="
PY_END = "# ===== /SC-SETTINGS-011 ====="
HTML_MARK = "<!--SC-SETTINGS-011-->"
HTML_END = "<!--/SC-SETTINGS-011-->"

API_APPEND = r"""
# ===== SC-SETTINGS-011 =====
# Ayarlar: rememberProject / rememberSession artik backend tarafinda da uygulanir.
_SC011_EMPTY_SESSION = {
    "cwd": None,
    "tabs": [],
    "activeTab": None,
    "recentFiles": [],
}

_sc011_orig_init = Api.__init__
_sc011_orig_klasor_sec = Api.klasor_sec


def _sc011_init(self):
    _sc011_orig_init(self)
    try:
        if not self.settings.get("rememberProject", True):
            self._cwd = None
    except Exception:
        pass


def _sc011_ayarlar_kaydet(self, s):
    try:
        data = dict(s or {})
        if "saveBeforeRun" in data and "autoSaveBeforeRun" not in data:
            data["autoSaveBeforeRun"] = data["saveBeforeRun"]
        merged = dict(self.settings)
        merged.update(data)
        if not merged.get("rememberProject", True):
            merged["lastProject"] = None
        self.settings = normalize_settings(merged)
        save_settings(self.settings)
        if not self.settings.get("rememberSession", True):
            self.session = dict(_SC011_EMPTY_SESSION)
            save_session(self.session)
        try:
            clear_build_cache()
        except Exception:
            pass
        return {"ok": True, "settings": self.settings}
    except Exception as e:
        return {"ok": False, "hata": str(e)}


def _sc011_oturum_yukle(self):
    try:
        if not self.settings.get("rememberSession", True):
            return dict(_SC011_EMPTY_SESSION)
        return self.session
    except Exception:
        return dict(_SC011_EMPTY_SESSION)


def _sc011_oturum_kaydet(self, s):
    try:
        if not self.settings.get("rememberSession", True):
            self.session = dict(_SC011_EMPTY_SESSION)
            save_session(self.session)
            return {"ok": True, "skipped": True}
        self.session.update(s or {})
        save_session(self.session)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "hata": str(e)}


def _sc011_klasor_sec(self):
    r = _sc011_orig_klasor_sec(self)
    try:
        if isinstance(r, dict) and r.get("ok") and not self.settings.get("rememberProject", True):
            self.settings["lastProject"] = None
            save_settings(self.settings)
    except Exception:
        pass
    return r


Api.__init__ = _sc011_init
Api.ayarlari_kaydet = _sc011_ayarlar_kaydet
Api.oturum_yukle = _sc011_oturum_yukle
Api.oturum_kaydet = _sc011_oturum_kaydet
Api.klasor_sec = _sc011_klasor_sec
# ===== /SC-SETTINGS-011 =====
"""

SETTINGS_CSS = r"""
#settingsOverlay .modal.sc11-settings{width:min(1080px,calc(100vw - 32px);max-height:88vh}
.sc11-head{display:flex;align-items:center;gap:12px;padding:16px 20px;border-bottom:1px solid var(--border);background:var(--bg-alt)}
.sc11-head h2{font-size:15px;font-weight:700;margin:0;color:var(--text)}
.sc11-head p{margin:2px 0 0;font-size:11.5px;color:var(--dim)}
.sc11-search{margin-left:auto;min-width:260px;max-width:360px;width:32%;background:var(--bg);border:1px solid var(--border);border-radius:8px;color:var(--text);padding:8px 11px;font:12.5px var(--font-ui);outline:none}
.sc11-search:focus{border-color:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 18%,transparent)}
.sc11-body{display:grid;grid-template-columns:210px 1fr;min-height:0;flex:1}
.sc11-nav{border-right:1px solid var(--border);background:var(--bg-alt);padding:10px;overflow:auto}
.sc11-nav button{width:100%;border:none;background:transparent;color:var(--dim);border-radius:8px;padding:9px 10px;display:flex;align-items:center;gap:9px;text-align:left;cursor:pointer;font:600 12px var(--font-ui);margin-bottom:3px}
.sc11-nav button:hover{background:var(--bg-hover);color:var(--text)}
.sc11-nav button.on{background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent)}
.sc11-nav svg{width:16px;height:16px;flex:0 0 16px}
.sc11-content{padding:16px 20px;overflow:auto;min-height:0;background:var(--bg)}
.sc11-section{margin-bottom:18px}
.sc11-section-title{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;margin:0 0 10px}
.sc11-section-title h3{font-size:13px;font-weight:750;color:var(--text);margin:0}
.sc11-section-title span{font-size:11px;color:var(--dim)}
.sc11-card{border:1px solid var(--border);border-radius:10px;background:var(--bg-alt);overflow:hidden}
.sc11-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:16px;align-items:center;padding:12px 14px;border-bottom:1px solid var(--border)}
.sc11-row:last-child{border-bottom:none}
.sc11-row.hide{display:none}
.sc11-label{font-size:12.5px;font-weight:650;color:var(--text);margin-bottom:3px}
.sc11-desc{font-size:11.3px;line-height:1.45;color:var(--dim);max-width:620px}
.sc11-control{display:flex;align-items:center;gap:8px;justify-content:flex-end;min-width:160px}
.sc11-control input[type=text],.sc11-control input[type=password],.sc11-control input[type=number],.sc11-control select{background:var(--bg);border:1px solid var(--border);color:var(--text);border-radius:7px;padding:7px 9px;font:12px var(--font-ui);outline:none;min-width:150px}
.sc11-control input[type=number]{min-width:82px}
.sc11-control input:focus,.sc11-control select:focus{border-color:var(--accent)}
.sc11-control input[type=color]{width:42px;height:32px;border:1px solid var(--border);border-radius:7px;background:var(--bg);padding:3px;cursor:pointer}
.sc11-switch{width:42px;height:23px;border-radius:99px;border:1px solid var(--border);background:var(--bg);position:relative;cursor:pointer;transition:all .14s;flex:0 0 42px}
.sc11-switch::after{content:"";position:absolute;top:3px;left:3px;width:15px;height:15px;border-radius:50%;background:var(--dim);transition:all .14s}
.sc11-switch.on{background:var(--accent);border-color:var(--accent)}
.sc11-switch.on::after{left:22px;background:#fff}
.sc11-pill{font:700 10px var(--font-ui);color:var(--dim);border:1px solid var(--border);border-radius:99px;padding:3px 7px;text-transform:uppercase;letter-spacing:.04em}
.sc11-actions{display:flex;gap:8px;align-items:center}
.sc11-footer{padding:13px 20px;border-top:1px solid var(--border);background:var(--bg-alt);display:flex;align-items:center;gap:8px}
.sc11-footnote{font-size:11px;color:var(--dim);margin-right:auto}
.sc11-empty{padding:38px;text-align:center;color:var(--dim);font-size:12px}
@media(max-width:820px){
  .sc11-body{grid-template-columns:1fr}
  .sc11-nav{display:flex;overflow-x:auto;border-right:none;border-bottom:1px solid var(--border)}
  .sc11-nav button{white-space:nowrap;width:auto}
  .sc11-search{min-width:160px;width:100%}
  .sc11-row{grid-template-columns:1fr}
  .sc11-control{justify-content:flex-start}
}
"""

SETTINGS_JS = r"""
(function(){
'use strict';
if(window.__SC_SETTINGS_011__)return;
window.__SC_SETTINGS_011__=true;

var DRAFT=null, ACTIVE='genel', QUERY='';

function api(){return window.pywebview&&window.pywebview.api;}
function el(id){return document.getElementById(id);}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function ic(paths){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+paths+'</svg>';}
var ICONS={
 genel:ic('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4a1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.36.3.6.72.66 1.2H21a2 2 0 1 1 0 4h-.09c-.48.06-.9.3-1.21.8z"/>'),
 editor:ic('<path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/>'),
 run:ic('<polygon points="5 3 19 12 5 21 5 3"/>'),
 code:ic('<path d="M16 18l6-6-6-6"/><path d="M8 6l-6 6 6 6"/>'),
 ai:ic('<rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><path d="M8 16h.01M16 16h.01"/>'),
 look:ic('<circle cx="12" cy="12" r="10"/><path d="M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20M2 12h20"/>')
};

var GROUPS=[
 {id:'genel',title:'Genel',icon:'genel',desc:'Başlangıç, oturum ve kayıt davranışı'},
 {id:'editor',title:'Editör',icon:'editor',desc:'Yazı tipi, satır numaraları ve editör görünümü'},
 {id:'run',title:'Çalıştırma & Terminal',icon:'run',desc:'F5, terminal ve süreç davranışı'},
 {id:'code',title:'Kod Yardımı',icon:'code',desc:'LSP, biçimlendirme, hızlı kontrol ve outline'},
 {id:'ai',title:'AI Asistan',icon:'ai',desc:'Sağlayıcı, model ve API anahtarları'},
 {id:'look',title:'Görünüm',icon:'look',desc:'Tema, vurgu rengi ve ikonlar'}
];

var FIELDS=[
 {g:'genel',k:'rememberProject',type:'switch',label:'Son projeyi açılışta geri yükle',desc:'Kapalıysa Splash Code Studio her zaman boş proje ile açılır. Mevcut çalışma期间的 klasör değişmez; sadece bir sonraki açılış hatırlanmaz.'},
 {g:'genel',k:'rememberSession',type:'switch',label:'Sekmeleri ve son dosyaları hatırla',desc:'Kapalıysa açık sekmeler, son dosyalar ve oturum bilgisi diske yazılmaz.'},
 {g:'genel',k:'showWelcome',type:'switch',label:'Başlangıçta karşılama ekranını göster',desc:'Kapalıysa uygulama doğrudan boş bir dosya sekmesiyle açılır.'},
 {g:'genel',k:'autosave',type:'switch',label:'Otomatik kaydet',desc:'Kaydedilmiş dosyalardaki değişiklikleri belirli aralıklarla otomatik kaydeder.'},
 {g:'genel',k:'autoSaveBeforeRun',type:'switch',label:'Çalıştırmadan önce kaydet',desc:'F5 ile çalıştırmadan önce dosyayı kaydeder. Kapalıysa kaydedilmemiş içerik geçici kopyadan çalıştırılır.'},

 {g:'editor',k:'fontFamily',type:'selectFont',label:'Editör yazı tipi',desc:'Kod alanında kullanılacak font. Terminal ayrı font ayarını kullanır.'},
 {g:'editor',k:'fontSize',type:'number',label:'Editör font boyutu',desc:'Kod editöründeki yazı boyutu.',min:8,max:32,step:.5},
 {g:'editor',k:'tabSize',type:'number',label:'Tab genişliği',desc:'Bir tab karakterinin kaç boşluk gibi görüneceği.',min:1,max:8,step:1},
 {g:'editor',k:'minimap',type:'switch',label:'Minimap göster',desc:'Sağ taraftaki küçük kod haritası.'},
 {g:'editor',k:'wordWrap',type:'switch',label:'Uzun satırları kaydır',desc:'Uzun satırlar yatay scroll yerine alt satıra sarar.'},
 {g:'editor',k:'fontLigatures',type:'switch',label:'Font ligature desteği',desc:'JetBrains Mono / Fira Code gibi fontlarda =>, === gibi birleşik semboller.'},
 {g:'editor',k:'lineNumbers',type:'switch',label:'Satır numaralarını göster',desc:'Breakpoint koymak için satır numarasının solundaki gutter alanı kullanılır.'},
 {g:'editor',k:'splitMode',type:'select',label:'Varsayılan bölünmüş editör',desc:'İkinci editör panelinin yönü.',opts:[['none','Kapalı'],['vertical','Dikey'],['horizontal','Yatay']]},

 {g:'run',k:'runMode',type:'select',label:'Çalıştırma yeri',desc:'F5 çıktısı yerleşik panelde mi yoksa harici terminalde mi açılsın?',opts:[['internal','Yerleşik çıktı paneli'],['external','Harici terminal']]},
 {g:'run',k:'terminalMode',type:'select',label:'Terminal modu',desc:'Ctrl+` ile açılacak terminal türü.',opts:[['internal','Yerleşik terminal'],['external','Varsayılan harici terminal']]},
 {g:'run',k:'terminalFontSize',type:'number',label:'Terminal font boyutu',desc:'Yerleşik terminal yazı boyutu.',min:8,max:28,step:1},
 {g:'run',k:'terminalScrollback',type:'number',label:'Terminal geri kaydırma',desc:'Terminalde tutulacak maksimum geçmiş satır sayısı.',min:100,max:20000,step:100},

 {g:'code',k:'lspEnabled',type:'switch',label:'Dil sunucusu desteği',desc:'Otomatik tamamlama, tanıılama, Git Diff, referanslar ve tanımlara gitme için LSP kullanır.'},
 {g:'code',k:'diagnosticsEnabled',type:'switch',label:'Hata ve uyarıları göster',desc:'LSP tanılama sonuçlarını editörde ve Sorunlar panelinde gösterir.'},
 {g:'code',k:'formatOnSave',type:'switch',label:'Kaydederken kodu biçimlendir',desc:'Kaydetmeden önce formatter çalıştırır. Formatter yoksa güvenli temel temizlik yapılır.'},
 {g:'code',k:'lintOnSave',type:'switch',label:'Kaydederken hızlı kod kontrolü',desc:'Kayıttan sonra sözdizimi / lint kontrolü çalıştırır ve sorunları panelde gösterir.'},
 {g:'code',k:'treesitterEnabled',type:'switch',label:'Gelişmiş outline ve parantez eşleştirme',desc:'Tree-sitter varsa kullanır; yoksa AST / regex fallback ile outline ve bracket highlight sağlar.'},

 {g:'ai',k:'ai_provider',type:'select',label:'AI sağlayıcı',desc:'Kod açıklama, refactor ve soru-cevap için kullanılacak servis.',opts:[['','Kapalı'],['gemini','Gemini'],['claude','Claude']]},
 {g:'ai',k:'ai_gemini_key',type:'password',label:'Gemini API anahtarı',desc:'Google Gemini için API key.'},
 {g:'ai',k:'ai_claude_key',type:'password',label:'Claude API anahtarı',desc:'Anthropic Claude için API key.'},
 {g:'ai',k:'ai_model',type:'text',label:'Model adı',desc:'Boş bırakılırsa sağlayıcının varsayılan modeli kullanılır.'},

 {g:'look',k:'theme',type:'theme',label:'Tema',desc:'Tüm IDE ve yerleşik terminal aynı temadan renk alır.'},
 {g:'look',k:'useCustomAccent',type:'switch',label:'Özel vurgu rengi kullan',desc:'Tema accent rengi yerine kendi seçtiğin rengi kullanır.'},
 {g:'look',k:'customAccent',type:'color',label:'Özel vurgu rengi',desc:'Seçiliyse butonlar, aktif sekme çizgisi ve terminal imleci bu rengi kullanır.'},
 {g:'look',k:'iconPack',type:'select',label:'Dosya ikon paketi',desc:'Dosya ağacındaki ikonların renk dili.',opts:[['splash','Splash'],['minimal','Minimal'],['neon','Neon'],['pastel','Pastel']]}
];

function normalizeDraft(){
 var s=window.settings||{};
 DRAFT=Object.assign({},s);
 if(DRAFT.saveBeforeRun==null)DRAFT.saveBeforeRun=DRAFT.autoSaveBeforeRun!==false;
 if(DRAFT.autoSaveBeforeRun==null)DRAFT.autoSaveBeforeRun=DRAFT.saveBeforeRun!==false;
 if(DRAFT.rememberProject==null)DRAFT.rememberProject=true;
 if(DRAFT.rememberSession==null)DRAFT.rememberSession=true;
 if(DRAFT.terminalMode==null)DRAFT.terminalMode='internal';
 if(DRAFT.runMode==null)DRAFT.runMode='internal';
 if(DRAFT.splitMode==null)DRAFT.splitMode='none';
 if(DRAFT.iconPack==null)DRAFT.iconPack='splash';
}

function optionHtml(opts,val){
 return opts.map(function(o){return '<option value="'+esc(o[0])+'"'+(String(o[0])===String(val)?' selected':'')+'>'+esc(o[1])+'</option>';}).join('');
}
function fontOptions(val){
 var fonts=(typeof SYSTEM_FONTS!=='undefined'&&SYSTEM_FONTS)||['JetBrains Mono','Fira Code','Cascadia Code','Consolas','monospace'];
 return fonts.map(function(f){return '<option value="'+esc(f)+'"'+(f===val?' selected':'')+'>'+esc(f)+'</option>';}).join('');
}
function fieldControl(f){
 var v=DRAFT[f.k];
 if(f.type==='switch')return '<button class="sc11-switch'+(v?' on':'')+'" data-key="'+f.k+'" type="button" aria-label="'+esc(f.label)+'"></button>';
 if(f.type==='select')return '<select data-key="'+f.k+'">'+optionHtml(f.opts||[],v)+'</select>';
 if(f.type==='selectFont')return '<select data-key="'+f.k+'">'+fontOptions(v||'JetBrains Mono')+'</select>';
 if(f.type==='number')return '<input type="number" data-key="'+f.k+'" value="'+esc(v)+'" min="'+(f.min||0)+'" max="'+(f.max||999999)+'" step="'+(f.step||1)+'">';
 if(f.type==='color')return '<input type="color" data-key="'+f.k+'" value="'+esc(v||'#2F81F7')+'">';
 if(f.type==='password')return '<input type="password" data-key="'+f.k+'" value="'+esc(v||'')+'" autocomplete="off">';
 if(f.type==='theme')return '<div class="sc11-actions"><span class="sc11-pill">'+esc((BUILTIN_THEMES[v]&&BUILTIN_THEMES[v].name)||v||'Obsidian')+'</span><button class="btn" type="button" onclick="temaGalerisiAc()">Tema seç</button></div>';
 return '<input type="text" data-key="'+f.k+'" value="'+esc(v||'')+'">';
}
function rowHtml(f){
 var hay=(f.label+' '+f.desc+' '+f.g).toLowerCase();
 var hide=QUERY && hay.indexOf(QUERY)<0;
 return '<div class="sc11-row'+(hide?' hide':'')+'" data-row="'+f.k+'"><div><div class="sc11-label">'+esc(f.label)+'</div><div class="sc11-desc">'+esc(f.desc)+'</div></div><div class="sc11-control">'+fieldControl(f)+'</div></div>';
}
function renderSettings(){
 var ov=el('settingsOverlay');if(!ov)return;
 var modal=ov.querySelector('.modal');if(!modal)return;
 modal.classList.add('sc11-settings');
 var groups=QUERY?GROUPS:GROUPS.filter(function(g){return g.id===ACTIVE;});
 var nav=GROUPS.map(function(g){return '<button type="button" data-g="'+g.id+'" class="'+(!QUERY&&g.id===ACTIVE?'on':'')+'">'+ICONS[g.icon]+'<span>'+esc(g.title)+'</span></button>';}).join('');
 var content=groups.map(function(g){
   var rows=FIELDS.filter(function(f){return f.g===g.id;}).map(rowHtml).join('');
   if(QUERY && rows.indexOf('sc11-row hide')===rows.lastIndexOf('sc11-row hide') && rows.indexOf('sc11-row')>=0){}
   return '<section class="sc11-section" data-section="'+g.id+'"><div class="sc11-section-title"><div><h3>'+esc(g.title)+'</h3><span>'+esc(g.desc)+'</span></div></div><div class="sc11-card">'+rows+'</div></section>';
 }).join('');
 modal.innerHTML='<div class="sc11-head"><div><h2>Ayarlar</h2><p>Değişiklikler kaydedildiğinde uygulanır. API anahtarları yerel ayar dosyanda saklanır.</p></div><input class="sc11-search" id="sc11Search" placeholder="Ayar ara..." value="'+esc(QUERY)+'"><button class="icon-btn" onclick="ayarlariKapat()">✕</button></div>'+
   '<div class="sc11-body"><nav class="sc11-nav">'+nav+'</nav><main class="sc11-content" id="sc11Content">'+(content||'<div class="sc11-empty">Eşleşen ayar yok.</div>')+'</main></div>'+
   '<div class="sc11-footer"><span class="sc11-footnote">İpucu: “Kaydederken kodu biçimlendir” ve “hızlı kod kontrolü” artık açık isimlerle ve gerçek backend davranışıyla çalışır.</span><button class="btn" onclick="ayarlariKapat()">İptal</button><button class="btn primary" onclick="ayarlariKaydet()">Kaydet</button></div>';
 bindSettings();
}
function bindSettings(){
 Array.prototype.forEach.call(document.querySelectorAll('.sc11-nav button'),function(b){
   b.onclick=function(){ACTIVE=b.dataset.g;QUERY='';renderSettings();};
 });
 var search=el('sc11Search');
 if(search)search.oninput=function(){QUERY=this.value.toLowerCase().trim();renderSettings();setTimeout(function(){var s=el('sc11Search');if(s){s.focus();s.selectionStart=s.value.length;}},0);};
 Array.prototype.forEach.call(document.querySelectorAll('.sc11-switch'),function(sw){
   sw.onclick=function(){var k=sw.dataset.key;DRAFT[k]=!DRAFT[k];sw.classList.toggle('on',DRAFT[k]);};
 });
 Array.prototype.forEach.call(document.querySelectorAll('[data-key]'),function(inp){
   if(inp.classList.contains('sc11-switch'))return;
   inp.oninput=function(){setDraft(inp.dataset.key,inp.value,inp.type);};
   inp.onchange=function(){setDraft(inp.dataset.key,inp.value,inp.type);};
 });
}
function setDraft(k,v,type){
 if(type==='number')v=parseFloat(v);
 DRAFT[k]=v;
 if(k==='autoSaveBeforeRun')DRAFT.saveBeforeRun=v;
 if(k==='saveBeforeRun')DRAFT.autoSaveBeforeRun=v;
}

function applyEditor(){
 try{
  if(typeof editor!=='undefined'&&editor){
   editor.updateOptions({fontSize:DRAFT.fontSize,fontFamily:DRAFT.fontFamily,tabSize:DRAFT.tabSize,minimap:{enabled:!!DRAFT.minimap},wordWrap:DRAFT.wordWrap?'on':'off',fontLigatures:!!DRAFT.fontLigatures,lineNumbers:DRAFT.lineNumbers?'on':'off'});
  }
  if(typeof editor2!=='undefined'&&editor2){
   editor2.updateOptions({fontSize:DRAFT.fontSize,fontFamily:DRAFT.fontFamily,tabSize:DRAFT.tabSize,minimap:{enabled:false},wordWrap:DRAFT.wordWrap?'on':'off',fontLigatures:!!DRAFT.fontLigatures,lineNumbers:DRAFT.lineNumbers?'on':'off'});
  }
 }catch(e){}
}
function applySplit(){
 try{
  var c=el('editor-container'),p=el('editor2');if(!c||!p)return;
  var m=DRAFT.splitMode||'none';
  if(m==='none'){p.classList.remove('open');c.className='vertical';if(typeof editor2!=='undefined'&&editor2){try{editor2.dispose();}catch(e){} editor2=null;}}
  else{c.className=m;p.classList.add('open');if(typeof editor2==='undefined'||!editor2){editor2=monaco.editor.create(p,{value:'// İkinci editör',language:'python',theme:'sc-dyn',fontSize:DRAFT.fontSize,fontFamily:DRAFT.fontFamily,minimap:{enabled:false},automaticLayout:true,tabSize:DRAFT.tabSize});}}
  if(typeof window._scSplitResizerShow==='function')window._scSplitResizerShow();
 }catch(e){}
}
function applyAll(){
 window.settings=Object.assign(window.settings||{},DRAFT);
 try{if(typeof temaUygula==='function')temaUygula(window.settings.theme||'obsidian');}catch(e){}
 applyEditor();applySplit();
 try{if(typeof updateAiBadge==='function')updateAiBadge();}catch(e){}
 try{
  if(typeof _term!=='undefined'&&_term){_term.options.fontSize=window.settings.terminalFontSize||13;_term.options.scrollback=window.settings.terminalScrollback||1000;}
  if(typeof window._scFitTerm==='function')window._scFitTerm();
 }catch(e){}
 try{document.documentElement.style.setProperty('--sc-settings-rev',String(Date.now()));}catch(e){}
}

window.ayarlariAc=function(){
 normalizeDraft();
 var ov=el('settingsOverlay');if(ov)ov.classList.add('open');
 renderSettings();
};
window.fillSettings=function(){normalizeDraft();renderSettings();};
window.ayarlariKapat=function(){var ov=el('settingsOverlay');if(ov)ov.classList.remove('open');};
window.settingsSearchChanged=function(v){QUERY=String(v||'').toLowerCase();renderSettings();};
window.ayarlariKaydet=function(){
 normalizeDraft();
 DRAFT.saveBeforeRun=DRAFT.autoSaveBeforeRun;
 applyAll();
 var a=api();
 if(a&&a.ayarlari_kaydet){
  a.ayarlari_kaydet(DRAFT).then(function(r){
   if(r&&r.ok&&r.settings)window.settings=Object.assign(window.settings,r.settings);
   try{if(typeof toast==='function')toast('Ayarlar kaydedildi','success');}catch(e){}
  }).catch(function(e){try{toast(String(e),'error');}catch(x){}});
 }
 window.ayarlariKapat();
};
})();
"""

def find_root(cli=None):
    cands=[]
    if cli:
        cands.append(os.path.abspath(cli))
    here=os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for p in cands:
        if p and os.path.isdir(os.path.join(p,"splash_code")):
            return p
    return here

def rd(p):
    with open(p,"r",encoding="utf-8",newline="") as f:
        return f.read()

def wr(p,s):
    d=os.path.dirname(p) or "."
    os.makedirs(d,exist_ok=True)
    fd,tmp=tempfile.mkstemp(dir=d,suffix=".sctmp")
    try:
        with os.fdopen(fd,"w",encoding="utf-8",newline="") as f:
            f.write(s)
        os.replace(tmp,p)
    except Exception:
        try: os.remove(tmp)
        except Exception: pass
        raise

def strip_block(src,start,end):
    i=src.find(start)
    if i<0: return src
    j=src.find(end,i)
    if j<0: return src[:i]
    return src[:i]+src[j+len(end):]

SKIP={".git",".venv","venv","node_modules","_backups",".idea",".vscode","dist","build"}

def pycache(root):
    targets=[]
    for dp,dn,fn in os.walk(root):
        if os.path.basename(dp)=="__pycache__":
            targets.append(dp); dn[:]=[]; continue
        dn[:]=[d for d in dn if d not in SKIP]
    for t in targets:
        shutil.rmtree(t,ignore_errors=True)
    return len(targets)

def backup(root):
    bd=os.path.join(root,"_backups"); os.makedirs(bd,exist_ok=True)
    zp=os.path.join(bd,"pre_patch%s_%s.zip"%(PATCH_ID,time.strftime("%Y%m%d_%H%M%S")))
    n=0
    with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED) as z:
        for dp,dn,fns in os.walk(root):
            dn[:]=[d for d in dn if d not in SKIP]
            for fn in fns:
                full=os.path.join(dp,fn)
                rel=os.path.relpath(full,root).replace("\\","/")
                try:
                    if os.path.getsize(full)>25*1024*1024: continue
                    z.write(full,rel); n+=1
                except Exception:
                    pass
    return zp,n

def plan(root):
    api_path=os.path.join(root,API_REL)
    html_path=os.path.join(root,HTML_REL)
    if not os.path.isfile(api_path): return None,None,"api.py yok"
    if not os.path.isfile(html_path): return None,None,"index.html yok"
    api_src=strip_block(rd(api_path),PY_MARK,PY_END)
    api_new=api_src if api_src.endswith("\n") else api_src+"\n"
    api_new += "\n"+API_APPEND.strip("\n")+"\n"
    html_src=strip_block(rd(html_path),HTML_MARK,HTML_END)
    inject="\n%s\n<style>\n%s\n</style>\n<script>\n%s\n</script>\n%s\n"%(HTML_MARK,SETTINGS_CSS.strip("\n"),SETTINGS_JS.strip("\n"),HTML_END)
    i=html_src.lower().rfind("</body>")
    html_new=html_src+inject if i<0 else html_src[:i]+inject+html_src[i:]
    return api_new,html_new,None

def verify(root,rels):
    bad=[]
    for rel in rels:
        if rel.endswith(".py"):
            try:
                py_compile.compile(os.path.join(root,rel),cfile=os.path.join(tempfile.gettempdir(),"sc011.pyc"),doraise=True)
            except Exception as e:
                bad.append((rel,str(e)))
    return bad

def rollback(root,zp,rels):
    print("  ! GERI ALINIYOR")
    with zipfile.ZipFile(zp) as z:
        names=set(z.namelist())
        for rel in rels:
            k=rel.replace("\\","/")
            if k in names:
                with open(os.path.join(root,rel),"wb") as f: f.write(z.read(k))
                print("    geri: "+rel)

def restore(root,zp):
    if not os.path.isfile(zp):
        print("Backup yok: "+zp); return 1
    n=0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t=os.path.join(root,name.replace("/",os.sep))
            os.makedirs(os.path.dirname(t),exist_ok=True)
            with open(t,"wb") as f: f.write(z.read(name))
            n+=1
    pycache(root)
    print("%d dosya geri yuklendi."%n)
    return 0

def check(root):
    api=rd(os.path.join(root,API_REL)) if os.path.isfile(os.path.join(root,API_REL)) else ""
    idx=rd(os.path.join(root,HTML_REL)) if os.path.isfile(os.path.join(root,HTML_REL)) else ""
    print("\n  --- TANI ---")
    print("  Ayarlar 011 backend :", "VAR" if PY_MARK in api else "YOK")
    print("  Ayarlar 011 panel   :", "VAR" if HTML_MARK in idx else "YOK")
    print("  rememberProject fix :", "VAR" if "_sc011_ayarlar_kaydet" in api else "YOK")
    print("  rememberSession fix :", "VAR" if "_sc011_oturum_yukle" in api else "YOK")
    return 0

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run",action="store_true")
    ap.add_argument("--no-backup",action="store_true")
    ap.add_argument("--restore",metavar="ZIP")
    ap.add_argument("--check",action="store_true")
    a=ap.parse_args()
    root=find_root(a.root)
    print("="*66)
    print("  Splash Code Studio - Patch %s"%PATCH_ID)
    print("  "+TITLE)
    print("="*66)
    print("  Kok: "+root)
    if a.restore: return restore(root,a.restore)
    if not os.path.isdir(os.path.join(root,"splash_code")):
        print("splash_code yok"); return 1
    if a.check: return check(root)
    api_new,html_new,err=plan(root)
    if err:
        print("SORUN: "+err); return 2
    print("\n  On-kontrol...")
    try:
        compile(api_new.encode("utf-8"),API_REL,"exec")
    except SyntaxError as e:
        print("X api.py satir %s: %s"%(e.lineno,e.msg)); return 2
    print("  Python OK · CSS %d KB · JS %d KB"%(len(SETTINGS_CSS)//1024,len(SETTINGS_JS)//1024))
    print("\n  Plan:")
    print("    %-34s GUNCELLE"%API_REL)
    print("    %-34s GUNCELLE"%HTML_REL)
    if a.dry_run:
        print("\n  --dry-run: temiz."); return 0
    zp=None
    if not a.no_backup:
        print("\n  Backup...")
        zp,n=backup(root)
        print("    %s (%d dosya)"%(zp,n))
    touched=[]
    try:
        wr(os.path.join(root,API_REL),api_new); touched.append(API_REL)
        wr(os.path.join(root,HTML_REL),html_new); touched.append(HTML_REL)
        print("    + "+API_REL)
        print("    + "+HTML_REL)
    except Exception as e:
        print("YAZMA HATASI: %s"%e)
        if zp: rollback(root,zp,touched)
        return 1
    bad=verify(root,touched)
    if bad:
        for rel,e in bad: print("X %s: %s"%(rel,e))
        if zp: rollback(root,zp,touched)
        return 1
    print("    OK · %d __pycache__ silindi"%pycache(root))
    print("\n"+"="*66)
    print("  Patch %s UYGULANDI"%PATCH_ID)
    if zp: print("  Geri al: py path.py --restore \"%s\""%zp)
    print("  Test: py main.py -> Ayarlar")
    print("="*66)
    return 0

if __name__=="__main__":
    sys.exit(main())
