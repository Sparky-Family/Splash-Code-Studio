#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 010 "Düzen"
1) Alt bardaki kalabalık araçlar -> sol menüye (SVG ikonlu, profesyonel)
2) Breakpoint: satır no soluna tıklayarak koyma + kırmızı highlight kalıntısı FIX
3) Harici terminal: NORMAL modda, varsayılan terminal, dosya konumuna cd + clear

    py path.py --check
    py path.py --dry-run
    py path.py
    py path.py --restore _backups/pre_patch010_XXXX.zip
"""

import argparse
import os
import py_compile
import re
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "010"
TITLE = "Sol menu araclar + breakpoint fix + harici terminal"
PY_MARK = "# ===== SC-STUDIO-010 ====="
PY_MARK_END = "# ===== /SC-STUDIO-010 ====="
HTML_MARK = "<!--SC-STUDIO-010-->"
HTML_MARK_END = "<!--/SC-STUDIO-010-->"
API_REL = "splash_code/api.py"
HTML_REL = "splash_code/templates/index.html"

# ══════════════════════════════════════════════════════════════════════
#  api.py  APPEND  —  harici terminal (normal mod, cd + clear)
# ══════════════════════════════════════════════════════════════════════

API_APPEND = r"""
# ===== SC-STUDIO-010 =====
import os as _sc010_os
import shutil as _sc010_shutil
import subprocess as _sc010_sp
import tempfile as _sc010_tf
import threading as _sc010_th
import time as _sc010_time
import uuid as _sc010_uuid


def _sc010_harici_terminal(self, path=None, *_rest):
    # Hedef klasor: secili agac yolu -> aktif sekme -> proje kokü
    try:
        target = None
        if path:
            p = _sc010_os.path.abspath(str(path))
            if _sc010_os.path.isdir(p):
                target = p
            elif _sc010_os.path.isfile(p):
                target = _sc010_os.path.dirname(p)
        if not target:
            cp = getattr(self, "_cur_path", None)
            if cp and _sc010_os.path.exists(cp):
                target = cp if _sc010_os.path.isdir(cp) else _sc010_os.path.dirname(cp)
        if not target:
            cw = getattr(self, "_cwd", None)
            if cw and _sc010_os.path.isdir(cw):
                target = cw
        if target and not _sc010_os.path.isdir(target):
            target = None
        if _sc010_os.name == "nt":
            return _sc010_open_win(target)
        return _sc010_open_unix(target)
    except Exception as e:
        return {"ok": False, "hata": str(e)}


def _sc010_open_win(target):
    CREATE_NO_WINDOW = 0x08000000
    wt = _sc010_shutil.which("wt")
    pwsh = _sc010_shutil.which("pwsh") or _sc010_shutil.which("powershell")
    if wt:
        name = "Windows Terminal"
        term_cmd = ('"%s" -d "%s"' % (wt, target)) if target else ('"%s"' % wt)
    elif pwsh:
        name = "PowerShell"
        if target:
            term_cmd = ('"%s" -NoExit -Command "Set-Location -LiteralPath \'%s\'; Clear-Host"'
                        % (pwsh, target))
        else:
            term_cmd = '"%s" -NoExit -Command "Clear-Host"' % pwsh
    else:
        name = "CMD"
        term_cmd = ('cmd /k cd /d "%s"' % target) if target else "cmd"

    # Gecici .cmd + zamanlanmis gorev -> yetki DUSURULUR (admin -> kullanici)
    tmp = _sc010_os.path.join(_sc010_tf.gettempdir(),
                              "sc_term_%s.cmd" % _sc010_uuid.uuid4().hex)
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write("@echo off\n")
            f.write('start "" %s\n' % term_cmd)
        task = "SC_Term_%s" % _sc010_uuid.uuid4().hex[:10]
        deelevated = False
        try:
            _sc010_sp.run(["schtasks", "/create", "/tn", task,
                           "/tr", '"%s"' % tmp, "/sc", "once",
                           "/st", "00:00", "/f"],
                          capture_output=True, timeout=10,
                          creationflags=CREATE_NO_WINDOW)
            _sc010_sp.run(["schtasks", "/run", "/tn", task],
                          capture_output=True, timeout=10,
                          creationflags=CREATE_NO_WINDOW)
            _sc010_sp.run(["schtasks", "/delete", "/tn", task, "/f"],
                          capture_output=True, timeout=10,
                          creationflags=CREATE_NO_WINDOW)
            deelevated = True
        except Exception:
            _sc010_sp.Popen(term_cmd, shell=True)

        def _clean():
            _sc010_time.sleep(3)
            try:
                _sc010_os.remove(tmp)
            except Exception:
                pass
        _sc010_th.Thread(target=_clean, daemon=True).start()
        return {"ok": True, "terminal": name,
                "deelevated": deelevated, "dir": target}
    except Exception as e:
        return {"ok": False, "hata": str(e)}


def _sc010_open_unix(target):
    term = None
    for cand in (["x-terminal-emulator"], ["gnome-terminal"], ["konsole"],
                 ["xfce4-terminal"], ["xterm"]):
        if _sc010_shutil.which(cand[0]):
            term = cand
            break
    if not term:
        return {"ok": False, "hata": "Terminal bulunamadi"}
    args = list(term)
    if target:
        if term[0] in ("gnome-terminal", "xfce4-terminal"):
            args += ["--working-directory", target]
        elif term[0] == "konsole":
            args += ["--workdir", target]
        else:
            args += [target]
    try:
        _sc010_sp.Popen(args, cwd=target or None)
        return {"ok": True, "terminal": term[0],
                "deelevated": False, "dir": target}
    except Exception as e:
        return {"ok": False, "hata": str(e)}


Api.harici_terminal_ac = _sc010_harici_terminal
# ===== /SC-STUDIO-010 =====
"""

# ══════════════════════════════════════════════════════════════════════
#  index.html  INJECT  —  CSS + JS
# ══════════════════════════════════════════════════════════════════════

CSS010 = r"""
.sc10-tools{display:flex;flex-direction:column;gap:2px;padding:6px}
.sc10-tool{display:flex;align-items:center;gap:8px;width:100%;padding:7px 8px;border:none;background:transparent;color:var(--text);border-radius:6px;cursor:pointer;font:500 12px/1.3 var(--font-ui);text-align:left}
.sc10-tool:hover{background:var(--bg-hover)}
.sc10-tool svg{flex:0 0 16px;color:var(--dim)}
.sc10-tool:hover svg{color:var(--accent)}
.sc10-tool .kbd{margin-left:auto;font:500 9.5px var(--font-mono);color:var(--dim);border:1px solid var(--border);border-radius:4px;padding:1px 5px}
.sc10-sep{height:1px;background:var(--border);margin:6px 4px}
.sc10-panel{display:none;padding:6px 8px;border-top:1px solid var(--border);max-height:34vh;overflow:auto}
.sc10-panel.on{display:block}
.sc10-bp-glyph{background:radial-gradient(circle at 50% 50%, #F85149 0 40%, transparent 41%);cursor:pointer}
.monaco-editor .margin-view-overlays .sc10-bp-glyph:hover{filter:brightness(1.3)}
"""

JS010 = r"""
(function(){
'use strict';
if (window.__SC10__) return;
window.__SC10__ = true;

var I = {
  sliders:'<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  alert:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
  list:'<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
  check:'<polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
  type:'<polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/>',
  edit:'<path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>',
  link:'<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  repeat:'<polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
  disc:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>',
  play:'<polygon points="5 3 19 12 5 21 5 3"/>',
  git:'<line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
  flask:'<path d="M9 3h6"/><path d="M10 3v6L4.5 17a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 9V3"/>'
};
function ic(n,s){ s=s||16; return '<svg xmlns="http://www.w3.org/2000/svg" width="'+s+'" height="'+s+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+(I[n]||'')+'</svg>'; }

/* ---------- breakpoint: kalici kirmizi highlight FIX + gutter tik ---------- */
window.sc23ToggleBreakpoint = function(ln){
  try{
    var line = (typeof ln==='number') ? ln : (editor.getPosition()?editor.getPosition().lineNumber:null);
    if(!line) return;
    if(!window._sc23) window._sc23={};
    if(!window._sc23.breakpoints) window._sc23.breakpoints=new Set();
    var bps=window._sc23.breakpoints;
    var added = !bps.has(line);
    if(added) bps.add(line); else bps.delete(line);
    window.sc23RenderBreakpoints();
    if(window.sc23Toast) window.sc23Toast('Breakpoint '+(added?'eklendi':'kald\u0131r\u0131ld\u0131')+': sat\u0131r '+line,'info',1200);
  }catch(e){}
};
window.sc23RenderBreakpoints = function(){
  try{
    if(!window.editor||!window.monaco) return;
    if(!window._sc23) window._sc23={};
    if(!window._sc23.breakpoints) window._sc23.breakpoints=new Set();
    window._sc23.bpDecorIds = window._sc23.bpDecorIds||[];
    var decs=[];
    window._sc23.breakpoints.forEach(function(l){
      decs.push({ range:new monaco.Range(l,1,l,1),
        options:{ glyphMarginClassName:'sc10-bp-glyph', stickiness:1 } });
    });
    decs.sort(function(a,b){return a.range.startLineNumber-b.range.startLineNumber;});
    window._sc23.bpDecorIds = editor.deltaDecorations(window._sc23.bpDecorIds, decs);
  }catch(e){}
};
function setupBreakpoints(){
  try{
    editor.updateOptions({ glyphMargin:true });
    if(!window.__sc10Cmds){
      window.__sc10Cmds=true;
      editor.addCommand(monaco.KeyCode.F9, function(){ window.sc23ToggleBreakpoint(); });
      editor.addCommand(monaco.KeyCode.F2, function(){ if(window.sc23Rename) window.sc23Rename(); });
      editor.onMouseDown(function(e){
        try{
          if(e.target && e.target.type===monaco.editor.MouseTargetType.GUTTER_GLYPH_MARGIN){
            var ln = e.target.position ? e.target.position.lineNumber : null;
            if(ln) window.sc23ToggleBreakpoint(ln);
          }
        }catch(err){}
      });
    }
    window.sc23RenderBreakpoints();
  }catch(e){}
}

/* ---------- sol menü: Araçlar ---------- */
function togglePanel(pid){
  var n=document.getElementById(pid); if(!n) return;
  var wasOn=n.classList.contains('on');
  ['sc23Problems','sc23Outline','sc23Todo'].forEach(function(x){
    var e=document.getElementById(x); if(e) e.classList.remove('on');
  });
  if(!wasOn) n.classList.add('on');
}
function buildTools(){
  if(document.getElementById('view-tools')) return;
  var ab=document.getElementById('activity-bar');
  if(ab && !document.getElementById('act-tools')){
    var btn=document.createElement('button');
    btn.className='icon-btn'; btn.id='act-tools'; btn.title='Ara\u00e7lar';
    btn.innerHTML=ic('sliders',18);
    btn.onclick=function(){ if(window.toggleSidebarView) window.toggleSidebarView('tools'); };
    var spacer=null;
    for(var i=0;i<ab.children.length;i++){
      var c=ab.children[i];
      if(c.style && c.style.flex==='1'){ spacer=c; break; }
    }
    if(spacer) ab.insertBefore(btn,spacer); else ab.appendChild(btn);
  }
  var sb=document.getElementById('sidebar'); if(!sb) return;
  var view=document.createElement('div');
  view.id='view-tools'; view.className='sidebar-view';
  view.innerHTML =
    '<div class="sidebar-header"><span>Ara\u00e7lar</span></div>'+
    '<div class="sc10-tools" id="sc10Tools"></div>'+
    '<div id="sc10Panels"></div>';
  sb.appendChild(view);

  var T=[
    {icon:'alert', label:'Sorunlar', view:1, fn:function(){togglePanel('sc23Problems'); if(window.sc23RefreshProblems)window.sc23RefreshProblems();}},
    {icon:'list',  label:'Outline',  view:1, fn:function(){togglePanel('sc23Outline'); if(window.sc23RefreshOutline)window.sc23RefreshOutline();}},
    {icon:'check', label:'TODO',     view:1, fn:function(){togglePanel('sc23Todo'); if(window.sc23RefreshTodo)window.sc23RefreshTodo();}},
    {sep:1},
    {icon:'type',   label:'Bi\u00e7imlendir', fn:function(){if(window.sc23FormatCurrent)window.sc23FormatCurrent();}},
    {icon:'edit',   label:'Yeniden Adland\u0131r', kbd:'F2', fn:function(){if(window.sc23Rename)window.sc23Rename();}},
    {icon:'link',   label:'Referanslar', kbd:'\u21e7F12', fn:function(){if(window.sc23References)window.sc23References();}},
    {icon:'repeat', label:'Ara / De\u011fi\u015ftir', fn:function(){if(window.sc23SearchReplace)window.sc23SearchReplace();}},
    {sep:1},
    {icon:'disc',  label:'Breakpoint', kbd:'F9', fn:function(){window.sc23ToggleBreakpoint();}},
    {icon:'play',  label:'Debug (pdb)', fn:function(){if(window.sc23DebugStart)window.sc23DebugStart();}},
    {icon:'git',   label:'Git Diff', fn:function(){if(window.sc23GitDiff)window.sc23GitDiff();}},
    {icon:'flask', label:'Testler', fn:function(){if(window.sc23RunTests)window.sc23RunTests();}}
  ];
  var wrap=document.getElementById('sc10Tools');
  T.forEach(function(t){
    if(t.sep){ var s=document.createElement('div'); s.className='sc10-sep'; wrap.appendChild(s); return; }
    var b=document.createElement('button');
    b.className='sc10-tool'; b.title=t.label;
    b.innerHTML=ic(t.icon,16)+'<span>'+t.label+'</span>'+(t.kbd?'<span class="kbd">'+t.kbd+'</span>':'');
    b.onclick=function(){ t.fn(); };
    wrap.appendChild(b);
  });

  var holder=document.getElementById('sc10Panels');
  ['sc23Problems','sc23Outline','sc23Todo'].forEach(function(pid){
    var n=document.getElementById(pid);
    if(!n){ n=document.createElement('div'); n.id=pid; }
    n.classList.add('sc10-panel');
    holder.appendChild(n);
  });
  var old=document.getElementById('sc23Panel');
  if(old) old.remove();
}

/* ---------- hazir olmayi bekle ---------- */
function whenReady(cb){
  var tries=0;
  var t=setInterval(function(){
    tries++;
    if(window.monaco && window.editor && document.getElementById('activity-bar')){
      clearInterval(t); cb();
    } else if(tries>240){ clearInterval(t); }
  },150);
}
whenReady(function(){
  try{ buildTools(); }catch(e){}
  try{ setupBreakpoints(); }catch(e){}
});
})();
"""

# ══════════════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════════════

SKIP = {".git", ".venv", "venv", "node_modules", "_backups",
        ".idea", ".vscode", "dist", "build"}
MAXB = 25 * 1024 * 1024


def find_root(cli=None):
    c = []
    if cli:
        c.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    c += [here, os.getcwd(), os.path.dirname(here)]
    for x in c:
        if os.path.isdir(os.path.join(x, "splash_code")):
            return x
    return c[0]


def rd(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def wr(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def pycache(root):
    t = []
    for dp, dn, fn in os.walk(root):
        if os.path.basename(dp) == "__pycache__":
            t.append(dp)
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in SKIP]
    for x in t:
        shutil.rmtree(x, ignore_errors=True)
    return len(t)


def backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAXB:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def strip_block(src, start, end):
    i = src.find(start)
    if i < 0:
        return src
    j = src.find(end, i)
    if j < 0:
        return src[:i]
    return src[:i] + src[j + len(end):]


def plan_api(root):
    p = os.path.join(root, API_REL)
    if not os.path.isfile(p):
        return None, API_REL + " yok"
    src = rd(p)
    src = strip_block(src, PY_MARK, PY_MARK_END)
    body = API_APPEND.strip("\n")
    new = src if src.endswith("\n") else src + "\n"
    new += "\n" + body + "\n"
    return new, None


def plan_html(root):
    p = os.path.join(root, HTML_REL)
    if not os.path.isfile(p):
        return None, HTML_REL + " yok"
    src = rd(p)
    src = strip_block(src, HTML_MARK, HTML_MARK_END)
    inject = ("\n%s\n<style>\n%s\n</style>\n<script>\n%s\n</script>\n%s\n"
              % (HTML_MARK, CSS010.strip("\n"), JS010.strip("\n"), HTML_MARK_END))
    low = src.lower()
    i = low.rfind("</body>")
    if i < 0:
        new = src + inject
    else:
        new = src[:i] + inject + src[i:]
    return new, None


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc010.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                if k in names:
                    with open(os.path.join(root, rel), "wb") as f:
                        f.write(z.read(k))
                    print("    geri: " + rel)
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Elle ac: %s" % zp)


def restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: " + zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def check(root):
    print("\n  --- TANI ---")
    api = rd(os.path.join(root, API_REL)) if os.path.isfile(
        os.path.join(root, API_REL)) else ""
    idx = rd(os.path.join(root, HTML_REL)) if os.path.isfile(
        os.path.join(root, HTML_REL)) else ""
    print("  api harici_terminal (schtasks de-elevasyon) : %s"
          % ("VAR" if PY_MARK in api else "YOK"))
    print("  index Araclar sidebar + breakpoint fix      : %s"
          % ("VAR" if HTML_MARK in idx else "YOK"))
    print("  glyphMargin CSS                             : %s"
          % ("VAR" if "sc10-bp-glyph" in idx else "YOK"))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 66)
    print("  Splash Code Studio - Patch %s" % PATCH_ID)
    print("  " + TITLE)
    print("=" * 66)
    print("  Kok: " + root)

    if a.restore:
        return restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok. --root ver.")
        return 1
    if a.check:
        return check(root)

    api_new, e1 = plan_api(root)
    html_new, e2 = plan_html(root)
    if e1 or e2:
        print("\n  !! SORUN:")
        if e1:
            print("     - " + e1)
        if e2:
            print("     - " + e2)
        return 2

    print("\n  On-kontrol (bellekte derleme)...")
    try:
        compile(api_new.encode("utf-8"), API_REL, "exec")
    except SyntaxError as e:
        print("    X api.py satir %s: %s" % (e.lineno, e.msg))
        return 2
    print("    Python OK")

    print("\n  Plan:")
    print("    %-34s GUNCELLE (harici terminal)" % API_REL)
    print("    %-34s GUNCELLE (araclar+breakpoint)" % HTML_REL)

    if a.dry_run:
        print("\n  --dry-run: temiz.")
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = backup(root)
        print("    %s (%d dosya)" % (zp, n))

    touched = []
    try:
        wr(os.path.join(root, API_REL), api_new)
        touched.append(API_REL)
        print("    + " + API_REL)
        wr(os.path.join(root, HTML_REL), html_new)
        touched.append(HTML_REL)
        print("    + " + HTML_REL)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Disk dogrulamasi...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK  ·  %d __pycache__ silindi" % pycache(root))

    print("\n" + "=" * 66)
    print("  Patch %s UYGULANDI" % PATCH_ID)
    if zp:
        print("  Geri al: py path.py --restore \"%s\"" % zp)
    print("  py main.py")
    print("    1) Sol menude yeni 'Araclar' ikonu -> alt bar artik yok")
    print("    2) Satir no soluna tikla -> breakpoint koy/kaldir (kalinti YOK)")
    print("    3) Ayarlar>Terminal modu=Harici -> Ctrl+` normal terminalde acar")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
