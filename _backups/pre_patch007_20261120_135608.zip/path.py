#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 007
1) xterm.js AMD kalkani (KOK FIX) + duplicate temizligi
2) index.html: sc23Body / window.editor / fit / tema noktalari
3) terminal.py + lsp_client.py cekirdek stabilizasyon + log.py

    py path.py --check
    py path.py --dry-run
    py path.py
"""

import argparse
import os
import py_compile
import re
import shutil
import sys
import tempfile
import time
import zipfile

PATCH_ID = "007"
TITLE = "xterm AMD kok fix + cekirdek stabilizasyon"
HTML_REL = "splash_code/templates/index.html"

XT_MARK = "t.AccessibilityManager=void 0"
XC_MARK = ".xterm-char-measure-element"
SHIELD = "/*SC-XT-SHIELD*/"

# ══════════════════════════════════════════════════════════════
#  splash_code/log.py  (YENI)
# ══════════════════════════════════════════════════════════════

LOG_PY = r'''"""
Splash Code Studio - Merkezi loglama  (SC-PATCH-007)
~/.splash_code/splash.log  (2MB x 3 rotasyon)
"""
import functools
import logging
import logging.handlers
import os
import sys
import traceback

from .constants import SETTINGS_DIR

LOG_FILE = os.path.join(SETTINGS_DIR, "splash.log")
_logger = None


def get_logger():
    global _logger
    if _logger is not None:
        return _logger
    lg = logging.getLogger("splash")
    lg.setLevel(logging.DEBUG)
    lg.propagate = False
    if not lg.handlers:
        try:
            os.makedirs(SETTINGS_DIR, exist_ok=True)
            fh = logging.handlers.RotatingFileHandler(
                LOG_FILE, maxBytes=2 * 1024 * 1024,
                backupCount=3, encoding="utf-8")
            fh.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)-7s [%(threadName)s] %(message)s"))
            lg.addHandler(fh)
        except Exception:
            lg.addHandler(logging.NullHandler())
        if os.environ.get("SPLASH_DEBUG"):
            sh = logging.StreamHandler(sys.stderr)
            sh.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
            lg.addHandler(sh)
    _logger = lg
    return lg


def info(msg, *args):
    try:
        get_logger().info(msg, *args)
    except Exception:
        pass


def warn(msg, *args):
    try:
        get_logger().warning(msg, *args)
    except Exception:
        pass


def error(msg, *args):
    try:
        get_logger().error(msg, *args)
    except Exception:
        pass


def exc(msg, e=None):
    try:
        suffix = (": %s" % e) if e is not None else ""
        get_logger().error("%s%s\n%s", msg, suffix, traceback.format_exc())
    except Exception:
        pass


def safe(default=None):
    def deco(fn):
        @functools.wraps(fn)
        def wrap(*a, **kw):
            try:
                return fn(*a, **kw)
            except Exception as e:
                exc(fn.__qualname__, e)
                return default() if callable(default) else default
        return wrap
    return deco
'''

# ══════════════════════════════════════════════════════════════
#  splash_code/terminal.py
# ══════════════════════════════════════════════════════════════

TERMINAL_PY = r'''"""
Splash Code Studio - Terminal PTY Yonetimi  (SC-PATCH-007)

  * RLock -> ic ice kilitlenme yok
  * Kilit altinda asla I/O yok
  * Queue'lu writer -> sirali cikti + zaman tabanli flush
  * env winpty'ye de geciriliyor
  * Reader: olu surecte sonsuz dongu korumasi
  * Coklu terminal altyapisi hazir (term_list)
"""
import os
import queue
import shutil
import threading
import time

try:
    from .log import exc, info, warn
except Exception:
    def exc(*a, **k):
        pass

    def info(*a, **k):
        pass

    def warn(*a, **k):
        pass

_TERM_PROCS = {}
_TERM_LOCK = threading.RLock()
_MAX_CHUNK = 8000
_FLUSH_INTERVAL = 0.035
_READ_ERRORS_LIMIT = 20


def _alive(proc):
    try:
        return bool(proc.isalive())
    except Exception:
        return False


def _notify_frontend(func_name, data, term_id):
    try:
        import webview
        if not webview.windows:
            return
        import json as _json
        if data is None:
            js = ("if(window.%s) window.%s(%s);"
                  % (func_name, func_name, _json.dumps(term_id)))
        else:
            js = ("if(window.%s) window.%s(%s, %s);"
                  % (func_name, func_name,
                     _json.dumps(data), _json.dumps(term_id)))
        webview.windows[0].evaluate_js(js)
    except Exception as e:
        warn("term notify %s: %s", func_name, e)


def term_spawn(term_id, cwd, shell_cmd=None):
    term_id = str(term_id or "t1")
    try:
        term_close(term_id)

        if not cwd or not os.path.isdir(str(cwd)):
            cwd = os.getcwd()
        cwd = os.path.abspath(cwd)

        env = dict(os.environ)
        env.setdefault("TERM", "xterm-256color")
        env.setdefault("COLORTERM", "truecolor")
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUNBUFFERED"] = "1"

        if os.name == "nt":
            try:
                from winpty import PtyProcess as WPy
            except ImportError:
                return {"ok": False,
                        "hata": "pywinpty yok. pip install pywinpty"}
            shell = shell_cmd or (
                shutil.which("pwsh")
                or shutil.which("powershell")
                or "powershell.exe")
            argv = [shell] if isinstance(shell, str) else list(shell)
            try:
                proc = WPy.spawn(argv, cwd=cwd, env=env,
                                 dimensions=(30, 120))
            except TypeError:
                proc = WPy.spawn(argv, cwd=cwd, dimensions=(30, 120))
        else:
            try:
                import ptyprocess
            except ImportError:
                return {"ok": False,
                        "hata": "ptyprocess yok. pip install ptyprocess"}
            shell = shell_cmd or os.environ.get("SHELL", "/bin/bash")
            argv = [shell] if isinstance(shell, str) else list(shell)
            proc = ptyprocess.PtyProcessUnicode.spawn(
                argv, cwd=cwd, env=env, dimensions=(30, 120))

        q = queue.Queue()
        stop = threading.Event()
        entry = {"proc": proc, "q": q, "stop": stop, "cwd": cwd}
        with _TERM_LOCK:
            _TERM_PROCS[term_id] = entry

        def reader():
            errs = 0
            while not stop.is_set():
                try:
                    data = proc.read(4096)
                except EOFError:
                    break
                except Exception:
                    errs += 1
                    if errs > _READ_ERRORS_LIMIT or not _alive(proc):
                        break
                    time.sleep(0.02)
                    continue
                if not data:
                    if not _alive(proc):
                        break
                    continue
                errs = 0
                if isinstance(data, bytes):
                    data = data.decode("utf-8", "replace")
                q.put(data)
            q.put(None)

        def writer():
            buf, size, first = [], 0, 0.0
            while True:
                wait = _FLUSH_INTERVAL if not size else _FLUSH_INTERVAL / 3
                try:
                    item = q.get(timeout=wait)
                except queue.Empty:
                    item = ""
                if item is None:
                    break
                if item:
                    if not size:
                        first = time.time()
                    buf.append(item)
                    size += len(item)
                if size and (size >= _MAX_CHUNK
                             or time.time() - first >= _FLUSH_INTERVAL):
                    chunk = "".join(buf)
                    buf, size, first = [], 0, 0.0
                    _notify_frontend("termWrite", chunk, term_id)
            if buf:
                _notify_frontend("termWrite", "".join(buf), term_id)
            _notify_frontend("termClosed", None, term_id)
            with _TERM_LOCK:
                if _TERM_PROCS.get(term_id) is entry:
                    _TERM_PROCS.pop(term_id, None)
            info("terminal kapandi: %s", term_id)

        threading.Thread(target=reader, name="term-r-%s" % term_id,
                         daemon=True).start()
        threading.Thread(target=writer, name="term-w-%s" % term_id,
                         daemon=True).start()
        info("terminal basladi: %s (cwd=%s)", term_id, cwd)
        return {"ok": True, "cwd": cwd, "term_id": term_id}

    except Exception as e:
        exc("term_spawn", e)
        return {"ok": False, "hata": str(e)}


def _get_proc(term_id):
    with _TERM_LOCK:
        entry = _TERM_PROCS.get(term_id)
        return entry["proc"] if entry else None


def term_write(term_id, data):
    try:
        proc = _get_proc(term_id)
        if not proc:
            return {"ok": False}
        if not isinstance(data, str):
            data = str(data)
        proc.write(data)
        return {"ok": True}
    except Exception as e:
        exc("term_write", e)
        return {"ok": False, "hata": str(e)}


def term_resize(term_id, rows, cols):
    try:
        rows = max(5, min(200, int(rows or 30)))
        cols = max(20, min(500, int(cols or 120)))
        proc = _get_proc(term_id)
        if not proc:
            return {"ok": False}
        done = False
        for args in ((rows, cols), (cols, rows)):
            try:
                proc.setwinsize(*args)
                done = True
                break
            except Exception:
                continue
        if not done:
            warn("term_resize basarisiz: %s", term_id)
        return {"ok": True, "rows": rows, "cols": cols}
    except Exception as e:
        exc("term_resize", e)
        return {"ok": False}


def term_close(term_id):
    try:
        with _TERM_LOCK:
            entry = _TERM_PROCS.pop(term_id, None)
        if not entry:
            return {"ok": True}
        entry["stop"].set()
        proc = entry["proc"]
        try:
            proc.terminate(force=True)
        except TypeError:
            try:
                proc.terminate()
            except Exception:
                pass
        except Exception:
            pass
        try:
            entry["q"].put_nowait(None)
        except Exception:
            pass
        return {"ok": True}
    except Exception as e:
        exc("term_close", e)
        return {"ok": False}


def term_list():
    with _TERM_LOCK:
        return list(_TERM_PROCS.keys())


def close_all_terminals():
    with _TERM_LOCK:
        ids = list(_TERM_PROCS.keys())
    for tid in ids:
        try:
            term_close(tid)
        except Exception as e:
            exc("close_all_terminals", e)
'''

# ══════════════════════════════════════════════════════════════
#  splash_code/lsp_client.py
# ══════════════════════════════════════════════════════════════

LSP_PY = r'''"""
Splash Code Studio - LSP Istemcisi  (SC-PATCH-007)

  * stderr drain thread -> pipe dolup sunucu bloke olmuyor
  * bufsize=-1 + _read_exact -> kismi okuma / bozuk JSON yok
  * Istek oncesi _sync() -> sunucu asla bayat dokuman gormuyor
  * initialize() cevap dogrulamasi
  * Pool eviction kilit DISINDA
  * peek_lsp() -> diagnostics icin sunucu spawn etmez
"""
import json
import os
import shutil
import subprocess
import threading
import time
from collections import deque

from .constants import LSP_SERVERS
from .utils import path_to_uri

try:
    from .log import exc, info, warn
except Exception:
    def exc(*a, **k):
        pass

    def info(*a, **k):
        pass

    def warn(*a, **k):
        pass

_THROTTLE = 0.25
_CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0


class LspClient:

    def __init__(self, lang, root_path):
        self.lang = lang
        self.cmd = LSP_SERVERS.get(lang)
        self.proc = None
        self._id = 0
        self._wlock = threading.Lock()
        self._plock = threading.RLock()
        self._pending = {}
        self._open_files = set()
        self._versions = {}
        self._diagnostics = {}
        self._diag_lock = threading.Lock()
        self._last_text = {}
        self._pending_text = {}
        self._last_did_change = {}
        self._last_used = time.time()
        self._ready = False
        self._init_lock = threading.RLock()
        self.capabilities = {}
        self.stderr_tail = deque(maxlen=200)
        self._root = root_path or os.getcwd()
        self._reader = None
        self._errreader = None
        self._start()

    def _start(self):
        if not self.cmd:
            return
        exe = self.cmd[0]
        if not (shutil.which(exe)
                or (os.path.isabs(exe) and os.path.isfile(exe))):
            return
        try:
            kw = {}
            if _CREATE_NO_WINDOW:
                kw["creationflags"] = _CREATE_NO_WINDOW
            if os.path.isdir(self._root):
                kw["cwd"] = self._root
            self.proc = subprocess.Popen(
                self.cmd, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                bufsize=-1, **kw)
        except Exception as e:
            exc("lsp start %s" % self.lang, e)
            self.proc = None
            return

        p = self.proc

        def drain_stderr():
            try:
                for raw in iter(p.stderr.readline, b""):
                    line = raw.decode("utf-8", "replace").rstrip()
                    if line:
                        self.stderr_tail.append(line)
            except Exception:
                pass

        self._errreader = threading.Thread(
            target=drain_stderr, name="lsp-err-%s" % self.lang, daemon=True)
        self._errreader.start()
        self._reader = threading.Thread(
            target=self._read_loop, name="lsp-r-%s" % self.lang, daemon=True)
        self._reader.start()
        info("lsp basladi: %s (root=%s)", self.lang, self._root)

    def _read_headers(self, stream):
        headers = {}
        while True:
            line = stream.readline()
            if not line:
                return None
            try:
                line = line.decode("ascii", errors="ignore").strip()
            except Exception:
                return None
            if not line:
                return headers
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip()] = v.strip()

    def _read_exact(self, stream, n):
        chunks = []
        left = n
        while left > 0:
            b = stream.read(left)
            if not b:
                return None
            chunks.append(b)
            left -= len(b)
        return b"".join(chunks)

    def _read_loop(self):
        p = self.proc
        try:
            while p and p.poll() is None:
                headers = self._read_headers(p.stdout)
                if not headers:
                    break
                try:
                    length = int(headers.get("Content-Length", 0))
                except Exception:
                    continue
                if length <= 0:
                    continue
                body = self._read_exact(p.stdout, length)
                if body is None:
                    break
                try:
                    msg = json.loads(body.decode("utf-8", "replace"))
                except Exception as e:
                    warn("lsp %s bozuk mesaj: %s", self.lang, e)
                    continue
                try:
                    self._dispatch(msg)
                except Exception as e:
                    exc("lsp dispatch %s" % self.lang, e)
        except Exception:
            pass
        finally:
            self._ready = False
            with self._plock:
                for pend in self._pending.values():
                    try:
                        pend["event"].set()
                    except Exception:
                        pass
            info("lsp reader bitti: %s", self.lang)

    def _dispatch(self, msg):
        mid = msg.get("id")
        method = msg.get("method")
        if method is not None and mid is None:
            self._handle_notification(msg)
            return
        if method is not None and mid is not None:
            self._handle_server_request(msg, mid)
            return
        if mid is not None:
            with self._plock:
                pend = self._pending.get(mid)
            if pend:
                pend["response"] = msg
                pend["event"].set()

    def _handle_notification(self, msg):
        method = msg.get("method", "")
        params = msg.get("params") or {}
        if method == "textDocument/publishDiagnostics":
            uri = params.get("uri", "")
            diags = params.get("diagnostics") or []
            with self._diag_lock:
                self._diagnostics[uri] = diags[:200]
        elif method in ("window/logMessage", "window/showMessage"):
            warn("lsp %s: %s", self.lang, params.get("message", ""))

    def _handle_server_request(self, msg, mid):
        method = msg.get("method", "")
        params = msg.get("params") or {}
        if method == "workspace/configuration":
            items = params.get("items") or [{}]
            result = [{} for _ in items]
        elif method == "workspace/workspaceFolders":
            result = [{"uri": path_to_uri(self._root),
                       "name": os.path.basename(self._root) or "root"}]
        elif method == "workspace/applyEdit":
            result = {"applied": False}
        else:
            result = None
        body = json.dumps({"jsonrpc": "2.0", "id": mid,
                           "result": result}).encode("utf-8")
        self._write_raw(body)

    def _write_raw(self, body):
        try:
            header = ("Content-Length: %d\r\n\r\n" % len(body)).encode("ascii")
            with self._wlock:
                if not self.proc or not self.proc.stdin:
                    return False
                self.proc.stdin.write(header + body)
                self.proc.stdin.flush()
            return True
        except Exception as e:
            exc("lsp write %s" % self.lang, e)
            return False

    def _send(self, method, params, is_request=True):
        if not self.proc or self.proc.poll() is not None:
            return None
        msg = {"jsonrpc": "2.0", "method": method, "params": params}
        mid = None
        if is_request:
            with self._plock:
                self._id += 1
                mid = self._id
                self._pending[mid] = {"event": threading.Event(),
                                      "response": None}
            msg["id"] = mid
        body = json.dumps(msg, ensure_ascii=False).encode("utf-8")
        if not self._write_raw(body):
            if mid is not None:
                with self._plock:
                    self._pending.pop(mid, None)
            return None
        return mid if is_request else True

    def _request(self, method, params, timeout=10):
        mid = self._send(method, params, True)
        if mid is None:
            return None
        with self._plock:
            pend = self._pending.get(mid)
        if pend is None:
            return None
        try:
            ok = pend["event"].wait(timeout)
        finally:
            with self._plock:
                self._pending.pop(mid, None)
        if not ok:
            warn("lsp %s timeout: %s", self.lang, method)
            return None
        return pend["response"]

    def initialize(self):
        if self._ready:
            return True
        if not self.proc:
            return False
        with self._init_lock:
            if self._ready:
                return True
            if not self.proc or self.proc.poll() is not None:
                return False
            root_uri = path_to_uri(self._root)
            resp = self._request("initialize", {
                "processId": os.getpid(),
                "rootUri": root_uri,
                "rootPath": self._root,
                "clientInfo": {"name": "Splash Code Studio",
                               "version": "3.0.0"},
                "workspaceFolders": [{
                    "uri": root_uri,
                    "name": os.path.basename(self._root) or "root",
                }],
                "capabilities": {
                    "workspace": {
                        "workspaceFolders": True,
                        "configuration": True,
                        "didChangeConfiguration": {
                            "dynamicRegistration": False},
                    },
                    "textDocument": {
                        "synchronization": {
                            "dynamicRegistration": False, "didSave": True},
                        "completion": {
                            "dynamicRegistration": False,
                            "completionItem": {
                                "snippetSupport": False,
                                "documentationFormat": [
                                    "markdown", "plaintext"],
                            },
                        },
                        "hover": {
                            "dynamicRegistration": False,
                            "contentFormat": ["markdown", "plaintext"],
                        },
                        "definition": {
                            "dynamicRegistration": False,
                            "linkSupport": True},
                        "publishDiagnostics": {"relatedInformation": True},
                        "documentSymbol": {
                            "hierarchicalDocumentSymbolSupport": True},
                        "formatting": {"dynamicRegistration": False},
                    },
                    "window": {"workDoneProgress": True},
                },
            }, timeout=20)
            if not resp or "result" not in resp:
                warn("lsp %s initialize basarisiz: %s",
                     self.lang, (resp or {}).get("error"))
                return False
            self.capabilities = (resp.get("result") or {}).get(
                "capabilities") or {}
            self._send("initialized", {}, False)
            self._ready = True
            info("lsp hazir: %s", self.lang)
            return True

    def did_open(self, file_uri, text):
        if file_uri in self._open_files:
            return
        ok = self._send("textDocument/didOpen", {
            "textDocument": {"uri": file_uri, "languageId": self.lang,
                             "version": 1, "text": text},
        }, False)
        if ok:
            self._open_files.add(file_uri)
            self._versions[file_uri] = 1
            self._last_text[file_uri] = text
            self._last_did_change[file_uri] = time.time()

    def _sync(self, file_uri, text):
        self._last_used = time.time()
        if text is None:
            text = self._pending_text.get(file_uri)
            if text is None:
                text = self._last_text.get(file_uri, "")
        if file_uri not in self._open_files:
            self._pending_text.pop(file_uri, None)
            self.did_open(file_uri, text)
            return
        if (self._last_text.get(file_uri) == text
                and file_uri not in self._pending_text):
            return
        self._pending_text.pop(file_uri, None)
        self._last_text[file_uri] = text
        self._last_did_change[file_uri] = time.time()
        self._versions[file_uri] = self._versions.get(file_uri, 1) + 1
        self._send("textDocument/didChange", {
            "textDocument": {"uri": file_uri,
                             "version": self._versions[file_uri]},
            "contentChanges": [{"text": text}],
        }, False)

    def did_change(self, file_uri, text):
        if file_uri not in self._open_files:
            self._sync(file_uri, text)
            return
        if (self._last_text.get(file_uri) == text
                and file_uri not in self._pending_text):
            return
        self._pending_text[file_uri] = text
        if time.time() - self._last_did_change.get(file_uri, 0) < _THROTTLE:
            return
        self._sync(file_uri, text)

    def did_save(self, file_uri, text=None):
        try:
            self._send("textDocument/didSave", {
                "textDocument": {"uri": file_uri},
            }, False)
        except Exception as e:
            exc("lsp did_save", e)

    def did_close(self, file_uri):
        if not self.proc:
            return
        try:
            self._send("textDocument/didClose", {
                "textDocument": {"uri": file_uri},
            }, False)
        except Exception as e:
            exc("lsp did_close", e)
        self._open_files.discard(file_uri)
        self._pending_text.pop(file_uri, None)

    def completion(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/completion", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=3)
        if not resp:
            return None
        result = resp.get("result")
        if not result:
            return None
        if isinstance(result, list):
            return result
        return result.get("items", [])

    def hover(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/hover", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=10)
        return resp.get("result") if resp else None

    def definition(self, file_uri, line, col, text):
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/definition", {
            "textDocument": {"uri": file_uri},
            "position": {"line": line, "character": col},
        }, timeout=10)
        return resp.get("result") if resp else None

    def formatting(self, file_uri, text, tab_size=4, insert_spaces=True):
        if not self.initialize():
            return None
        self._sync(file_uri, text)
        resp = self._request("textDocument/formatting", {
            "textDocument": {"uri": file_uri},
            "options": {"tabSize": int(tab_size),
                        "insertSpaces": bool(insert_spaces)},
        }, timeout=10)
        return resp.get("result") if resp else None

    def diagnostics_for(self, file_uri):
        with self._diag_lock:
            return list(self._diagnostics.get(file_uri, []))

    def shutdown(self):
        proc = self.proc
        if not proc:
            return
        try:
            if proc.poll() is None:
                try:
                    self._request("shutdown", {}, timeout=2)
                except Exception:
                    pass
                try:
                    self._send("exit", {}, False)
                except Exception:
                    pass
                try:
                    proc.wait(timeout=2)
                except Exception:
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        try:
                            proc.kill()
                        except Exception:
                            pass
        finally:
            self._ready = False
            for stream in (proc.stdin, proc.stdout, proc.stderr):
                try:
                    if stream:
                        stream.close()
                except Exception:
                    pass
            with self._plock:
                for pend in self._pending.values():
                    try:
                        pend["event"].set()
                    except Exception:
                        pass
                self._pending.clear()
            self.proc = None
            info("lsp kapandi: %s", self.lang)


_LSP_CLIENTS = {}
_LSP_LOCK = threading.RLock()
_MAX_CLIENTS = 3


def get_lsp(lang, root):
    root = root or os.getcwd()
    key = (lang, root)
    doomed = []
    with _LSP_LOCK:
        c = _LSP_CLIENTS.get(key)
        if c is not None:
            if c.proc and c.proc.poll() is None:
                c._last_used = time.time()
                return c
            _LSP_CLIENTS.pop(key, None)
            doomed.append(c)
        while len(_LSP_CLIENTS) >= _MAX_CLIENTS:
            oldest = min(_LSP_CLIENTS,
                         key=lambda k: getattr(_LSP_CLIENTS[k],
                                               "_last_used", 0))
            doomed.append(_LSP_CLIENTS.pop(oldest))
        c = LspClient(lang, root)
        _LSP_CLIENTS[key] = c
    for d in doomed:
        threading.Thread(target=d.shutdown, daemon=True).start()
    return c


def peek_lsp(lang, root=None):
    root = root or os.getcwd()
    with _LSP_LOCK:
        c = _LSP_CLIENTS.get((lang, root))
        if c and c.proc and c.proc.poll() is None:
            return c
    return None


def shutdown_all_lsp():
    with _LSP_LOCK:
        clients = list(_LSP_CLIENTS.values())
        _LSP_CLIENTS.clear()
    threads = []
    for c in clients:
        t = threading.Thread(target=c.shutdown, daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join(timeout=3)
'''

FILES = {
    "splash_code/log.py": LOG_PY,
    "splash_code/terminal.py": TERMINAL_PY,
    "splash_code/lsp_client.py": LSP_PY,
}

# ══════════════════════════════════════════════════════════════
#  index.html CERRAHI EDITLER   (guard, anchor, yeni, aciklama)
# ══════════════════════════════════════════════════════════════

EDITS = [
    ("body.id='sc23Body'",
     "const body = div.querySelector('#sc23Body');",
     "let body = document.getElementById('sc23Body'); "
     "if(!body){ body=document.createElement('div'); "
     "body.id='sc23Body'; "
     "body.style.cssText='overflow:auto;min-height:0;flex:1'; "
     "['sc23Problems','sc23Outline','sc23Todo'].forEach(function(id)"
     "{ var n=div.querySelector('#'+id); if(n) body.appendChild(n); }); "
     "div.appendChild(body); }",
     "sc23Body yok -> alt panel ac/kapa butonu olusmuyor"),

    ("if(!editor || !window.monaco) return;",
     "if(!window.editor || !window.monaco) return;",
     "if(!editor || !window.monaco) return;",
     "let editor window'a yazilmaz -> sc25 ayarlar oluyordu"),

    ("if(editor){ editor.onDidChangeCursorPosition",
     "if(window.editor){ editor.onDidChangeCursorPosition(()=>{ "
     "clearTimeout(window._tsB); "
     "window._tsB=setTimeout(sc25BracketMatch, 120); }); }",
     "if(editor){ editor.onDidChangeCursorPosition(()=>{ "
     "clearTimeout(window._tsB); "
     "window._tsB=setTimeout(sc25BracketMatch, 120); }); }",
     "bracket-match baglama hic calismiyordu"),

    ("_c._renderService",
     "try { dims = _term.proposeDimensions(); } catch (e) {}",
     "try { var _c=_term._core; "
     "var _d=_c&&_c._renderService&&_c._renderService.dimensions; "
     "if(_d&&_d.css&&_d.css.cell.width>0&&_d.css.cell.height>0){ "
     "var _sb=(_c.viewport&&_c.viewport.scrollBarWidth)||0; "
     "var _cs=window.getComputedStyle(cont); "
     "var _aw=cont.clientWidth-(parseFloat(_cs.paddingLeft)||0)"
     "-(parseFloat(_cs.paddingRight)||0)-_sb; "
     "var _ah=cont.clientHeight-(parseFloat(_cs.paddingTop)||0)"
     "-(parseFloat(_cs.paddingBottom)||0); "
     "dims={cols:Math.max(2,Math.floor(_aw/_d.css.cell.width)),"
     "rows:Math.max(1,Math.floor(_ah/_d.css.cell.height))}; } "
     "} catch (e) {}",
     "proposeDimensions Terminal'de yok -> gercek hucre olcusu"),

    ("String(t.keyword||'')",
     "+ '<span class=\"tc-dot\" style=\"background:' + t.keyword "
     "+ '\"></span>'",
     "+ '<span class=\"tc-dot\" style=\"background:' + "
     "(String(t.keyword||'').charAt(0)==='#'?t.keyword:"
     "'#'+(t.keyword||'')) + '\"></span>'",
     "tema onizleme keyword rengi # eksik"),

    ("String(t.string||'')",
     "+ '<span class=\"tc-dot\" style=\"background:' + t.string "
     "+ '\"></span>'",
     "+ '<span class=\"tc-dot\" style=\"background:' + "
     "(String(t.string||'').charAt(0)==='#'?t.string:"
     "'#'+(t.string||'')) + '\"></span>'",
     "tema onizleme string rengi # eksik"),
]

# ══════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════

SKIP_DIRS = {".git", ".venv", "venv", "node_modules",
             "_backups", ".idea", ".vscode", "dist", "build"}
MAX_BACKUP_FILE = 25 * 1024 * 1024


def find_root(cli=None):
    cands = []
    if cli:
        cands.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for c in cands:
        if os.path.isdir(os.path.join(c, "splash_code")):
            return c
    return cands[0]


def read_text(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def clear_pycache(root):
    targets = []
    for dp, dn, fn in os.walk(root):
        if os.path.basename(dp) == "__pycache__":
            targets.append(dp)
            dn[:] = []
            continue
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
    for t in targets:
        shutil.rmtree(t, ignore_errors=True)
    return len(targets)


def make_backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP_DIRS]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAX_BACKUP_FILE:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def fix_xterm(html):
    """KOK FIX: xterm UMD'sini AMD'den koru + duplicate temizle."""
    rep = []
    spat = re.compile(r"(<script\b[^>]*>)(.*?)(</script>)", re.S | re.I)
    st = {"n": 0}

    def srep(m):
        op, body, cl = m.group(1), m.group(2), m.group(3)
        if XT_MARK not in body:
            return m.group(0)
        st["n"] += 1
        if st["n"] > 1:
            rep.append("xterm.js kopya #%d silindi (-%d KB)"
                       % (st["n"], len(m.group(0)) // 1024))
            return ""
        if SHIELD in body:
            rep.append("xterm.js AMD kalkani ZATEN var")
            return m.group(0)
        b = re.sub(r"^[ \t]*//# sourceMappingURL=.*$", "", body, flags=re.M)
        rep.append("xterm.js AMD KALKANI EKLENDI (kok fix)")
        return (op + SHIELD + "(function(){var define,exports,module;\n"
                + b + "\n})();\n" + cl)

    html = spat.sub(srep, html)
    if st["n"] == 0:
        rep.append("UYARI: inline xterm.js bulunamadi")

    cpat = re.compile(r"(<style\b[^>]*>)(.*?)(</style>)", re.S | re.I)
    ct = {"n": 0}

    def crep(m):
        if XC_MARK not in m.group(2):
            return m.group(0)
        ct["n"] += 1
        if ct["n"] > 1:
            rep.append("xterm.css kopya #%d silindi (-%d KB)"
                       % (ct["n"], len(m.group(0)) // 1024))
            return ""
        return m.group(0)

    html = cpat.sub(crep, html)
    return html, rep


def plan_html(root):
    p = os.path.join(root, HTML_REL)
    if not os.path.isfile(p):
        return None, ["%s: dosya yok" % HTML_REL], []
    src = read_text(p)
    cur = src
    notes = []
    for guard, anchor, new, desc in EDITS:
        if guard in cur:
            notes.append(("ZATEN", desc))
            continue
        c = cur.count(anchor)
        if c == 1:
            cur = cur.replace(anchor, new, 1)
            notes.append(("OK", desc))
        elif c == 0:
            notes.append(("MISS", desc))
        else:
            notes.append(("COKLU", desc))
    cur, xrep = fix_xterm(cur)
    for x in xrep:
        notes.append(("XTERM", x))
    changed = (cur != src)
    return (cur if changed else None), [], notes


def make_plan(root):
    ops, problems = [], []
    for rel, content in FILES.items():
        p = os.path.join(root, rel)
        if not os.path.exists(p):
            ops.append((rel, content, "YENI"))
            continue
        try:
            old = read_text(p)
        except Exception:
            ops.append((rel, content, "GUNCELLE"))
            continue
        if old == content:
            ops.append((rel, None, "AYNI"))
        else:
            ops.append((rel, content, "GUNCELLE"))
    h, hp, notes = plan_html(root)
    problems.extend(hp)
    ops.append((HTML_REL, h, "GUNCELLE" if h is not None else "DEGISIKLIK YOK"))
    return ops, problems, notes


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc007.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR...")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                t = os.path.join(root, rel)
                if k in names:
                    with open(t, "wb") as f:
                        f.write(z.read(k))
                    print("    geri: %s" % rel)
                else:
                    try:
                        os.remove(t)
                        print("    silindi (yeniydi): %s" % rel)
                    except Exception:
                        pass
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Elle ac: %s" % zp)


def do_restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: %s" % zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    clear_pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def do_check(root):
    print("\n  --- TANI ---")

    def rd(rel):
        try:
            return read_text(os.path.join(root, rel))
        except Exception:
            return ""

    idx = rd(HTML_REL)
    lsp = rd("splash_code/lsp_client.py")
    term = rd("splash_code/terminal.py")
    api = rd("splash_code/api.py")
    print("  === FRONTEND ===")
    print("  xterm.js inline kopya : %d" % idx.count(XT_MARK))
    print("  xterm AMD KALKANI     : %s"
          % ("VAR" if SHIELD in idx else "YOK  <-- TERMINAL FALLBACK SEBEBI"))
    print("  xterm.css kopya       : %d" % idx.count(XC_MARK))
    print("  index.html boyut      : %.0f KB" % (len(idx) / 1024.0))
    for g, d in (("body.id='sc23Body'", "sc23Body fix"),
                 ("if(!editor || !window.monaco)", "editor guard"),
                 ("_c._renderService", "fit fix"),
                 ("String(t.keyword||'')", "tema nokta fix")):
        print("  %-21s : %s" % (d, "VAR" if g in idx else "YOK"))
    print("  === BACKEND ===")
    print("  log.py                : %s"
          % ("VAR" if os.path.isfile(
              os.path.join(root, "splash_code", "log.py")) else "YOK"))
    print("  lsp peek_lsp          : %s"
          % ("VAR" if "def peek_lsp" in lsp else "YOK"))
    print("  lsp stderr drain      : %s"
          % ("VAR" if "drain_stderr" in lsp else "YOK"))
    print("  lsp bufsize=-1        : %s"
          % ("VAR" if "bufsize=-1" in lsp else "YOK"))
    print("  lsp _sync             : %s"
          % ("VAR" if "def _sync" in lsp else "YOK"))
    print("  terminal RLock        : %s"
          % ("VAR" if "threading.RLock()" in term else "YOK"))
    print("  terminal queue writer : %s"
          % ("VAR" if "import queue" in term else "YOK"))
    print("  api import tempfile   : %s"
          % ("VAR" if "import tempfile" in api else "YOK"))
    print("  api format_dosya      : %s"
          % ("VAR" if "def format_dosya" in api else "YOK"))
    ml = os.path.join(root, "splash_code", "static", "monaco",
                      "vs", "loader.js")
    print("  Yerel Monaco          : %s"
          % ("VAR" if os.path.isfile(ml) else "YOK"))
    lg = os.path.join(os.path.expanduser("~"), ".splash_code", "splash.log")
    if os.path.isfile(lg):
        print("  splash.log            : %d byte" % os.path.getsize(lg))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 66)
    print("  Splash Code Studio - Patch %s" % PATCH_ID)
    print("  %s" % TITLE)
    print("=" * 66)
    print("  Kok: %s" % root)

    if a.restore:
        return do_restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok. --root ver.")
        return 1
    if a.check:
        return do_check(root)

    print("\n  Icerik on-kontrolu (bellekte derleme)...")
    for rel, content in FILES.items():
        try:
            compile(content, rel, "exec")
        except SyntaxError as e:
            print("    X %s satir %s: %s" % (rel, e.lineno, e.msg))
            print("  Hicbir sey yazilmadi.")
            return 2
    print("    %d dosya derleniyor OK" % len(FILES))

    ops, problems, notes = make_plan(root)
    print("\n  Frontend islemleri:")
    for tag, desc in notes:
        print("    [%-6s] %s" % (tag, desc))
    print("\n  Dosya plani:")
    for rel, new, info_ in ops:
        print("    %-34s %s" % (rel, info_))

    if problems:
        print("\n  !! SORUN:")
        for x in problems:
            print("     - %s" % x)
        print("  Hicbir sey yazilmadi.")
        return 2

    todo = [(r, c) for r, c, _ in ops if c is not None]
    if not todo:
        print("\n  Zaten uygulanmis.")
        return 0
    if a.dry_run:
        print("\n  --dry-run: temiz. (%d dosya yazilacak)" % len(todo))
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = make_backup(root)
        print("    %s (%d dosya)" % (zp, n))

    touched = []
    try:
        for rel, content in todo:
            write_atomic(os.path.join(root, rel), content)
            touched.append(rel)
            print("    + %s" % rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Disk dogrulamasi...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK")
    print("    %d __pycache__ silindi" % clear_pycache(root))

    print("\n" + "=" * 66)
    print("  Patch %s UYGULANDI" % PATCH_ID)
    if zp:
        print("  Geri al: py path.py --restore \"%s\"" % zp)
    print("  Test: py main.py")
    print("    1) Terminal ac -> ARTIK FALLBACK DEGIL, gercek xterm")
    print("    2) Terminal boyutu panele tam oturuyor mu")
    print("    3) Alt panel ac/kapa oku calisiyor mu")
    print("    4) Tema galerisi noktalari renkli mi")
    print("  Log: ~/.splash_code/splash.log")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
