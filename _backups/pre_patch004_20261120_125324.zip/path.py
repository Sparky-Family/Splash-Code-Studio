#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Splash Code Studio - Patch 004
1) api.py: import tempfile  -> KAYIT DUZELIR
2) Offline Monaco: yerel vendor + kendi HTTP sunucumuz
3) --check      : tani raporu
4) --get-monaco : Monaco'yu indir

    py path.py --check
    py path.py --dry-run
    py path.py
    py path.py --get-monaco
"""

import argparse
import io
import os
import py_compile
import shutil
import sys
import tarfile
import tempfile
import time
import urllib.request
import zipfile

PATCH_ID = "004"
TITLE = "tempfile fix + offline Monaco"
MARK = "# ===== SC-PATCH-004 ====="
MONACO_VER = "0.44.0"

# ══════════════════════════════════════════════════════════════
#  main.py  (TAM YENIDEN YAZIM - docstring yok, sadece # yorum)
# ══════════════════════════════════════════════════════════════

MAIN_PY = r"""# Splash Code Studio v3.0 - Moduler Entry Point
# Tum mantik splash_code/ paketinde.
import sys
import os
import json
import threading
import traceback
import datetime

_CRASH_LOG = os.path.join(os.path.expanduser('~'), '.splash_code', 'error.log')
_PKG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'splash_code')


def _install_crash_handler():
    def handler(et, ev, etb):
        try:
            os.makedirs(os.path.dirname(_CRASH_LOG), exist_ok=True)
            with open(_CRASH_LOG, 'a', encoding='utf-8') as f:
                f.write('\n' + '=' * 60 + '\n')
                f.write(datetime.datetime.now().isoformat() + '\n')
                f.write('=' * 60 + '\n')
                traceback.print_exception(et, ev, etb, file=f)
            import webview
            if webview.windows:
                webview.windows[0].evaluate_js(
                    'if(window.scToast) scToast("Hata: " + '
                    + json.dumps(str(ev)[:200]) + ', "error", 8000);')
        except Exception:
            pass
        sys.__excepthook__(et, ev, etb)
    sys.excepthook = handler


_install_crash_handler()

from splash_code import app_name, version
from splash_code.settings import load_settings
from splash_code.api import Api
from splash_code.html_builder import build_html


def _local_monaco_ready():
    return os.path.isfile(
        os.path.join(_PKG_DIR, 'static', 'monaco', 'vs', 'loader.js'))


def _start_local_server(root):
    # Koku kesin bilinen mini HTTP sunucusu (stdlib).
    # Ayni origin -> Monaco worker'lari calisir.
    import functools
    from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            p = self.path.split('?')[0].lower()
            if p.endswith(('.py', '.pyc')) and not p.startswith('/static/'):
                self.send_error(403)
                return
            return SimpleHTTPRequestHandler.do_GET(self)

    handler = functools.partial(Handler, directory=root)
    srv = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def main():
    print('=' * 60)
    print(app_name + ' v' + version)
    print('=' * 60)
    import webview
    settings = load_settings()
    api = Api()
    html = build_html(settings)
    offline = _local_monaco_ready() and not os.environ.get('SPLASH_FORCE_CDN')
    srv = None
    window = None
    if offline:
        try:
            out = os.path.join(_PKG_DIR, 'index.sc.html')
            with open(out, 'w', encoding='utf-8', newline='') as f:
                f.write(html)
            srv, port = _start_local_server(_PKG_DIR)
            url = 'http://127.0.0.1:%d/index.sc.html' % port
            print('  Offline mod: ' + url)
            window = webview.create_window(
                app_name, url=url, js_api=api,
                width=1400, height=900, min_size=(900, 600),
                text_select=True)
        except Exception as e:
            print('  Offline mod kurulamadi, CDN moduna donuluyor: ' + str(e))
            if srv is not None:
                try:
                    srv.shutdown()
                except Exception:
                    pass
                srv = None
            window = None
    if window is None:
        print('  Online mod: Monaco CDN')
        window = webview.create_window(
            app_name, html=html, js_api=api,
            width=1400, height=900, min_size=(900, 600),
            text_select=True)

    def on_closed():
        try:
            api.cleanup()
        except Exception:
            pass
        if srv is not None:
            try:
                srv.shutdown()
            except Exception:
                pass

    window.events.closed += on_closed
    webview.start(debug=False, http_server=False)


if __name__ == '__main__':
    main()
"""

FILES = {"main.py": MAIN_PY}

# ══════════════════════════════════════════════════════════════
#  html_builder.py  (APPEND)
# ══════════════════════════════════════════════════════════════

B_HTML = r"""
# ===== SC-PATCH-004 =====
import os as _sc004_os
_SC004_CDN = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.44.0/min/vs'
_SC004_LOCAL = 'static/monaco/vs'
_sc004_orig_build = build_html
def _sc004_local_ready():
    try:
        d = _sc004_os.path.dirname(_sc004_os.path.abspath(__file__))
        p = _sc004_os.path.join(d, 'static', 'monaco', 'vs', 'loader.js')
        return _sc004_os.path.isfile(p)
    except Exception:
        return False
def build_html(settings):
    # Yerel Monaco varsa CDN adreslerini yerel yola cevir (offline)
    html = _sc004_orig_build(settings)
    try:
        if _sc004_local_ready() and not _sc004_os.environ.get('SPLASH_FORCE_CDN'):
            html = html.replace(_SC004_CDN, _SC004_LOCAL)
    except Exception:
        pass
    return html
# ===== /SC-PATCH-004 =====
"""

APPEND = {"splash_code/html_builder.py": B_HTML}

# ══════════════════════════════════════════════════════════════
#  api.py  (CERRAHI EDIT)  guard, anchor, yeni, aciklama
# ══════════════════════════════════════════════════════════════

EDITS = {
    "splash_code/api.py": [
        ("import tempfile", "import subprocess",
         "import subprocess\nimport tempfile",
         "import tempfile -> kaydet / calistir_icerik / projede_degistir"),
    ],
}

# ══════════════════════════════════════════════════════════════
#  MOTOR
# ══════════════════════════════════════════════════════════════

SKIP_DIRS = {"__pycache__", ".git", ".venv", "venv", "node_modules",
             "_backups", ".idea", ".vscode", "dist", "build"}
MAX_BACKUP_FILE = 25 * 1024 * 1024


def find_root(cli=None):
    cands = []
    if cli:
        cands.append(os.path.abspath(cli))
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [here, os.getcwd(), os.path.dirname(here)]
    for c in cands:
        if os.path.isdir(os.path.join(c, "splash_code")):
            return c
    return cands[0]


def read_text(p):
    with open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, content):
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".sctmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise


def make_backup(root):
    bd = os.path.join(root, "_backups")
    os.makedirs(bd, exist_ok=True)
    zp = os.path.join(bd, "pre_patch%s_%s.zip"
                      % (PATCH_ID, time.strftime("%Y%m%d_%H%M%S")))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dn, fns in os.walk(root):
            dn[:] = [d for d in dn if d not in SKIP_DIRS]
            for fn in fns:
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                try:
                    if os.path.getsize(full) > MAX_BACKUP_FILE:
                        continue
                    z.write(full, rel)
                    n += 1
                except Exception:
                    pass
    return zp, n


def make_plan(root):
    ops, problems = [], []

    for rel, content in FILES.items():
        p = os.path.join(root, rel)
        st = "YENI"
        if os.path.exists(p):
            try:
                st = "AYNI" if read_text(p) == content else "GUNCELLE"
            except Exception:
                st = "GUNCELLE"
        ops.append((rel, None if st == "AYNI" else content, st))

    for rel, block in APPEND.items():
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            problems.append("%s: dosya yok" % rel)
            continue
        src = read_text(p)
        if MARK in src:
            ops.append((rel, None, "ZATEN"))
            continue
        body = block.strip("\n")
        new = src if src.endswith("\n") else src + "\n"
        new += "\n" + body + "\n"
        ops.append((rel, new, "+%d satir" % len(body.splitlines())))

    for rel, items in EDITS.items():
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            problems.append("%s: dosya yok" % rel)
            continue
        cur = read_text(p)
        changed = False
        for guard, anchor, new, desc in items:
            if guard in cur:
                ops.append((rel, None, "ZATEN: " + desc))
                continue
            c = cur.count(anchor)
            if c != 1:
                problems.append("%s: anchor %d kez -> %s" % (rel, c, desc))
                continue
            cur = cur.replace(anchor, new, 1)
            changed = True
            ops.append((rel, cur, "OK: " + desc))
        if not changed:
            pass
    return ops, problems


def verify(root, rels):
    bad = []
    for rel in rels:
        if not rel.endswith(".py"):
            continue
        try:
            py_compile.compile(
                os.path.join(root, rel),
                cfile=os.path.join(tempfile.gettempdir(), "sc004.pyc"),
                doraise=True)
        except Exception as e:
            bad.append((rel, str(e)))
    return bad


def rollback(root, zp, rels):
    print("  ! GERI ALINIYOR...")
    try:
        with zipfile.ZipFile(zp) as z:
            names = set(z.namelist())
            for rel in rels:
                k = rel.replace("\\", "/")
                if k in names:
                    with open(os.path.join(root, rel), "wb") as f:
                        f.write(z.read(k))
                    print("    geri: %s" % rel)
    except Exception as e:
        print("    GERI ALMA BASARISIZ: %s" % e)
        print("    Elle ac: %s" % zp)


def clear_pycache(root):
    targets = []
    for dp, dn, _ in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        if os.path.basename(dp) == "__pycache__":
            targets.append(dp)
    for t in targets:
        shutil.rmtree(t, ignore_errors=True)
    return len(targets)


def do_restore(root, zp):
    if not os.path.isfile(zp):
        print("Backup yok: %s" % zp)
        return 1
    n = 0
    with zipfile.ZipFile(zp) as z:
        for name in z.namelist():
            t = os.path.join(root, name.replace("/", os.sep))
            try:
                os.makedirs(os.path.dirname(t), exist_ok=True)
                with open(t, "wb") as f:
                    f.write(z.read(name))
                n += 1
            except Exception:
                pass
    clear_pycache(root)
    print("%d dosya geri yuklendi." % n)
    return 0


def get_monaco(root):
    dest = os.path.abspath(
        os.path.join(root, "splash_code", "static", "monaco"))
    url = ("https://registry.npmjs.org/monaco-editor/-/monaco-editor-%s.tgz"
           % MONACO_VER)
    print("  Indiriliyor: %s" % url)
    try:
        with urllib.request.urlopen(url, timeout=240) as r:
            data = r.read()
    except Exception as e:
        print("  INDIRME BASARISIZ: %s" % e)
        return 1
    print("  %.1f MB alindi, aciliyor..." % (len(data) / 1048576.0))
    prefix = "package/min/"
    n = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
        for m in tf.getmembers():
            if not m.isfile() or not m.name.startswith(prefix + "vs/"):
                continue
            rel = m.name[len(prefix):]
            target = os.path.abspath(
                os.path.join(dest, rel.replace("/", os.sep)))
            if os.path.commonpath([dest, target]) != dest:
                continue
            f = tf.extractfile(m)
            if f is None:
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, "wb") as out:
                shutil.copyfileobj(f, out)
            n += 1
    ok = os.path.isfile(os.path.join(dest, "vs", "loader.js"))
    print("  %d dosya -> %s" % (n, dest))
    print("  loader.js: %s" % ("VAR" if ok else "YOK (!)"))
    return 0 if ok else 1


def do_check(root):
    print("\n  --- TANI ---")

    def rd(rel):
        try:
            return read_text(os.path.join(root, rel))
        except Exception:
            return ""

    api = rd("splash_code/api.py")
    lsp = rd("splash_code/lsp_client.py")
    hb = rd("splash_code/html_builder.py")
    idx = rd("splash_code/templates/index.html")
    mn = rd("main.py")

    print("  api.py import tempfile   : %s"
          % ("VAR" if "import tempfile" in api else "YOK  <-- KAYIT BOZUK"))
    print("  api.py tempfile.mkstemp  : %s"
          % ("VAR (002 uygulanmis)" if "tempfile.mkstemp" in api
             else "YOK (002 yok)"))
    print("  api.py format_dosya      : %s"
          % ("VAR" if "def format_dosya" in api else "YOK"))
    print("  Patch 001 (peek_lsp)     : %s"
          % ("VAR" if "def peek_lsp" in lsp else "YOK  <-- LSP fix eksik"))
    print("  Patch 003 (html)         : %s"
          % ("VAR" if "SC-PATCH-003" in hb else "YOK"))
    print("  Patch 004 (html)         : %s"
          % ("VAR" if MARK in hb else "YOK"))
    print("  main.py offline destek   : %s"
          % ("VAR" if "_start_local_server" in mn else "YOK"))
    ml = os.path.join(root, "splash_code", "static", "monaco",
                      "vs", "loader.js")
    print("  Yerel Monaco             : %s"
          % ("VAR" if os.path.isfile(ml) else "YOK  <-- --get-monaco"))
    print("  xterm.js inline kopya    : %d"
          % idx.count("t.AccessibilityManager=void 0"))
    print("  xterm.css inline kopya   : %d"
          % idx.count(".xterm-char-measure-element"))
    print("  index.html boyut         : %.0f KB" % (len(idx) / 1024.0))
    for mod in ("webview", "winpty", "ptyprocess"):
        try:
            m = __import__(mod)
            print("  %-24s : KURULU (%s)"
                  % (mod, getattr(m, "__version__", "?")))
        except Exception:
            print("  %-24s : YOK" % mod)
    print("  Python                   : %s" % sys.version.split()[0])
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--restore", metavar="ZIP")
    ap.add_argument("--get-monaco", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    root = find_root(a.root)

    print("=" * 64)
    print("  Splash Code Studio - Patch %s" % PATCH_ID)
    print("  %s" % TITLE)
    print("=" * 64)
    print("  Kok: %s" % root)

    if a.restore:
        return do_restore(root, a.restore)
    if not os.path.isdir(os.path.join(root, "splash_code")):
        print("\n  HATA: splash_code/ yok. --root ver.")
        return 1
    if a.check:
        return do_check(root)
    if a.get_monaco:
        return get_monaco(root)

    ops, problems = make_plan(root)
    print("\n  Plan:")
    for rel, new, info in ops:
        print("    %-30s %s" % (rel, info))
    if problems:
        print("\n  !! SORUN:")
        for x in problems:
            print("     - %s" % x)
        print("  Hicbir sey yazilmadi.")
        return 2

    todo = [(r, c) for r, c, _ in ops if c is not None]
    if not todo:
        print("\n  Zaten uygulanmis.")
        return 0
    if a.dry_run:
        print("\n  --dry-run: temiz.")
        return 0

    zp = None
    if not a.no_backup:
        print("\n  Backup...")
        zp, n = make_backup(root)
        print("    %s (%d dosya)" % (zp, n))

    touched = []
    try:
        for rel, content in todo:
            write_atomic(os.path.join(root, rel), content)
            touched.append(rel)
            print("    + %s" % rel)
    except Exception as e:
        print("    YAZMA HATASI: %s" % e)
        if zp:
            rollback(root, zp, touched)
        return 1

    print("\n  Derleme dogrulamasi...")
    bad = verify(root, touched)
    if bad:
        for rel, err in bad:
            print("    X %s\n      %s" % (rel, err))
        if zp:
            rollback(root, zp, touched)
        return 1
    print("    OK")
    print("    %d __pycache__ temizlendi" % clear_pycache(root))

    ml = os.path.join(root, "splash_code", "static", "monaco",
                      "vs", "loader.js")
    print("\n" + "=" * 64)
    print("  Patch %s UYGULANDI" % PATCH_ID)
    if not os.path.isfile(ml):
        print("  SIRADAKI: py path.py --get-monaco")
    else:
        print("  Yerel Monaco hazir -> offline mod aktif")
    if zp:
        print("  Geri al: py path.py --restore \"%s\"" % zp)
    print("  Test: py main.py")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())
